# Correção para APK Android — VOX Control

Este projeto usa TanStack Start/SSR para web. O Capacitor, porém, precisa carregar um app estático com `dist/client/index.html`.

Foram adicionados:

- `index.html` — entrada estática para o APK.
- `src/main.capacitor.tsx` — monta o React/TanStack Router no `#root`.
- `vite.capacitor.config.ts` — build estático com `base: "./"` e saída em `dist/client`.
- scripts Android estáticos no `package.json`.
- fallback no bootstrap do Supabase para o APK não travar em tela vazia caso esteja offline ou sem sessão.
- workflow GitHub Actions para gerar APK debug automaticamente.

## Comandos no PC

Primeira vez:

```bash
npm install
npm run build:android:web
npx cap add android
npx cap sync android
npx cap open android
```

Depois, para atualizar:

```bash
npm run android:build:static
npx cap open android
```

No Android Studio:

```text
Build > Build Bundle(s) / APK(s) > Build APK(s)
```

O APK debug fica em:

```text
android/app/build/outputs/apk/debug/app-debug.apk
```

## Sem PC, usando GitHub pelo celular

1. Suba estes arquivos corrigidos no repositório.
2. No GitHub, vá em **Actions**.
3. Abra **Build Android Debug APK**.
4. Toque em **Run workflow**.
5. Ao terminar, baixe o artifact **VOX-Control-debug-apk**.

Se o repositório não tiver `.env`, configure os secrets:

- `VITE_SUPABASE_URL`
- `VITE_SUPABASE_PUBLISHABLE_KEY`


## APK assinado pelo GitHub

Também foi adicionado o workflow:

```text
.github/workflows/android-signed-release-apk.yml
```

Ele gera o artifact:

```text
VOX-Control-release-signed-apk
```

Dentro do artifact fica o arquivo:

```text
VOX-Control-release-signed.apk
```

Leia o guia completo em:

```text
COMO_GERAR_APK_ASSINADO_PELO_GITHUB.md
```
