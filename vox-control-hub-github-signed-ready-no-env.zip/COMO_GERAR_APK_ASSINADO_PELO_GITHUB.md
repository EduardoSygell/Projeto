# Como gerar o APK assinado pelo GitHub — VOX Control

Este projeto já está preparado para o GitHub Actions gerar o APK Android assinado, mesmo sem computador.

## Caminho rápido — funciona agora

1. Suba os arquivos deste projeto no seu repositório do GitHub.
2. No GitHub, abra o repositório.
3. Vá em **Actions**.
4. Abra **Build Android Signed APK**.
5. Toque em **Run workflow**.
6. Aguarde terminar.
7. Entre no workflow finalizado e baixe o artifact:

```text
VOX-Control-release-signed-apk
```

Dentro dele estará:

```text
VOX-Control-release-signed.apk
```

Esse é o APK para instalar no celular.

## Importante sobre assinatura temporária

Se você rodar sem configurar secrets, o GitHub vai gerar uma assinatura temporária automaticamente.

Isso permite instalar e testar o APK, mas não é ideal para atualizações futuras. Se a assinatura mudar, o Android pode impedir instalar por cima do app antigo. Nesse caso, será necessário desinstalar o app antigo antes de instalar o novo.

## Caminho recomendado — assinatura permanente

Para sempre conseguir atualizar o app por cima, configure estes secrets no GitHub:

```text
ANDROID_KEYSTORE_BASE64
ANDROID_KEYSTORE_PASSWORD
ANDROID_KEY_ALIAS
ANDROID_KEY_PASSWORD
```

Também configure estes se quiser o Supabase funcionando no APK:

```text
VITE_SUPABASE_URL
VITE_SUPABASE_PUBLISHABLE_KEY
```

## Onde colocar os secrets

No repositório do GitHub:

```text
Settings > Secrets and variables > Actions > New repository secret
```

Crie um secret por vez, exatamente com os nomes acima.

## O que já foi corrigido no projeto

- Build estático para Android com Capacitor.
- `dist/client/index.html` gerado corretamente.
- Workflow para APK debug.
- Workflow para APK release assinado.
- Fallback para o app não travar em tela vazia se estiver offline ou sem Supabase.
- `.env` removido do pacote final por segurança.

## Nome do APK gerado

```text
VOX-Control-release-signed.apk
```

## Workflow usado

O arquivo principal é:

```text
.github/workflows/android-signed-release-apk.yml
```
