export type ConfigDefault = {
  categoria: string;
  chave: string;
  valor: number;
  descricao: string;
};

export const PRECIFICACAO_DEFAULTS: ConfigDefault[] = [
  { categoria: "GERAL", chave: "margem_padrao_pct", valor: 30, descricao: "Margem padrão (%)" },
  { categoria: "GERAL", chave: "desconto_padrao_pct", valor: 0, descricao: "Desconto padrão (%)" },
  { categoria: "GERAL", chave: "acrescimo_padrao_pct", valor: 0, descricao: "Acréscimo padrão (%)" },
  { categoria: "GERAL", chave: "validade_orcamento_dias", valor: 7, descricao: "Validade do orçamento (dias)" },

  { categoria: "DTF", chave: "filme_metro", valor: 18, descricao: "Filme DTF (R$/metro)" },
  { categoria: "DTF", chave: "tinta_branca_ml", valor: 0.45, descricao: "Tinta branca (R$/ml)" },
  { categoria: "DTF", chave: "tinta_cmyk_ml", valor: 0.35, descricao: "Tinta CMYK (R$/ml)" },
  { categoria: "DTF", chave: "mao_obra_min", valor: 1.5, descricao: "Mão de obra (R$/min)" },
  { categoria: "DTF", chave: "perda_pct", valor: 5, descricao: "Perda estimada (%)" },

  { categoria: "DTG", chave: "tinta_ml", valor: 0.6, descricao: "Tinta (R$/ml)" },
  { categoria: "DTG", chave: "pretratamento_un", valor: 2.5, descricao: "Pré-tratamento (R$/un)" },
  { categoria: "DTG", chave: "mao_obra_min", valor: 1.5, descricao: "Mão de obra (R$/min)" },

  { categoria: "BORDADO", chave: "pontos_1000", valor: 2.5, descricao: "Pontos (R$/1000)" },
  { categoria: "BORDADO", chave: "minuto_maquina", valor: 1.2, descricao: "Minuto de máquina (R$)" },
  { categoria: "BORDADO", chave: "linha_un", valor: 0.3, descricao: "Linha (R$/un)" },
  { categoria: "BORDADO", chave: "entretela_un", valor: 0.5, descricao: "Entretela (R$/un)" },
  { categoria: "BORDADO", chave: "setup_matriz", valor: 25, descricao: "Setup/Matriz (R$)" },

  { categoria: "PAGAMENTO", chave: "pix", valor: 1, descricao: "PIX" },
  { categoria: "PAGAMENTO", chave: "dinheiro", valor: 1, descricao: "Dinheiro" },
  { categoria: "PAGAMENTO", chave: "cartao_credito", valor: 1, descricao: "Cartão de crédito" },
  { categoria: "PAGAMENTO", chave: "cartao_debito", valor: 1, descricao: "Cartão de débito" },
  { categoria: "PAGAMENTO", chave: "boleto", valor: 0, descricao: "Boleto" },
  { categoria: "PAGAMENTO", chave: "transferencia", valor: 0, descricao: "Transferência bancária" },
  { categoria: "PAGAMENTO", chave: "forma_padrao", valor: 0, descricao: "PIX" },
];

export const GRUPOS: { categoria: string; titulo: string; descricao?: string }[] = [
  { categoria: "GERAL", titulo: "Geral", descricao: "Margens, desconto, acréscimo e validade do orçamento" },
  { categoria: "DTF", titulo: "DTF", descricao: "Custos para impressão DTF" },
  { categoria: "DTG", titulo: "DTG", descricao: "Custos para impressão direta no tecido" },
  { categoria: "BORDADO", titulo: "Bordado", descricao: "Custos para bordado computadorizado" },
];

export function chaveKey(c: string, k: string) {
  return `${c}.${k}`;
}
