import { useEffect, useMemo, useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { toast } from "sonner";
import { RotateCcw, Save } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Checkbox } from "@/components/ui/checkbox";
import {
  Select, SelectContent, SelectItem, SelectTrigger, SelectValue,
} from "@/components/ui/select";
import { db } from "@/lib/db";
import { PRECIFICACAO_DEFAULTS, GRUPOS, chaveKey } from "./precificacao-defaults";

type Row = { categoria: string; chave: string; valor: number; descricao: string | null };

export function PrecificacaoTab() {
  const qc = useQueryClient();
  const [values, setValues] = useState<Record<string, number>>({});
  const [pagamentoLabels, setPagamentoLabels] = useState<Record<string, string>>({});
  const [formaPadrao, setFormaPadrao] = useState<string>("pix");

  const { data: rows = [], isLoading } = useQuery({
    queryKey: ["config_precificacao"],
    queryFn: async () => {
      const { data, error } = await db.from("config_precificacao").select("categoria, chave, valor, descricao");
      if (error) throw error;
      return data as Row[];
    },
  });

  useEffect(() => {
    if (!rows.length) return;
    const v: Record<string, number> = {};
    const labels: Record<string, string> = {};
    let padrao = "pix";
    for (const r of rows) {
      v[chaveKey(r.categoria, r.chave)] = Number(r.valor ?? 0);
      if (r.categoria === "PAGAMENTO") {
        if (r.chave === "forma_padrao") padrao = r.descricao || "pix";
        else labels[r.chave] = r.descricao || r.chave;
      }
    }
    // garantir defaults para chaves ausentes
    for (const d of PRECIFICACAO_DEFAULTS) {
      const k = chaveKey(d.categoria, d.chave);
      if (!(k in v)) v[k] = d.valor;
      if (d.categoria === "PAGAMENTO" && d.chave !== "forma_padrao" && !(d.chave in labels)) {
        labels[d.chave] = d.descricao;
      }
    }
    setValues(v);
    setPagamentoLabels(labels);
    setFormaPadrao(padrao.toLowerCase());
  }, [rows]);

  const formasPagamento = useMemo(
    () => PRECIFICACAO_DEFAULTS.filter((d) => d.categoria === "PAGAMENTO" && d.chave !== "forma_padrao"),
    [],
  );

  const formasAtivas = formasPagamento.filter((f) => (values[chaveKey("PAGAMENTO", f.chave)] ?? 0) > 0);

  const save = useMutation({
    mutationFn: async () => {
      const payload = PRECIFICACAO_DEFAULTS.map((d) => {
        const k = chaveKey(d.categoria, d.chave);
        if (d.categoria === "PAGAMENTO") {
          if (d.chave === "forma_padrao") {
            return { categoria: "PAGAMENTO", chave: "forma_padrao", valor: 0, descricao: formaPadrao };
          }
          return {
            categoria: "PAGAMENTO",
            chave: d.chave,
            valor: values[k] ?? 0,
            descricao: pagamentoLabels[d.chave] ?? d.descricao,
          };
        }
        return { categoria: d.categoria, chave: d.chave, valor: Number(values[k] ?? 0), descricao: d.descricao };
      });
      const { error } = await db
        .from("config_precificacao")
        .upsert(payload, { onConflict: "categoria,chave" });
      if (error) throw error;
    },
    onSuccess: () => {
      toast.success("Configurações salvas");
      qc.invalidateQueries({ queryKey: ["config_precificacao"] });
    },
    onError: (e: Error) => toast.error(e.message),
  });

  function restaurar() {
    const v: Record<string, number> = {};
    const labels: Record<string, string> = {};
    for (const d of PRECIFICACAO_DEFAULTS) {
      v[chaveKey(d.categoria, d.chave)] = d.valor;
      if (d.categoria === "PAGAMENTO" && d.chave !== "forma_padrao") labels[d.chave] = d.descricao;
    }
    setValues(v);
    setPagamentoLabels(labels);
    setFormaPadrao("pix");
    toast.message("Padrões restaurados", { description: "Clique em Salvar para aplicar." });
  }

  function setVal(cat: string, k: string, v: string) {
    const n = v === "" ? 0 : Number(v);
    if (Number.isNaN(n)) return;
    setValues((prev) => ({ ...prev, [chaveKey(cat, k)]: n }));
  }

  if (isLoading) {
    return <div className="text-sm text-muted-foreground">Carregando configurações…</div>;
  }

  return (
    <div className="space-y-5">
      {GRUPOS.map((g) => {
        const itens = PRECIFICACAO_DEFAULTS.filter((d) => d.categoria === g.categoria);
        return (
          <div key={g.categoria} className="rounded-xl border border-border bg-card p-5">
            <div className="mb-3">
              <h3 className="text-sm font-semibold">{g.titulo}</h3>
              {g.descricao && <p className="text-xs text-muted-foreground">{g.descricao}</p>}
            </div>
            <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-3">
              {itens.map((d) => (
                <div key={d.chave}>
                  <Label className="text-xs">{d.descricao}</Label>
                  <Input
                    type="number"
                    step="0.01"
                    min={0}
                    value={values[chaveKey(d.categoria, d.chave)] ?? 0}
                    onChange={(e) => setVal(d.categoria, d.chave, e.target.value)}
                  />
                </div>
              ))}
            </div>
          </div>
        );
      })}

      <div className="rounded-xl border border-border bg-card p-5">
        <h3 className="mb-1 text-sm font-semibold">Formas de pagamento</h3>
        <p className="mb-3 text-xs text-muted-foreground">
          Marque as formas aceitas e escolha qual será sugerida por padrão nos novos orçamentos.
        </p>
        <div className="grid gap-2 sm:grid-cols-2 lg:grid-cols-3">
          {formasPagamento.map((f) => {
            const k = chaveKey("PAGAMENTO", f.chave);
            const ativo = (values[k] ?? 0) > 0;
            return (
              <label
                key={f.chave}
                className="flex items-center gap-2 rounded-lg border border-border/60 p-2 cursor-pointer hover:bg-muted/40"
              >
                <Checkbox
                  checked={ativo}
                  onCheckedChange={(c) =>
                    setValues((prev) => ({ ...prev, [k]: c ? 1 : 0 }))
                  }
                />
                <Input
                  value={pagamentoLabels[f.chave] ?? f.descricao}
                  onChange={(e) =>
                    setPagamentoLabels((p) => ({ ...p, [f.chave]: e.target.value }))
                  }
                  className="h-8 border-0 bg-transparent px-1 focus-visible:ring-0"
                />
              </label>
            );
          })}
        </div>
        <div className="mt-4 max-w-xs">
          <Label className="text-xs">Forma padrão</Label>
          <Select
            value={formaPadrao}
            onValueChange={(v) => setFormaPadrao(v)}
          >
            <SelectTrigger>
              <SelectValue placeholder="Selecione" />
            </SelectTrigger>
            <SelectContent>
              {(formasAtivas.length ? formasAtivas : formasPagamento).map((f) => (
                <SelectItem key={f.chave} value={f.chave}>
                  {pagamentoLabels[f.chave] ?? f.descricao}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>
      </div>

      <div className="flex flex-wrap items-center justify-end gap-2">
        <Button variant="outline" onClick={restaurar}>
          <RotateCcw className="mr-2 h-4 w-4" />
          Restaurar padrões
        </Button>
        <Button onClick={() => save.mutate()} disabled={save.isPending}>
          <Save className="mr-2 h-4 w-4" />
          {save.isPending ? "Salvando…" : "Salvar alterações"}
        </Button>
      </div>
    </div>
  );
}
