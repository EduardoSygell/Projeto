// Pure pricing engine — VOX Control
// Lê as configurações salvas em `config_precificacao` (categoria + chave),
// mapeadas no objeto: { `${categoria}_${chave}`: valor }
// As chaves AQUI devem espelhar exatamente as chaves do precificacao-defaults.ts
// para que qualquer alteração feita em Configurações > Precificação se aplique
// imediatamente em toda a operação (wizard, orçamentos, recálculos).

export type PricingConfig = Record<string, number>;

export const cfg = (c: PricingConfig, cat: string, key: string, fallback = 0) =>
  Number(c[`${cat}_${key}`] ?? fallback);

// ---------- DTF ----------
export type DTFInput = {
  metros: number;
  tintaBrancaMl: number;
  tintaCmykMl: number;
  tempoMin: number;
  perdaPct: number;
  quantidade: number;
};
export function precoDTF(i: DTFInput, c: PricingConfig) {
  const filme = i.metros * cfg(c, "DTF", "filme_metro");
  const tintaB = i.tintaBrancaMl * cfg(c, "DTF", "tinta_branca_ml");
  const tintaC = i.tintaCmykMl * cfg(c, "DTF", "tinta_cmyk_ml");
  const mo = i.tempoMin * cfg(c, "DTF", "mao_obra_min");
  const subtotal = filme + tintaB + tintaC + mo;
  const perdaPct = i.perdaPct || cfg(c, "DTF", "perda_pct");
  const comPerda = subtotal * (1 + perdaPct / 100);
  return {
    custoUnit: comPerda / Math.max(1, i.quantidade),
    custoTotal: comPerda,
    breakdown: { filme, tintaB, tintaC, mo },
  };
}

// ---------- DTG ----------
export type DTGInput = {
  tintaBrancaMl: number;
  tintaCmykMl: number;
  preTratamento: boolean;
  custoPeca: number;
  tempoMin: number;
  perdaPct: number;
  quantidade: number;
};
export function precoDTG(i: DTGInput, c: PricingConfig) {
  // DTG usa um custo único de tinta (R$/ml) — soma branca + cmyk
  const tintaTotalMl = (i.tintaBrancaMl || 0) + (i.tintaCmykMl || 0);
  const tintaB = i.tintaBrancaMl * cfg(c, "DTG", "tinta_ml");
  const tintaC = i.tintaCmykMl * cfg(c, "DTG", "tinta_ml");
  const tinta = tintaTotalMl * cfg(c, "DTG", "tinta_ml");
  const preT = i.preTratamento ? i.quantidade * cfg(c, "DTG", "pretratamento_un") : 0;
  const peca = i.custoPeca * i.quantidade;
  const mo = i.tempoMin * cfg(c, "DTG", "mao_obra_min");
  const subtotal = tinta + preT + peca + mo;
  const comPerda = subtotal * (1 + (i.perdaPct || 0) / 100);
  return {
    custoUnit: comPerda / Math.max(1, i.quantidade),
    custoTotal: comPerda,
    breakdown: { tintaB, tintaC, preT, peca, mo },
  };
}

// ---------- Bordado ----------
export type BordadoInput = {
  pontos: number;
  tempoMin: number;
  linhaM: number;     // unidades de linha consumidas
  entretelaUn: number;
  setup: boolean;
  perdaPct: number;
  quantidade: number;
};
export function precoBordado(i: BordadoInput, c: PricingConfig) {
  const pontos = (i.pontos / 1000) * cfg(c, "BORDADO", "pontos_1000") * i.quantidade;
  const tempo = i.tempoMin * cfg(c, "BORDADO", "minuto_maquina");
  const linha = i.linhaM * cfg(c, "BORDADO", "linha_un");
  const entretela = i.entretelaUn * cfg(c, "BORDADO", "entretela_un");
  const setup = i.setup ? cfg(c, "BORDADO", "setup_matriz") : 0;
  const subtotal = pontos + tempo + linha + entretela + setup;
  const comPerda = subtotal * (1 + (i.perdaPct || 0) / 100);
  return {
    custoUnit: comPerda / Math.max(1, i.quantidade),
    custoTotal: comPerda,
    breakdown: { pontos, tempo, linha, entretela, setup },
  };
}

// ---------- Geral ----------
export function aplicarMargem(custo: number, margemPct: number) {
  return custo * (1 + (margemPct || 0) / 100);
}

export function totalPedido(
  itens: { valorTotal: number }[],
  ajustes: { desconto?: number; acrescimo?: number; entrada?: number },
) {
  const subtotal = itens.reduce((s, i) => s + i.valorTotal, 0);
  const total = Math.max(0, subtotal - (ajustes.desconto || 0) + (ajustes.acrescimo || 0));
  const entrada = Math.min(total, ajustes.entrada || 0);
  return { subtotal, total, entrada, saldo: total - entrada };
}

// ---------- Helpers para ler defaults globais ----------
export function getGeral(c: PricingConfig) {
  return {
    margem_pct: cfg(c, "GERAL", "margem_padrao_pct", 30),
    desconto_pct: cfg(c, "GERAL", "desconto_padrao_pct", 0),
    acrescimo_pct: cfg(c, "GERAL", "acrescimo_padrao_pct", 0),
    validade_dias: cfg(c, "GERAL", "validade_orcamento_dias", 7),
  };
}
