import { useWizard } from "./wizard-context";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { ORIGENS } from "./types";
import type { Prioridade } from "./types";

export function StepPedido() {
  const { state, patch } = useWizard();
  const p = state.pedido;
  return (
    <div className="grid gap-3 sm:grid-cols-2">
      <div><Label>Código</Label><Input value={p.codigo} onChange={(e) => patch("pedido", { codigo: e.target.value })} /></div>
      <div>
        <Label>Prioridade</Label>
        <Select value={p.prioridade} onValueChange={(v) => patch("pedido", { prioridade: v as Prioridade })}>
          <SelectTrigger><SelectValue /></SelectTrigger>
          <SelectContent>{(["BAIXA","MEDIA","ALTA","URGENTE"] as const).map(x => <SelectItem key={x} value={x}>{x}</SelectItem>)}</SelectContent>
        </Select>
      </div>
      <div><Label>Data de entrega</Label><Input type="date" value={p.data_entrega} onChange={(e) => patch("pedido", { data_entrega: e.target.value })} /></div>
      <div><Label>Limite de produção</Label><Input type="date" value={p.data_limite_producao} onChange={(e) => patch("pedido", { data_limite_producao: e.target.value })} /></div>
      <div className="sm:col-span-2">
        <Label>Origem do pedido</Label>
        <Select value={p.origem} onValueChange={(v) => patch("pedido", { origem: v })}>
          <SelectTrigger><SelectValue /></SelectTrigger>
          <SelectContent>{ORIGENS.map((o) => <SelectItem key={o} value={o}>{o}</SelectItem>)}</SelectContent>
        </Select>
      </div>
      <div className="sm:col-span-2"><Label>Observações</Label><Textarea rows={3} value={p.observacoes} onChange={(e) => patch("pedido", { observacoes: e.target.value })} /></div>
    </div>
  );
}
