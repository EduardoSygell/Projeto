import { createContext, useContext, useEffect, useState, type ReactNode } from "react";
import type { WizardState } from "./types";
import { nextOrderCode } from "@/lib/db";

const empty: WizardState = {
  cliente: {
    modo: "novo", nome: "", documento: "", telefone: "", email: "", endereco: "",
    tipo: "PF", status: "ATIVO", observacoes: "", atencoes_producao: "", origem: "",
  },
  pedido: {
    codigo: nextOrderCode(),
    data_entrega: "",
    data_limite_producao: "",
    prioridade: "MEDIA",
    origem: "WHATSAPP",
    observacoes: "",
  },
  itens: [],
  anexos: [],
  precificacao: { margem_pct: 30, desconto: 0, acrescimo: 0, entrada: 0, forma_pagamento: "pix" },
  validade_dias: 7,
};

type Ctx = {
  state: WizardState;
  set: (p: Partial<WizardState>) => void;
  patch: <K extends keyof WizardState>(k: K, v: Partial<WizardState[K]>) => void;
  reset: () => void;
  saveDraft: () => void;
  lastSavedAt: number | null;
  draftRecovered: boolean;
  dismissRecoveryBanner: () => void;
};

const WizardCtx = createContext<Ctx | null>(null);
const STORAGE_KEY = "vox-wizard-draft";
const STORAGE_TS_KEY = "vox-wizard-draft-ts";

export function WizardProvider({ children }: { children: ReactNode }) {
  const [draftRecovered, setDraftRecovered] = useState(false);
  const [lastSavedAt, setLastSavedAt] = useState<number | null>(null);

  const [state, setState] = useState<WizardState>(() => {
    if (typeof window !== "undefined") {
      try {
        const raw = localStorage.getItem(STORAGE_KEY);
        if (raw) {
          const parsed = JSON.parse(raw);
          // Marca recuperação só se houver conteúdo significativo
          if (parsed?.cliente?.nome || parsed?.itens?.length || parsed?.anexos?.length) {
            setTimeout(() => setDraftRecovered(true), 0);
          }
          return { ...empty, ...parsed };
        }
      } catch { /* ignore */ }
    }
    return empty;
  });

  useEffect(() => {
    if (typeof window === "undefined") return;
    const ts = localStorage.getItem(STORAGE_TS_KEY);
    if (ts) setLastSavedAt(Number(ts));
  }, []);

  const persist = (s: WizardState) => {
    setState(s);
    try {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(s));
      const now = Date.now();
      localStorage.setItem(STORAGE_TS_KEY, String(now));
      setLastSavedAt(now);
    } catch { /* ignore */ }
  };

  const set = (p: Partial<WizardState>) => persist({ ...state, ...p });
  const patch: Ctx["patch"] = (k, v) =>
    persist({ ...state, [k]: { ...(state[k] as object), ...v } } as WizardState);
  const reset = () => {
    try {
      localStorage.removeItem(STORAGE_KEY);
      localStorage.removeItem(STORAGE_TS_KEY);
    } catch { /* ignore */ }
    setLastSavedAt(null);
    setDraftRecovered(false);
    setState({ ...empty, pedido: { ...empty.pedido, codigo: nextOrderCode() } });
  };
  const saveDraft = () => persist(state);
  const dismissRecoveryBanner = () => setDraftRecovered(false);

  return (
    <WizardCtx.Provider value={{ state, set, patch, reset, saveDraft, lastSavedAt, draftRecovered, dismissRecoveryBanner }}>
      {children}
    </WizardCtx.Provider>
  );
}

export function useWizard() {
  const v = useContext(WizardCtx);
  if (!v) throw new Error("useWizard must be inside WizardProvider");
  return v;
}
