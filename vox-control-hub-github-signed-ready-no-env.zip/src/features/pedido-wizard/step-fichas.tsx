import { useState } from "react";
import { useWizard } from "./wizard-context";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Tabs, TabsList, TabsTrigger, TabsContent } from "@/components/ui/tabs";
import type { ItemTecnica, FichaDTF, FichaDTG, FichaBordado, FichaPrensa } from "./types";

function num(e: React.ChangeEvent<HTMLInputElement>) { return Number(e.target.value); }

const defDTF = (): FichaDTF => ({ metros: 0, largura_filme: "60cm", tipo_filme: "", perfil_cor: "", tinta_branca_ml: 0, tinta_cmyk_ml: 0, poliamida_g: 0, temperatura: 160, tempo_cura: 90, tempo_prensa: 15, maquina: "", perda_pct: 5, observacoes: "" });
const defDTG = (): FichaDTG => ({ tinta_branca_ml: 0, tinta_cmyk_ml: 0, pre_tratamento: false, custo_pretratamento_un: 0, tipo_tecido: "ALGODAO_100", cor_peca: "", perfil_impressao: "", temperatura: 160, tempo_cura: 90, maquina: "", perda_pct: 5, observacoes: "" });
const defBord = (): FichaBordado => ({ pontos: 0, tempo_min: 0, num_cores: 1, codigos_linha: "", tipo_linha: "Polyester", tipo_entretela: "", bastidor: "", agulha: "", maquina: "", ocorrencias: [], perda_pct: 5, observacoes: "" });
const defPrensa = (): FichaPrensa => ({ temperatura: 150, tempo_prensa: 15, tipo_tecido: "", observacoes: "" });

export function StepFichas() {
  const { state, set } = useWizard();
  const [tab, setTab] = useState(state.itens[0]?.uid ?? "");

  if (state.itens.length === 0) {
    return <p className="rounded-lg border border-dashed border-border bg-muted/20 p-6 text-center text-sm text-muted-foreground">Volte e adicione técnicas primeiro.</p>;
  }

  const update = (uid: string, patch: Partial<ItemTecnica>) =>
    set({ itens: state.itens.map((i) => (i.uid === uid ? { ...i, ...patch } : i)) });

  return (
    <Tabs value={tab || state.itens[0].uid} onValueChange={setTab}>
      <TabsList className="flex-wrap h-auto">
        {state.itens.map((it, idx) => (
          <TabsTrigger key={it.uid} value={it.uid}>{it.tecnica} #{idx + 1}</TabsTrigger>
        ))}
      </TabsList>

      {state.itens.map((it) => (
        <TabsContent key={it.uid} value={it.uid} className="space-y-4 pt-4">
          {it.tecnica === "DTF" && <FichaDTFForm value={it.ficha_dtf ?? defDTF()} onChange={(v) => update(it.uid, { ficha_dtf: v })} />}
          {it.tecnica === "DTG" && <FichaDTGForm value={it.ficha_dtg ?? defDTG()} onChange={(v) => update(it.uid, { ficha_dtg: v })} />}
          {it.tecnica === "BORDADO" && <FichaBordadoForm value={it.ficha_bordado ?? defBord()} onChange={(v) => update(it.uid, { ficha_bordado: v })} />}
          {it.tecnica === "PRENSA" && <FichaPrensaForm value={it.ficha_prensa ?? defPrensa()} onChange={(v) => update(it.uid, { ficha_prensa: v })} />}
        </TabsContent>
      ))}
    </Tabs>
  );
}

function Field({ label, children }: { label: string; children: React.ReactNode }) {
  return <div><Label>{label}</Label>{children}</div>;
}

function FichaDTFForm({ value, onChange }: { value: FichaDTF; onChange: (v: FichaDTF) => void }) {
  const f = value;
  const u = (p: Partial<FichaDTF>) => onChange({ ...f, ...p });
  return (
    <div className="grid gap-3 sm:grid-cols-3">
      <Field label="Metros de filme"><Input type="number" step="0.01" value={f.metros} onChange={(e) => u({ metros: num(e) })} /></Field>
      <Field label="Largura do filme"><Input value={f.largura_filme} onChange={(e) => u({ largura_filme: e.target.value })} /></Field>
      <Field label="Tipo de filme"><Input value={f.tipo_filme} onChange={(e) => u({ tipo_filme: e.target.value })} /></Field>
      <Field label="Perfil de cor"><Input value={f.perfil_cor} onChange={(e) => u({ perfil_cor: e.target.value })} /></Field>
      <Field label="Tinta branca (ml)"><Input type="number" value={f.tinta_branca_ml} onChange={(e) => u({ tinta_branca_ml: num(e) })} /></Field>
      <Field label="Tinta CMYK (ml)"><Input type="number" value={f.tinta_cmyk_ml} onChange={(e) => u({ tinta_cmyk_ml: num(e) })} /></Field>
      <Field label="Poliamida (g) — interno"><Input type="number" value={f.poliamida_g} onChange={(e) => u({ poliamida_g: num(e) })} /></Field>
      <Field label="Temperatura (°C)"><Input type="number" value={f.temperatura} onChange={(e) => u({ temperatura: num(e) })} /></Field>
      <Field label="Tempo cura (s)"><Input type="number" value={f.tempo_cura} onChange={(e) => u({ tempo_cura: num(e) })} /></Field>
      <Field label="Tempo prensa (s)"><Input type="number" value={f.tempo_prensa} onChange={(e) => u({ tempo_prensa: num(e) })} /></Field>
      <Field label="Máquina"><Input value={f.maquina} onChange={(e) => u({ maquina: e.target.value })} /></Field>
      <Field label="Perda (%)"><Input type="number" value={f.perda_pct} onChange={(e) => u({ perda_pct: num(e) })} /></Field>
      <div className="sm:col-span-3"><Label>Observações técnicas</Label><Textarea rows={2} value={f.observacoes} onChange={(e) => u({ observacoes: e.target.value })} /></div>
    </div>
  );
}

function FichaDTGForm({ value, onChange }: { value: FichaDTG; onChange: (v: FichaDTG) => void }) {
  const f = value;
  const u = (p: Partial<FichaDTG>) => onChange({ ...f, ...p });
  return (
    <div className="grid gap-3 sm:grid-cols-3">
      <Field label="Tinta branca (ml)"><Input type="number" value={f.tinta_branca_ml} onChange={(e) => u({ tinta_branca_ml: num(e) })} /></Field>
      <Field label="Tinta CMYK (ml)"><Input type="number" value={f.tinta_cmyk_ml} onChange={(e) => u({ tinta_cmyk_ml: num(e) })} /></Field>
      <Field label="Pré-tratamento">
        <select className="h-10 w-full rounded-md border border-input bg-background px-3 text-sm" value={f.pre_tratamento ? "1" : "0"} onChange={(e) => u({ pre_tratamento: e.target.value === "1" })}>
          <option value="0">Não</option><option value="1">Sim</option>
        </select>
      </Field>
      <Field label="Tipo de tecido"><Input value={f.tipo_tecido} onChange={(e) => u({ tipo_tecido: e.target.value })} /></Field>
      <Field label="Cor da peça"><Input value={f.cor_peca} onChange={(e) => u({ cor_peca: e.target.value })} /></Field>
      <Field label="Perfil de impressão"><Input value={f.perfil_impressao} onChange={(e) => u({ perfil_impressao: e.target.value })} /></Field>
      <Field label="Temperatura (°C)"><Input type="number" value={f.temperatura} onChange={(e) => u({ temperatura: num(e) })} /></Field>
      <Field label="Tempo cura (s)"><Input type="number" value={f.tempo_cura} onChange={(e) => u({ tempo_cura: num(e) })} /></Field>
      <Field label="Máquina"><Input value={f.maquina} onChange={(e) => u({ maquina: e.target.value })} /></Field>
      <Field label="Perda (%)"><Input type="number" value={f.perda_pct} onChange={(e) => u({ perda_pct: num(e) })} /></Field>
      <div className="sm:col-span-3"><Label>Observações</Label><Textarea rows={2} value={f.observacoes} onChange={(e) => u({ observacoes: e.target.value })} /></div>
    </div>
  );
}

function FichaBordadoForm({ value, onChange }: { value: FichaBordado; onChange: (v: FichaBordado) => void }) {
  const f = value;
  const u = (p: Partial<FichaBordado>) => onChange({ ...f, ...p });
  return (
    <div className="grid gap-3 sm:grid-cols-3">
      <Field label="Pontos"><Input type="number" value={f.pontos} onChange={(e) => u({ pontos: num(e) })} /></Field>
      <Field label="Tempo (min)"><Input type="number" value={f.tempo_min} onChange={(e) => u({ tempo_min: num(e) })} /></Field>
      <Field label="Nº cores"><Input type="number" value={f.num_cores} onChange={(e) => u({ num_cores: num(e) })} /></Field>
      <Field label="Códigos das linhas"><Input value={f.codigos_linha} onChange={(e) => u({ codigos_linha: e.target.value })} /></Field>
      <Field label="Tipo de linha"><Input value={f.tipo_linha} onChange={(e) => u({ tipo_linha: e.target.value })} /></Field>
      <Field label="Entretela"><Input value={f.tipo_entretela} onChange={(e) => u({ tipo_entretela: e.target.value })} /></Field>
      <Field label="Bastidor"><Input value={f.bastidor} onChange={(e) => u({ bastidor: e.target.value })} /></Field>
      <Field label="Agulha"><Input value={f.agulha} onChange={(e) => u({ agulha: e.target.value })} /></Field>
      <Field label="Máquina"><Input value={f.maquina} onChange={(e) => u({ maquina: e.target.value })} /></Field>
      <Field label="Perda (%)"><Input type="number" value={f.perda_pct} onChange={(e) => u({ perda_pct: num(e) })} /></Field>
      <div className="sm:col-span-3"><Label>Ocorrências (separadas por vírgula)</Label>
        <Input value={f.ocorrencias.join(", ")} onChange={(e) => u({ ocorrencias: e.target.value.split(",").map(s => s.trim()).filter(Boolean) })} placeholder="linha arrebentou, peça puxou…" />
      </div>
      <div className="sm:col-span-3"><Label>Observações</Label><Textarea rows={2} value={f.observacoes} onChange={(e) => u({ observacoes: e.target.value })} /></div>
    </div>
  );
}

function FichaPrensaForm({ value, onChange }: { value: FichaPrensa; onChange: (v: FichaPrensa) => void }) {
  const f = value;
  const u = (p: Partial<FichaPrensa>) => onChange({ ...f, ...p });
  return (
    <div className="grid gap-3 sm:grid-cols-3">
      <Field label="Temperatura (°C)"><Input type="number" value={f.temperatura} onChange={(e) => u({ temperatura: num(e) })} /></Field>
      <Field label="Tempo prensa (s)"><Input type="number" value={f.tempo_prensa} onChange={(e) => u({ tempo_prensa: num(e) })} /></Field>
      <Field label="Tipo de tecido"><Input value={f.tipo_tecido} onChange={(e) => u({ tipo_tecido: e.target.value })} /></Field>
      <div className="sm:col-span-3"><Label>Observações</Label><Textarea rows={2} value={f.observacoes} onChange={(e) => u({ observacoes: e.target.value })} /></div>
    </div>
  );
}
