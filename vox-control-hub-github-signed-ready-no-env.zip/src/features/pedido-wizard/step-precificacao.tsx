import { useEffect, useRef } from "react";
import { useWizard } from "./wizard-context";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { precoDTF, precoDTG, precoBordado, aplicarMargem, totalPedido, type PricingConfig } from "./pricing-engine";
import type { ItemTecnica } from "./types";
import { usePrecificacaoConfig } from "@/hooks/use-precificacao-config";

const brl = (n: number) => Number(n).toLocaleString("pt-BR", { style: "currency", currency: "BRL" });

function calcItem(it: ItemTecnica, cfg: PricingConfig, margemPct: number) {
  let custo = it.custo_peca * it.quantidade;
  let breakdown = "";
  if (it.tecnica === "DTF" && it.ficha_dtf) {
    const r = precoDTF({
      metros: it.ficha_dtf.metros,
      tintaBrancaMl: it.ficha_dtf.tinta_branca_ml,
      tintaCmykMl: it.ficha_dtf.tinta_cmyk_ml,
      tempoMin: (it.ficha_dtf.tempo_prensa + it.ficha_dtf.tempo_cura) / 60,
      perdaPct: it.ficha_dtf.perda_pct,
      quantidade: it.quantidade,
    }, cfg);
    custo += r.custoTotal;
    breakdown = `Filme ${brl(r.breakdown.filme)} · Tintas ${brl(r.breakdown.tintaB + r.breakdown.tintaC)} · MO ${brl(r.breakdown.mo)}`;
  } else if (it.tecnica === "DTG" && it.ficha_dtg) {
    const r = precoDTG({
      tintaBrancaMl: it.ficha_dtg.tinta_branca_ml,
      tintaCmykMl: it.ficha_dtg.tinta_cmyk_ml,
      preTratamento: it.ficha_dtg.pre_tratamento,
      custoPeca: it.custo_peca,
      tempoMin: (it.ficha_dtg.tempo_cura) / 60,
      perdaPct: it.ficha_dtg.perda_pct,
      quantidade: it.quantidade,
    }, cfg);
    custo = r.custoTotal;
    breakdown = `Tintas ${brl(r.breakdown.tintaB + r.breakdown.tintaC)} · Peça ${brl(r.breakdown.peca)} · MO ${brl(r.breakdown.mo)}`;
  } else if (it.tecnica === "BORDADO" && it.ficha_bordado) {
    const r = precoBordado({
      pontos: it.ficha_bordado.pontos,
      tempoMin: it.ficha_bordado.tempo_min,
      linhaM: it.ficha_bordado.pontos / 100,
      entretelaUn: it.quantidade,
      setup: true,
      perdaPct: it.ficha_bordado.perda_pct,
      quantidade: it.quantidade,
    }, cfg);
    custo += r.custoTotal;
    breakdown = `Pontos ${brl(r.breakdown.pontos)} · Tempo ${brl(r.breakdown.tempo)} · Setup ${brl(r.breakdown.setup)}`;
  }
  const sugerido = aplicarMargem(custo, margemPct);
  return { custo, sugerido, breakdown, custoUnit: custo / Math.max(1, it.quantidade), sugeridoUnit: sugerido / Math.max(1, it.quantidade) };
}

export function StepPrecificacao() {
  const { state, set, patch } = useWizard();
  const { cfg, geral, pagamentos, formaPadrao, isLoading } = usePrecificacaoConfig();
  const seededRef = useRef(false);

  // Aplica defaults globais ao entrar no passo (uma única vez por sessão do wizard).
  useEffect(() => {
    if (isLoading || seededRef.current) return;
    seededRef.current = true;
    const p = state.precificacao;
    const next: typeof p = {
      ...p,
      margem_pct: p.margem_pct || geral.margem_pct,
      forma_pagamento: p.forma_pagamento || formaPadrao,
    };
    patch("precificacao", next);
    if (!state.validade_dias) set({ validade_dias: geral.validade_dias });
  }, [isLoading]); // eslint-disable-line react-hooks/exhaustive-deps

  const margem = state.precificacao.margem_pct || geral.margem_pct;

  // Recalcula preço sugerido sempre que cfg ou margem mudar
  useEffect(() => {
    if (isLoading) return;
    const updated = state.itens.map((it) => {
      const r = calcItem(it, cfg, margem);
      return { ...it, custo_calc: r.custo, preco_sugerido: r.sugeridoUnit };
    });
    if (
      JSON.stringify(updated.map((u) => [u.custo_calc, u.preco_sugerido])) !==
      JSON.stringify(state.itens.map((u) => [u.custo_calc, u.preco_sugerido]))
    ) {
      set({ itens: updated });
    }
  }, [cfg, margem, isLoading]); // eslint-disable-line react-hooks/exhaustive-deps

  const itensTot = state.itens.map((it) => ({
    valorTotal: ((it.override_unit ?? it.preco_sugerido ?? 0) * it.quantidade),
  }));
  const t = totalPedido(itensTot, {
    desconto: state.precificacao.desconto,
    acrescimo: state.precificacao.acrescimo,
    entrada: state.precificacao.entrada,
  });

  const updateItem = (uid: string, p: Partial<ItemTecnica>) =>
    set({ itens: state.itens.map((i) => (i.uid === uid ? { ...i, ...p } : i)) });

  return (
    <div className="space-y-4">
      <div className="grid gap-3 sm:grid-cols-4">
        <div><Label>Margem padrão (%)</Label><Input type="number" value={state.precificacao.margem_pct} onChange={(e) => patch("precificacao", { margem_pct: Number(e.target.value) })} /></div>
        <div><Label>Desconto (R$)</Label><Input type="number" value={state.precificacao.desconto} onChange={(e) => patch("precificacao", { desconto: Number(e.target.value) })} /></div>
        <div><Label>Acréscimo (R$)</Label><Input type="number" value={state.precificacao.acrescimo} onChange={(e) => patch("precificacao", { acrescimo: Number(e.target.value) })} /></div>
        <div><Label>Entrada (R$)</Label><Input type="number" value={state.precificacao.entrada} onChange={(e) => patch("precificacao", { entrada: Number(e.target.value) })} /></div>
        <div className="sm:col-span-2"><Label>Forma de pagamento</Label>
          <Select value={state.precificacao.forma_pagamento || formaPadrao} onValueChange={(v) => patch("precificacao", { forma_pagamento: v })}>
            <SelectTrigger><SelectValue placeholder="Selecione" /></SelectTrigger>
            <SelectContent>{pagamentos.map((p) => <SelectItem key={p.chave} value={p.chave}>{p.label}</SelectItem>)}</SelectContent>
          </Select>
        </div>
        <div className="sm:col-span-2"><Label>Validade do orçamento (dias)</Label><Input type="number" value={state.validade_dias} onChange={(e) => set({ validade_dias: Number(e.target.value) })} /></div>
      </div>

      <div className="overflow-hidden rounded-xl border border-border">
        <table className="w-full text-sm">
          <thead className="bg-muted/40 text-xs uppercase text-muted-foreground">
            <tr>
              <th className="px-3 py-2 text-left">Técnica</th>
              <th className="px-3 py-2 text-left">Descrição</th>
              <th className="px-3 py-2 text-right">Qtd</th>
              <th className="px-3 py-2 text-right">Custo peça</th>
              <th className="px-3 py-2 text-right">Custo total</th>
              <th className="px-3 py-2 text-right">Sugerido un.</th>
              <th className="px-3 py-2 text-right">Cobrar un.</th>
              <th className="px-3 py-2 text-right">Total</th>
            </tr>
          </thead>
          <tbody>
            {state.itens.map((it) => {
              const r = calcItem(it, cfg, margem);
              const unit = it.override_unit ?? r.sugeridoUnit;
              return (
                <tr key={it.uid} className="border-t border-border align-top">
                  <td className="px-3 py-2 font-medium">{it.tecnica}</td>
                  <td className="px-3 py-2">
                    <div>{it.descricao || "—"}</div>
                    <div className="text-[11px] text-muted-foreground">{r.breakdown}</div>
                  </td>
                  <td className="px-3 py-2 text-right">{it.quantidade}</td>
                  <td className="px-3 py-2 text-right">
                    <Input className="h-8 w-24 text-right text-xs" type="number" value={it.custo_peca} onChange={(e) => updateItem(it.uid, { custo_peca: Number(e.target.value) })} />
                  </td>
                  <td className="px-3 py-2 text-right text-muted-foreground">{brl(r.custo)}</td>
                  <td className="px-3 py-2 text-right">{brl(r.sugeridoUnit)}</td>
                  <td className="px-3 py-2 text-right">
                    <Input className="h-8 w-24 text-right text-xs" type="number" value={it.override_unit ?? Number(r.sugeridoUnit.toFixed(2))} onChange={(e) => updateItem(it.uid, { override_unit: Number(e.target.value) })} />
                  </td>
                  <td className="px-3 py-2 text-right font-semibold">{brl(unit * it.quantidade)}</td>
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>

      <div className="ml-auto max-w-sm space-y-1 rounded-xl border border-border bg-card p-4 text-sm">
        <Linha label="Subtotal" value={brl(t.subtotal)} />
        {state.precificacao.desconto > 0 && <Linha label="Desconto" value={"- " + brl(state.precificacao.desconto)} />}
        {state.precificacao.acrescimo > 0 && <Linha label="Acréscimo" value={"+ " + brl(state.precificacao.acrescimo)} />}
        <Linha label="Total" value={brl(t.total)} bold />
        {t.entrada > 0 && <><Linha label="Entrada" value={brl(t.entrada)} /><Linha label="Saldo" value={brl(t.saldo)} bold /></>}
      </div>
    </div>
  );
}

function Linha({ label, value, bold }: { label: string; value: string; bold?: boolean }) {
  return (
    <div className={`flex items-center justify-between ${bold ? "font-semibold text-foreground" : "text-muted-foreground"}`}>
      <span>{label}</span><span>{value}</span>
    </div>
  );
}
