import { useWizard } from "./wizard-context";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Trash2, Plus } from "lucide-react";
import type { Tecnica, ItemTecnica } from "./types";

const TECNICAS: { value: Tecnica; label: string; color: string }[] = [
  { value: "DTF", label: "DTF", color: "bg-orange-500/15 text-orange-300" },
  { value: "DTG", label: "DTG", color: "bg-orange-600/15 text-orange-200" },
  { value: "BORDADO", label: "Bordado", color: "bg-purple-500/15 text-purple-300" },
  { value: "PRENSA", label: "Prensa", color: "bg-amber-500/15 text-amber-300" },
];

const uid = () => Math.random().toString(36).slice(2, 10);

export function StepTecnicas() {
  const { state, set } = useWizard();

  const add = (tecnica: Tecnica) => {
    const novo: ItemTecnica = { uid: uid(), tecnica, descricao: "", quantidade: 1, custo_peca: 0 };
    set({ itens: [...state.itens, novo] });
  };

  const remove = (u: string) => set({ itens: state.itens.filter((i) => i.uid !== u) });
  const update = (u: string, patch: Partial<ItemTecnica>) =>
    set({ itens: state.itens.map((i) => (i.uid === u ? { ...i, ...patch } : i)) });

  return (
    <div className="space-y-4">
      <div className="flex flex-wrap gap-2">
        {TECNICAS.map((t) => (
          <Button key={t.value} variant="outline" onClick={() => add(t.value)}>
            <Plus className="mr-1 h-4 w-4" /> {t.label}
          </Button>
        ))}
      </div>

      {state.itens.length === 0 && (
        <p className="rounded-lg border border-dashed border-border bg-muted/20 p-6 text-center text-sm text-muted-foreground">
          Adicione pelo menos uma técnica para continuar.
        </p>
      )}

      <div className="space-y-3">
        {state.itens.map((it, idx) => {
          const t = TECNICAS.find((x) => x.value === it.tecnica)!;
          return (
            <div key={it.uid} className="rounded-xl border border-border bg-card p-4">
              <div className="mb-3 flex items-center justify-between gap-2">
                <div className="flex items-center gap-2">
                  <span className={`rounded-md px-2 py-0.5 text-xs font-semibold ${t.color}`}>{t.label}</span>
                  <span className="text-xs text-muted-foreground">Item #{idx + 1}</span>
                </div>
                <Button size="sm" variant="ghost" onClick={() => remove(it.uid)}>
                  <Trash2 className="h-4 w-4 text-destructive" />
                </Button>
              </div>
              <div className="grid gap-3 sm:grid-cols-3">
                <div className="sm:col-span-2"><Label>Descrição do item *</Label>
                  <Input value={it.descricao} onChange={(e) => update(it.uid, { descricao: e.target.value })} placeholder="Ex.: Camiseta preta com logo" />
                </div>
                <div><Label>Quantidade *</Label>
                  <Input type="number" min={1} value={it.quantidade} onChange={(e) => update(it.uid, { quantidade: Number(e.target.value) })} />
                </div>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
}
