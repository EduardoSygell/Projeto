import { useRef, useState } from "react";
import { toast } from "sonner";
import { Upload, Trash2, FileText, ExternalLink, Loader2, UploadCloud, Camera } from "lucide-react";
import { capturePhoto } from "@/lib/camera";
import { useWizard } from "./wizard-context";
import { db } from "@/lib/db";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Button } from "@/components/ui/button";
import { Progress } from "@/components/ui/progress";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { cn } from "@/lib/utils";
import { CATEGORIAS_ANEXO, STATUS_ANEXO } from "./types";
import type { AnexoTemp } from "./types";

const uid = () => Math.random().toString(36).slice(2, 10);
const MAX_BYTES = 25 * 1024 * 1024; // 25 MB

export function StepArquivos() {
  const { state, set } = useWizard();
  const [progress, setProgress] = useState(0);
  const [busy, setBusy] = useState(false);
  const [categoria, setCategoria] = useState("ORIGINAL_CLIENTE");
  const [itemUid, setItemUid] = useState<string>("");
  const [dragOver, setDragOver] = useState(false);
  const inputRef = useRef<HTMLInputElement>(null);

  const uploadOne = async (file: File): Promise<AnexoTemp | null> => {
    if (file.size > MAX_BYTES) {
      toast.error(`${file.name}: acima de 25 MB`);
      return null;
    }
    const ext = file.name.split(".").pop() ?? "bin";
    const path = `wizard/${state.pedido.codigo}/${Date.now()}-${Math.random().toString(36).slice(2, 8)}.${ext}`;
    const { error } = await db.storage.from("anexos").upload(path, file, { contentType: file.type || undefined });
    if (error) throw error;
    const { data: pub } = db.storage.from("anexos").getPublicUrl(path);
    return {
      uid: uid(),
      nome: file.name,
      url: pub.publicUrl,
      tipo: file.type || ext.toUpperCase(),
      tamanho: file.size,
      categoria,
      status: "RECEBIDO",
      descricao: "",
      item_uid: itemUid || undefined,
    };
  };

  const handleFiles = async (files: FileList | File[]) => {
    const arr = Array.from(files);
    if (arr.length === 0) return;
    setBusy(true);
    setProgress(5);
    const ticker = setInterval(
      () => setProgress((p) => (p < 90 ? p + Math.max(1, Math.round((90 - p) / 8)) : p)),
      200,
    );
    const novos: AnexoTemp[] = [];
    let okCount = 0;
    for (const f of arr) {
      try {
        const a = await uploadOne(f);
        if (a) {
          novos.push(a);
          okCount++;
        }
      } catch (e: unknown) {
        toast.error(`${f.name}: ${e instanceof Error ? e.message : "falha no upload"}`);
      }
    }
    if (novos.length) set({ anexos: [...state.anexos, ...novos] });
    clearInterval(ticker);
    setProgress(100);
    if (okCount) toast.success(`${okCount} arquivo${okCount > 1 ? "s" : ""} enviado${okCount > 1 ? "s" : ""}`);
    setTimeout(() => {
      setBusy(false);
      setProgress(0);
    }, 600);
  };

  const remove = (u: string) => set({ anexos: state.anexos.filter((a) => a.uid !== u) });
  const update = (u: string, patch: Partial<AnexoTemp>) =>
    set({ anexos: state.anexos.map((a) => (a.uid === u ? { ...a, ...patch } : a)) });

  return (
    <div className="space-y-4">
      <div className="grid gap-3 sm:grid-cols-2">
        <div>
          <Label>Categoria padrão para os próximos uploads</Label>
          <Select value={categoria} onValueChange={setCategoria}>
            <SelectTrigger><SelectValue /></SelectTrigger>
            <SelectContent>{CATEGORIAS_ANEXO.map((c) => <SelectItem key={c} value={c}>{c}</SelectItem>)}</SelectContent>
          </Select>
        </div>
        <div>
          <Label>Vincular a item (opcional)</Label>
          <Select value={itemUid || "none"} onValueChange={(v) => setItemUid(v === "none" ? "" : v)}>
            <SelectTrigger><SelectValue /></SelectTrigger>
            <SelectContent>
              <SelectItem value="none">— pedido inteiro —</SelectItem>
              {state.itens.map((it, i) => (
                <SelectItem key={it.uid} value={it.uid}>{it.tecnica} #{i + 1}</SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>
      </div>

      <div
        onDragOver={(e) => { e.preventDefault(); setDragOver(true); }}
        onDragLeave={() => setDragOver(false)}
        onDrop={(e) => {
          e.preventDefault();
          setDragOver(false);
          if (busy) return;
          if (e.dataTransfer.files?.length) void handleFiles(e.dataTransfer.files);
        }}
        onClick={() => !busy && inputRef.current?.click()}
        className={cn(
          "flex cursor-pointer flex-col items-center justify-center rounded-xl border-2 border-dashed p-8 text-center transition",
          dragOver ? "border-primary bg-primary/5" : "border-border bg-card/40 hover:border-primary/60 hover:bg-card",
          busy && "cursor-wait opacity-70",
        )}
      >
        <UploadCloud className={cn("mb-2 h-8 w-8", dragOver ? "text-primary" : "text-muted-foreground")} />
        <p className="text-sm font-medium">Arraste e solte arquivos aqui</p>
        <p className="text-xs text-muted-foreground">
          ou <span className="text-primary underline">clique para selecionar</span> · múltiplos arquivos · até 25 MB cada
        </p>
        <p className="mt-1 text-[11px] text-muted-foreground">
          Formatos: PDF, PNG, JPG, SVG, AI, CDR, EPS, DST, PES e outros
        </p>
        <input
          ref={inputRef}
          type="file"
          multiple
          className="hidden"
          disabled={busy}
          onChange={(e) => {
            if (e.target.files?.length) void handleFiles(e.target.files);
            e.target.value = "";
          }}
        />
      </div>

      <div className="flex flex-wrap gap-2">
        <Button
          type="button"
          variant="outline"
          size="sm"
          disabled={busy}
          onClick={async () => {
            try {
              const r = await capturePhoto("camera");
              if (r) await handleFiles([r.file]);
            } catch (e) {
              toast.error(e instanceof Error ? e.message : "Falha ao acessar câmera");
            }
          }}
        >
          <Camera className="mr-1 h-4 w-4" /> Tirar foto
        </Button>
        <Button
          type="button"
          variant="outline"
          size="sm"
          disabled={busy}
          onClick={async () => {
            try {
              const r = await capturePhoto("gallery");
              if (r) await handleFiles([r.file]);
            } catch (e) {
              toast.error(e instanceof Error ? e.message : "Falha ao abrir galeria");
            }
          }}
        >
          <UploadCloud className="mr-1 h-4 w-4" /> Galeria
        </Button>
      </div>

      {busy && (
        <div className="space-y-1">
          <Progress value={progress} />
          <p className="flex items-center gap-1 text-xs text-muted-foreground">
            <Loader2 className="h-3 w-3 animate-spin" /> Enviando… {progress}%
          </p>
        </div>
      )}

      {state.anexos.length === 0 ? (
        <p className="rounded-lg border border-dashed border-border bg-muted/20 p-6 text-center text-sm text-muted-foreground">
          Nenhum arquivo anexado ainda.
        </p>
      ) : (
        <ul className="space-y-2">
          {state.anexos.map((a) => (
            <li key={a.uid} className="flex flex-wrap items-center gap-3 rounded-lg border border-border bg-card p-3">
              <FileText className="h-4 w-4 shrink-0 text-muted-foreground" />
              <div className="min-w-0 flex-1">
                <p className="truncate text-sm font-medium">{a.nome}</p>
                <p className="text-xs text-muted-foreground">
                  {a.categoria}
                  {a.item_uid && ` · item ${state.itens.findIndex((i) => i.uid === a.item_uid) + 1}`}
                  {a.tamanho && ` · ${(a.tamanho / 1024).toFixed(0)} KB`}
                </p>
              </div>
              <Select value={a.status} onValueChange={(v) => update(a.uid, { status: v })}>
                <SelectTrigger className="h-8 w-36 text-xs"><SelectValue /></SelectTrigger>
                <SelectContent>{STATUS_ANEXO.map((s) => <SelectItem key={s} value={s}>{s}</SelectItem>)}</SelectContent>
              </Select>
              <Input
                className="h-8 w-48 text-xs"
                placeholder="Descrição"
                value={a.descricao}
                onChange={(e) => update(a.uid, { descricao: e.target.value })}
              />
              <a href={a.url} target="_blank" rel="noreferrer" className="text-info">
                <ExternalLink className="h-4 w-4" />
              </a>
              <Button size="icon" variant="ghost" onClick={() => remove(a.uid)}>
                <Trash2 className="h-4 w-4 text-destructive" />
              </Button>
            </li>
          ))}
        </ul>
      )}

      <p className="flex items-center gap-1 text-xs text-muted-foreground">
        <Upload className="h-3 w-3" /> Arquivos podem ser adicionados depois pela tela de Arquivos vinculando ao pedido.
      </p>
    </div>
  );
}
