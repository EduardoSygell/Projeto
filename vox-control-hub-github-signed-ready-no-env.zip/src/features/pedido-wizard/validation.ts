import type { WizardState } from "./types";

export type StepErrors = Record<number, string[]>;

/**
 * Validação centralizada por etapa.
 * Retorna um mapa { etapa: [erros] } e o conjunto de etapas inválidas.
 */
export function validateWizard(state: WizardState): { errors: StepErrors; invalidSteps: Set<number>; firstInvalidStep: number | null } {
  const errors: StepErrors = { 1: [], 2: [], 3: [], 4: [], 5: [], 6: [], 7: [] };

  // 1. Cliente
  if (state.cliente.modo === "existente" && !state.cliente.cliente_id) {
    errors[1].push("Selecione um cliente existente");
  }
  if (!state.cliente.nome.trim()) errors[1].push("Nome do cliente é obrigatório");
  if (state.cliente.email && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(state.cliente.email)) {
    errors[1].push("E-mail inválido");
  }

  // 2. Pedido
  if (!state.pedido.codigo.trim()) errors[2].push("Código do pedido é obrigatório");
  if (state.pedido.data_entrega && state.pedido.data_limite_producao &&
      state.pedido.data_limite_producao > state.pedido.data_entrega) {
    errors[2].push("Limite de produção não pode ser depois da entrega");
  }

  // 3. Técnicas
  if (state.itens.length === 0) errors[3].push("Adicione pelo menos um item/técnica");

  // 4. Fichas (descrição + qtd válida)
  state.itens.forEach((it, i) => {
    if (!it.descricao.trim()) errors[4].push(`Item #${i + 1}: descrição obrigatória`);
    if (!it.quantidade || it.quantidade < 1) errors[4].push(`Item #${i + 1}: quantidade ≥ 1`);
  });

  // 6. Precificação
  if (!state.precificacao.forma_pagamento) errors[6].push("Selecione forma de pagamento");
  state.itens.forEach((it, i) => {
    const unit = it.override_unit ?? it.preco_sugerido ?? 0;
    if (unit <= 0) errors[6].push(`Item #${i + 1}: defina um preço unitário`);
  });

  const invalidSteps = new Set<number>();
  let firstInvalidStep: number | null = null;
  for (const k of Object.keys(errors)) {
    const n = Number(k);
    if (errors[n].length > 0) {
      invalidSteps.add(n);
      if (firstInvalidStep === null) firstInvalidStep = n;
    }
  }
  return { errors, invalidSteps, firstInvalidStep };
}
