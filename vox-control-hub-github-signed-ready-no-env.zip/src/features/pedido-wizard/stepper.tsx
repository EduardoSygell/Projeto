import { Check, AlertCircle } from "lucide-react";
import { cn } from "@/lib/utils";

export const STEPS = [
  { id: 1, label: "Cliente" },
  { id: 2, label: "Pedido" },
  { id: 3, label: "Técnicas" },
  { id: 4, label: "Fichas" },
  { id: 5, label: "Arquivos" },
  { id: 6, label: "Preço" },
  { id: 7, label: "Resumo" },
] as const;

export function Stepper({
  current,
  onJump,
  invalidSteps,
}: {
  current: number;
  onJump: (n: number) => void;
  invalidSteps?: Set<number>;
}) {
  const progressPct = Math.round(((current - 1) / (STEPS.length - 1)) * 100);
  return (
    <div className="space-y-2">
      <div className="h-1 w-full overflow-hidden rounded-full bg-muted">
        <div
          className="h-full rounded-full bg-gradient-to-r from-primary to-info transition-all"
          style={{ width: `${progressPct}%` }}
        />
      </div>
      <ol className="flex w-full items-center gap-1 overflow-x-auto rounded-xl border border-border bg-card p-2">
        {STEPS.map((s, idx) => {
          const done = current > s.id;
          const active = current === s.id;
          const invalid = invalidSteps?.has(s.id);
          return (
            <li key={s.id} className="flex flex-1 min-w-[80px] items-center gap-1">
              <button
                onClick={() => onJump(s.id)}
                aria-current={active ? "step" : undefined}
                className={cn(
                  "flex w-full items-center gap-2 rounded-lg px-3 py-2 text-left text-xs font-medium transition",
                  active && "bg-primary/15 text-primary",
                  done && !active && !invalid && "text-success",
                  invalid && !active && "text-destructive",
                  !active && !done && !invalid && "text-muted-foreground hover:bg-muted/40",
                )}
              >
                <span
                  className={cn(
                    "flex h-6 w-6 shrink-0 items-center justify-center rounded-full border text-[11px]",
                    active && "border-primary bg-primary text-primary-foreground",
                    done && !active && !invalid && "border-success bg-success/20 text-success",
                    invalid && !active && "border-destructive bg-destructive/15 text-destructive",
                    !active && !done && !invalid && "border-border",
                  )}
                >
                  {invalid && !active ? <AlertCircle className="h-3 w-3" /> : done ? <Check className="h-3 w-3" /> : s.id}
                </span>
                <span className="hidden sm:inline truncate">{s.label}</span>
              </button>
              {idx < STEPS.length - 1 && <span className="hidden md:inline h-px w-2 bg-border" />}
            </li>
          );
        })}
      </ol>
    </div>
  );
}
