import type { Database } from "@/integrations/supabase/types";

export type Tecnica = Database["public"]["Enums"]["tecnica_producao"];
export type Prioridade = Database["public"]["Enums"]["prioridade"];

export type ClienteForm = {
  modo: "novo" | "existente";
  cliente_id?: string;
  nome: string;
  documento: string;
  telefone: string;
  email: string;
  endereco: string;
  tipo: "PF" | "EMPRESA" | "REVENDEDOR" | "RECORRENTE" | "VIP";
  status: "ATIVO" | "INADIMPLENTE" | "EM_ANALISE" | "BLOQUEADO";
  observacoes: string;
  atencoes_producao: string;
  origem: string;
};

export type DadosPedido = {
  codigo: string;
  data_entrega: string;
  data_limite_producao: string;
  prioridade: Prioridade;
  origem: string;
  observacoes: string;
};

export type FichaDTF = {
  metros: number;
  largura_filme: string;
  tipo_filme: string;
  perfil_cor: string;
  tinta_branca_ml: number;
  tinta_cmyk_ml: number;
  poliamida_g: number;
  temperatura: number;
  tempo_cura: number;
  tempo_prensa: number;
  maquina: string;
  perda_pct: number;
  observacoes: string;
};

export type FichaDTG = {
  tinta_branca_ml: number;
  tinta_cmyk_ml: number;
  pre_tratamento: boolean;
  custo_pretratamento_un: number;
  tipo_tecido: string;
  cor_peca: string;
  perfil_impressao: string;
  temperatura: number;
  tempo_cura: number;
  maquina: string;
  perda_pct: number;
  observacoes: string;
};

export type FichaBordado = {
  pontos: number;
  tempo_min: number;
  num_cores: number;
  codigos_linha: string;
  tipo_linha: string;
  tipo_entretela: string;
  bastidor: string;
  agulha: string;
  maquina: string;
  ocorrencias: string[];
  perda_pct: number;
  observacoes: string;
};

export type FichaPrensa = {
  temperatura: number;
  tempo_prensa: number;
  tipo_tecido: string;
  observacoes: string;
};

export type ItemTecnica = {
  uid: string;
  tecnica: Tecnica;
  descricao: string;
  quantidade: number;
  custo_peca: number;
  ficha_dtf?: FichaDTF;
  ficha_dtg?: FichaDTG;
  ficha_bordado?: FichaBordado;
  ficha_prensa?: FichaPrensa;
  custo_calc?: number;
  preco_sugerido?: number;
  preco_unit?: number;
  // Override do usuário
  override_unit?: number;
};

export type AnexoTemp = {
  uid: string;
  nome: string;
  url: string;
  tipo: string | null;
  tamanho: number | null;
  categoria: string;
  status: string;
  descricao: string;
  item_uid?: string;
};

export type WizardState = {
  cliente: ClienteForm;
  pedido: DadosPedido;
  itens: ItemTecnica[];
  anexos: AnexoTemp[];
  precificacao: {
    margem_pct: number;
    desconto: number;
    acrescimo: number;
    entrada: number;
    forma_pagamento: string;
  };
  validade_dias: number;
};

export const CATEGORIAS_ANEXO = [
  "ORIGINAL_CLIENTE",
  "ARTE_TRATADA",
  "MOCKUP",
  "MATRIZ",
  "PRONTO_PRODUCAO",
  "COMPROVANTE",
  "FOTO_PECA",
  "REFERENCIA",
  "OUTRO",
] as const;

export const STATUS_ANEXO = [
  "RECEBIDO",
  "EM_ANALISE",
  "AJUSTE",
  "APROVADO",
  "PRONTO",
  "SUBSTITUIDO",
] as const;

export const ORIGENS = ["WHATSAPP", "INDICACAO", "LOJA", "INSTAGRAM", "RECORRENTE", "OUTRO"];
