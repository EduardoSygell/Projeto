import { useQuery } from "@tanstack/react-query";
import { useWizard } from "./wizard-context";
import { db } from "@/lib/db";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Button } from "@/components/ui/button";
import { ORIGENS } from "./types";

export function StepCliente() {
  const { state, patch } = useWizard();
  const c = state.cliente;

  const { data: clientes = [] } = useQuery({
    queryKey: ["wiz-clientes"],
    queryFn: async () => {
      const { data, error } = await db.from("clientes").select("*").order("nome");
      if (error) throw error;
      return data;
    },
  });

  return (
    <div className="space-y-4">
      <div className="flex gap-2">
        <Button variant={c.modo === "novo" ? "default" : "outline"} size="sm" onClick={() => patch("cliente", { modo: "novo", cliente_id: undefined })}>+ Novo cliente</Button>
        <Button variant={c.modo === "existente" ? "default" : "outline"} size="sm" onClick={() => patch("cliente", { modo: "existente" })}>Selecionar existente</Button>
      </div>

      {c.modo === "existente" && (
        <div>
          <Label>Cliente *</Label>
          <Select
            value={c.cliente_id ?? ""}
            onValueChange={(v) => {
              const cli = clientes.find((x) => x.id === v);
              patch("cliente", {
                cliente_id: v,
                nome: cli?.nome ?? "",
                documento: cli?.documento ?? "",
                telefone: cli?.telefone ?? "",
                email: cli?.email ?? "",
                endereco: cli?.endereco ?? "",
                observacoes: cli?.observacoes ?? "",
              });
            }}
          >
            <SelectTrigger><SelectValue placeholder="Buscar…" /></SelectTrigger>
            <SelectContent>{clientes.map((x) => <SelectItem key={x.id} value={x.id}>{x.nome}</SelectItem>)}</SelectContent>
          </Select>
        </div>
      )}

      <div className="grid gap-3 sm:grid-cols-2">
        <div className="sm:col-span-2"><Label>Nome / Razão social *</Label><Input value={c.nome} onChange={(e) => patch("cliente", { nome: e.target.value })} /></div>
        <div><Label>CPF / CNPJ</Label><Input value={c.documento} onChange={(e) => patch("cliente", { documento: e.target.value })} /></div>
        <div><Label>Telefone / WhatsApp</Label><Input value={c.telefone} onChange={(e) => patch("cliente", { telefone: e.target.value })} /></div>
        <div className="sm:col-span-2"><Label>E-mail</Label><Input type="email" value={c.email} onChange={(e) => patch("cliente", { email: e.target.value })} /></div>
        <div className="sm:col-span-2"><Label>Endereço</Label><Input value={c.endereco} onChange={(e) => patch("cliente", { endereco: e.target.value })} /></div>
        <div>
          <Label>Tipo</Label>
          <Select value={c.tipo} onValueChange={(v) => patch("cliente", { tipo: v as typeof c.tipo })}>
            <SelectTrigger><SelectValue /></SelectTrigger>
            <SelectContent>
              {(["PF", "EMPRESA", "REVENDEDOR", "RECORRENTE", "VIP"] as const).map((t) => <SelectItem key={t} value={t}>{t}</SelectItem>)}
            </SelectContent>
          </Select>
        </div>
        <div>
          <Label>Status</Label>
          <Select value={c.status} onValueChange={(v) => patch("cliente", { status: v as typeof c.status })}>
            <SelectTrigger><SelectValue /></SelectTrigger>
            <SelectContent>
              {(["ATIVO", "INADIMPLENTE", "EM_ANALISE", "BLOQUEADO"] as const).map((t) => <SelectItem key={t} value={t}>{t}</SelectItem>)}
            </SelectContent>
          </Select>
        </div>
        <div>
          <Label>Origem</Label>
          <Select value={c.origem} onValueChange={(v) => patch("cliente", { origem: v })}>
            <SelectTrigger><SelectValue placeholder="—" /></SelectTrigger>
            <SelectContent>{ORIGENS.map((o) => <SelectItem key={o} value={o}>{o}</SelectItem>)}</SelectContent>
          </Select>
        </div>
        <div className="sm:col-span-2"><Label>Atenções antes de produzir</Label><Textarea rows={2} value={c.atencoes_producao} onChange={(e) => patch("cliente", { atencoes_producao: e.target.value })} /></div>
        <div className="sm:col-span-2"><Label>Observações internas</Label><Textarea rows={2} value={c.observacoes} onChange={(e) => patch("cliente", { observacoes: e.target.value })} /></div>
      </div>
    </div>
  );
}
