import { useWizard } from "./wizard-context";
import { Button } from "@/components/ui/button";
import { FileDown, CheckCircle2 } from "lucide-react";
import { gerarOrcamentoPDF } from "@/lib/orcamento-pdf";
import { totalPedido } from "./pricing-engine";
import { usePrecificacaoConfig } from "@/hooks/use-precificacao-config";

const brl = (n: number) => Number(n).toLocaleString("pt-BR", { style: "currency", currency: "BRL" });

export function StepResumo() {
  const { state } = useWizard();
  const { pagamentos } = usePrecificacaoConfig();
  const formaLabel = pagamentos.find((p) => p.chave === state.precificacao.forma_pagamento)?.label
    ?? state.precificacao.forma_pagamento;
  const itensTot = state.itens.map((it) => ({
    valorTotal: ((it.override_unit ?? it.preco_sugerido ?? 0) * it.quantidade),
  }));
  const t = totalPedido(itensTot, {
    desconto: state.precificacao.desconto,
    acrescimo: state.precificacao.acrescimo,
    entrada: state.precificacao.entrada,
  });

  return (
    <div className="space-y-4">
      <div className="rounded-xl border border-border bg-card p-5">
        <div className="flex items-center justify-between">
          <div>
            <p className="text-xs uppercase text-muted-foreground">Orçamento</p>
            <h3 className="text-xl font-bold">{state.pedido.codigo}</h3>
          </div>
          <Button variant="outline" onClick={() => { void gerarOrcamentoPDF(state); }}>
            <FileDown className="mr-2 h-4 w-4" /> Gerar PDF
          </Button>
        </div>
      </div>

      <div className="grid gap-4 lg:grid-cols-2">
        <Card title="Cliente">
          <p className="font-medium">{state.cliente.nome || "—"}</p>
          <p className="text-xs text-muted-foreground">{state.cliente.documento} · {state.cliente.telefone}</p>
          <p className="text-xs text-muted-foreground">{state.cliente.email}</p>
          <p className="mt-1 text-xs"><span className="text-muted-foreground">Tipo:</span> {state.cliente.tipo} · <span className="text-muted-foreground">Status:</span> {state.cliente.status}</p>
        </Card>
        <Card title="Pedido">
          <p className="text-xs"><span className="text-muted-foreground">Entrega:</span> {state.pedido.data_entrega || "—"}</p>
          <p className="text-xs"><span className="text-muted-foreground">Limite produção:</span> {state.pedido.data_limite_producao || "—"}</p>
          <p className="text-xs"><span className="text-muted-foreground">Prioridade:</span> {state.pedido.prioridade}</p>
          <p className="text-xs"><span className="text-muted-foreground">Origem:</span> {state.pedido.origem}</p>
        </Card>
      </div>

      <Card title={`Itens (${state.itens.length})`}>
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead className="text-xs uppercase text-muted-foreground"><tr><th className="text-left py-1">Técnica</th><th className="text-left">Descrição</th><th className="text-right">Qtd</th><th className="text-right">Unit.</th><th className="text-right">Total</th></tr></thead>
            <tbody>
              {state.itens.map((it) => {
                const u = it.override_unit ?? it.preco_sugerido ?? 0;
                return <tr key={it.uid} className="border-t border-border/60"><td className="py-1">{it.tecnica}</td><td>{it.descricao || "—"}</td><td className="text-right">{it.quantidade}</td><td className="text-right">{brl(u)}</td><td className="text-right font-medium">{brl(u * it.quantidade)}</td></tr>;
              })}
            </tbody>
          </table>
        </div>
      </Card>

      <Card title="Totais">
        <div className="grid gap-1 sm:grid-cols-2 text-sm">
          <Linha label="Subtotal" value={brl(t.subtotal)} />
          <Linha label="Desconto" value={brl(state.precificacao.desconto)} />
          <Linha label="Acréscimo" value={brl(state.precificacao.acrescimo)} />
          <Linha label="Total" value={brl(t.total)} bold />
          <Linha label="Entrada" value={brl(t.entrada)} />
          <Linha label="Saldo" value={brl(t.saldo)} bold />
        </div>
        <p className="mt-2 text-xs text-muted-foreground">Forma: {formaLabel} · Validade {state.validade_dias} dias</p>
      </Card>

      <Card title={`Arquivos anexados (${state.anexos.length})`}>
        {state.anexos.length === 0 ? <p className="text-xs text-muted-foreground">Nenhum.</p> : (
          <ul className="text-xs space-y-1">
            {state.anexos.map((a) => <li key={a.uid} className="flex items-center gap-2"><CheckCircle2 className="h-3 w-3 text-success" /> {a.nome} <span className="text-muted-foreground">· {a.categoria} · {a.status}</span></li>)}
          </ul>
        )}
      </Card>
    </div>
  );
}

function Card({ title, children }: { title: string; children: React.ReactNode }) {
  return <div className="rounded-xl border border-border bg-card p-5"><h4 className="mb-3 text-sm font-semibold">{title}</h4>{children}</div>;
}
function Linha({ label, value, bold }: { label: string; value: string; bold?: boolean }) {
  return <div className={`flex justify-between ${bold ? "font-semibold" : "text-muted-foreground"}`}><span>{label}</span><span>{value}</span></div>;
}
