export type Json =
  | string
  | number
  | boolean
  | null
  | { [key: string]: Json | undefined }
  | Json[]

export type Database = {
  // Allows to automatically instantiate createClient with right options
  // instead of createClient<Database, { PostgrestVersion: 'XX' }>(URL, KEY)
  __InternalSupabase: {
    PostgrestVersion: "14.5"
  }
  public: {
    Tables: {
      anexos: {
        Row: {
          arte_id: string | null
          categoria: string | null
          cliente_id: string | null
          created_at: string
          descricao: string | null
          id: string
          item_id: string | null
          nome: string
          pedido_id: string | null
          status: string | null
          tamanho_bytes: number | null
          tipo: string | null
          uploaded_by: string | null
          url: string
        }
        Insert: {
          arte_id?: string | null
          categoria?: string | null
          cliente_id?: string | null
          created_at?: string
          descricao?: string | null
          id?: string
          item_id?: string | null
          nome: string
          pedido_id?: string | null
          status?: string | null
          tamanho_bytes?: number | null
          tipo?: string | null
          uploaded_by?: string | null
          url: string
        }
        Update: {
          arte_id?: string | null
          categoria?: string | null
          cliente_id?: string | null
          created_at?: string
          descricao?: string | null
          id?: string
          item_id?: string | null
          nome?: string
          pedido_id?: string | null
          status?: string | null
          tamanho_bytes?: number | null
          tipo?: string | null
          uploaded_by?: string | null
          url?: string
        }
        Relationships: [
          {
            foreignKeyName: "anexos_arte_id_fkey"
            columns: ["arte_id"]
            isOneToOne: false
            referencedRelation: "artes"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "anexos_cliente_id_fkey"
            columns: ["cliente_id"]
            isOneToOne: false
            referencedRelation: "clientes"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "anexos_pedido_id_fkey"
            columns: ["pedido_id"]
            isOneToOne: false
            referencedRelation: "pedidos"
            referencedColumns: ["id"]
          },
        ]
      }
      aprovacoes_arte: {
        Row: {
          arte_id: string
          created_at: string
          created_by: string | null
          enviado_em: string | null
          feedback: string | null
          id: string
          respondido_em: string | null
          respondido_por: string | null
          status: Database["public"]["Enums"]["status_arte"]
        }
        Insert: {
          arte_id: string
          created_at?: string
          created_by?: string | null
          enviado_em?: string | null
          feedback?: string | null
          id?: string
          respondido_em?: string | null
          respondido_por?: string | null
          status: Database["public"]["Enums"]["status_arte"]
        }
        Update: {
          arte_id?: string
          created_at?: string
          created_by?: string | null
          enviado_em?: string | null
          feedback?: string | null
          id?: string
          respondido_em?: string | null
          respondido_por?: string | null
          status?: Database["public"]["Enums"]["status_arte"]
        }
        Relationships: [
          {
            foreignKeyName: "aprovacoes_arte_arte_id_fkey"
            columns: ["arte_id"]
            isOneToOne: false
            referencedRelation: "artes"
            referencedColumns: ["id"]
          },
        ]
      }
      artes: {
        Row: {
          arquivo_url: string | null
          created_at: string
          created_by: string | null
          id: string
          item_id: string | null
          nome: string
          pedido_id: string
          status: Database["public"]["Enums"]["status_arte"]
          updated_at: string
          versao: number
        }
        Insert: {
          arquivo_url?: string | null
          created_at?: string
          created_by?: string | null
          id?: string
          item_id?: string | null
          nome: string
          pedido_id: string
          status?: Database["public"]["Enums"]["status_arte"]
          updated_at?: string
          versao?: number
        }
        Update: {
          arquivo_url?: string | null
          created_at?: string
          created_by?: string | null
          id?: string
          item_id?: string | null
          nome?: string
          pedido_id?: string
          status?: Database["public"]["Enums"]["status_arte"]
          updated_at?: string
          versao?: number
        }
        Relationships: [
          {
            foreignKeyName: "artes_item_id_fkey"
            columns: ["item_id"]
            isOneToOne: false
            referencedRelation: "itens_pedido"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "artes_pedido_id_fkey"
            columns: ["pedido_id"]
            isOneToOne: false
            referencedRelation: "pedidos"
            referencedColumns: ["id"]
          },
        ]
      }
      calendario_eventos: {
        Row: {
          cor: string | null
          created_at: string
          descricao: string | null
          fim: string | null
          id: string
          inicio: string
          maquina_id: string | null
          pedido_id: string | null
          responsavel_id: string | null
          tipo: string | null
          titulo: string
        }
        Insert: {
          cor?: string | null
          created_at?: string
          descricao?: string | null
          fim?: string | null
          id?: string
          inicio: string
          maquina_id?: string | null
          pedido_id?: string | null
          responsavel_id?: string | null
          tipo?: string | null
          titulo: string
        }
        Update: {
          cor?: string | null
          created_at?: string
          descricao?: string | null
          fim?: string | null
          id?: string
          inicio?: string
          maquina_id?: string | null
          pedido_id?: string | null
          responsavel_id?: string | null
          tipo?: string | null
          titulo?: string
        }
        Relationships: [
          {
            foreignKeyName: "calendario_eventos_maquina_id_fkey"
            columns: ["maquina_id"]
            isOneToOne: false
            referencedRelation: "maquinas"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "calendario_eventos_pedido_id_fkey"
            columns: ["pedido_id"]
            isOneToOne: false
            referencedRelation: "pedidos"
            referencedColumns: ["id"]
          },
        ]
      }
      clientes: {
        Row: {
          atencoes_producao: string | null
          created_at: string
          created_by: string | null
          documento: string | null
          email: string | null
          endereco: string | null
          id: string
          nome: string
          observacoes: string | null
          origem: string | null
          status: string | null
          telefone: string | null
          tipo: string | null
          updated_at: string
        }
        Insert: {
          atencoes_producao?: string | null
          created_at?: string
          created_by?: string | null
          documento?: string | null
          email?: string | null
          endereco?: string | null
          id?: string
          nome: string
          observacoes?: string | null
          origem?: string | null
          status?: string | null
          telefone?: string | null
          tipo?: string | null
          updated_at?: string
        }
        Update: {
          atencoes_producao?: string | null
          created_at?: string
          created_by?: string | null
          documento?: string | null
          email?: string | null
          endereco?: string | null
          id?: string
          nome?: string
          observacoes?: string | null
          origem?: string | null
          status?: string | null
          telefone?: string | null
          tipo?: string | null
          updated_at?: string
        }
        Relationships: []
      }
      config_precificacao: {
        Row: {
          categoria: string
          chave: string
          descricao: string | null
          id: string
          updated_at: string
          valor: number
        }
        Insert: {
          categoria: string
          chave: string
          descricao?: string | null
          id?: string
          updated_at?: string
          valor?: number
        }
        Update: {
          categoria?: string
          chave?: string
          descricao?: string | null
          id?: string
          updated_at?: string
          valor?: number
        }
        Relationships: []
      }
      estoque_itens: {
        Row: {
          categoria: string
          created_at: string
          custo_unitario: number | null
          fornecedor: string | null
          id: string
          nome: string
          quantidade: number
          quantidade_minima: number
          unidade: string
          updated_at: string
        }
        Insert: {
          categoria: string
          created_at?: string
          custo_unitario?: number | null
          fornecedor?: string | null
          id?: string
          nome: string
          quantidade?: number
          quantidade_minima?: number
          unidade?: string
          updated_at?: string
        }
        Update: {
          categoria?: string
          created_at?: string
          custo_unitario?: number | null
          fornecedor?: string | null
          id?: string
          nome?: string
          quantidade?: number
          quantidade_minima?: number
          unidade?: string
          updated_at?: string
        }
        Relationships: []
      }
      estoque_movimentacoes: {
        Row: {
          created_at: string
          id: string
          item_id: string
          motivo: string | null
          pedido_id: string | null
          quantidade: number
          responsavel_id: string | null
          tipo: Database["public"]["Enums"]["tipo_movimento_estoque"]
        }
        Insert: {
          created_at?: string
          id?: string
          item_id: string
          motivo?: string | null
          pedido_id?: string | null
          quantidade: number
          responsavel_id?: string | null
          tipo: Database["public"]["Enums"]["tipo_movimento_estoque"]
        }
        Update: {
          created_at?: string
          id?: string
          item_id?: string
          motivo?: string | null
          pedido_id?: string | null
          quantidade?: number
          responsavel_id?: string | null
          tipo?: Database["public"]["Enums"]["tipo_movimento_estoque"]
        }
        Relationships: [
          {
            foreignKeyName: "estoque_movimentacoes_item_id_fkey"
            columns: ["item_id"]
            isOneToOne: false
            referencedRelation: "estoque_itens"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "estoque_movimentacoes_pedido_id_fkey"
            columns: ["pedido_id"]
            isOneToOne: false
            referencedRelation: "pedidos"
            referencedColumns: ["id"]
          },
        ]
      }
      etapas_producao: {
        Row: {
          concluida_em: string | null
          created_at: string
          id: string
          iniciada_em: string | null
          nome: string
          observacoes: string | null
          ordem_id: string
          ordem_sequencia: number
          responsavel_id: string | null
          status: Database["public"]["Enums"]["status_ordem"]
        }
        Insert: {
          concluida_em?: string | null
          created_at?: string
          id?: string
          iniciada_em?: string | null
          nome: string
          observacoes?: string | null
          ordem_id: string
          ordem_sequencia?: number
          responsavel_id?: string | null
          status?: Database["public"]["Enums"]["status_ordem"]
        }
        Update: {
          concluida_em?: string | null
          created_at?: string
          id?: string
          iniciada_em?: string | null
          nome?: string
          observacoes?: string | null
          ordem_id?: string
          ordem_sequencia?: number
          responsavel_id?: string | null
          status?: Database["public"]["Enums"]["status_ordem"]
        }
        Relationships: [
          {
            foreignKeyName: "etapas_producao_ordem_id_fkey"
            columns: ["ordem_id"]
            isOneToOne: false
            referencedRelation: "ordens_producao"
            referencedColumns: ["id"]
          },
        ]
      }
      fichas_tecnicas: {
        Row: {
          arquivo_arte_url: string | null
          created_at: string
          dados: Json
          id: string
          item_id: string | null
          mockup_url: string | null
          pedido_id: string
          status_arte: string | null
          tecnica: string
          updated_at: string
        }
        Insert: {
          arquivo_arte_url?: string | null
          created_at?: string
          dados?: Json
          id?: string
          item_id?: string | null
          mockup_url?: string | null
          pedido_id: string
          status_arte?: string | null
          tecnica: string
          updated_at?: string
        }
        Update: {
          arquivo_arte_url?: string | null
          created_at?: string
          dados?: Json
          id?: string
          item_id?: string | null
          mockup_url?: string | null
          pedido_id?: string
          status_arte?: string | null
          tecnica?: string
          updated_at?: string
        }
        Relationships: []
      }
      fila_sincronizacao: {
        Row: {
          created_at: string
          id: string
          payload: Json
          processado_em: string | null
          status: string
          tentativas: number
          tipo: string
          ultimo_erro: string | null
        }
        Insert: {
          created_at?: string
          id?: string
          payload: Json
          processado_em?: string | null
          status?: string
          tentativas?: number
          tipo: string
          ultimo_erro?: string | null
        }
        Update: {
          created_at?: string
          id?: string
          payload?: Json
          processado_em?: string | null
          status?: string
          tentativas?: number
          tipo?: string
          ultimo_erro?: string | null
        }
        Relationships: []
      }
      filas_maquina: {
        Row: {
          created_at: string
          id: string
          maquina_id: string
          ordem_id: string
          posicao: number
        }
        Insert: {
          created_at?: string
          id?: string
          maquina_id: string
          ordem_id: string
          posicao?: number
        }
        Update: {
          created_at?: string
          id?: string
          maquina_id?: string
          ordem_id?: string
          posicao?: number
        }
        Relationships: [
          {
            foreignKeyName: "filas_maquina_maquina_id_fkey"
            columns: ["maquina_id"]
            isOneToOne: false
            referencedRelation: "maquinas"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "filas_maquina_ordem_id_fkey"
            columns: ["ordem_id"]
            isOneToOne: false
            referencedRelation: "ordens_producao"
            referencedColumns: ["id"]
          },
        ]
      }
      financeiro_pagar: {
        Row: {
          categoria: string | null
          created_at: string
          descricao: string
          fornecedor: string | null
          id: string
          metodo_pagamento: string | null
          pago_em: string | null
          status: Database["public"]["Enums"]["status_pagamento"]
          updated_at: string
          valor: number
          vencimento: string
        }
        Insert: {
          categoria?: string | null
          created_at?: string
          descricao: string
          fornecedor?: string | null
          id?: string
          metodo_pagamento?: string | null
          pago_em?: string | null
          status?: Database["public"]["Enums"]["status_pagamento"]
          updated_at?: string
          valor: number
          vencimento: string
        }
        Update: {
          categoria?: string | null
          created_at?: string
          descricao?: string
          fornecedor?: string | null
          id?: string
          metodo_pagamento?: string | null
          pago_em?: string | null
          status?: Database["public"]["Enums"]["status_pagamento"]
          updated_at?: string
          valor?: number
          vencimento?: string
        }
        Relationships: []
      }
      financeiro_receber: {
        Row: {
          cliente_id: string | null
          created_at: string
          descricao: string
          id: string
          metodo_pagamento: string | null
          pago_em: string | null
          pedido_id: string | null
          status: Database["public"]["Enums"]["status_pagamento"]
          updated_at: string
          valor: number
          vencimento: string
        }
        Insert: {
          cliente_id?: string | null
          created_at?: string
          descricao: string
          id?: string
          metodo_pagamento?: string | null
          pago_em?: string | null
          pedido_id?: string | null
          status?: Database["public"]["Enums"]["status_pagamento"]
          updated_at?: string
          valor: number
          vencimento: string
        }
        Update: {
          cliente_id?: string | null
          created_at?: string
          descricao?: string
          id?: string
          metodo_pagamento?: string | null
          pago_em?: string | null
          pedido_id?: string | null
          status?: Database["public"]["Enums"]["status_pagamento"]
          updated_at?: string
          valor?: number
          vencimento?: string
        }
        Relationships: [
          {
            foreignKeyName: "financeiro_receber_cliente_id_fkey"
            columns: ["cliente_id"]
            isOneToOne: false
            referencedRelation: "clientes"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "financeiro_receber_pedido_id_fkey"
            columns: ["pedido_id"]
            isOneToOne: false
            referencedRelation: "pedidos"
            referencedColumns: ["id"]
          },
        ]
      }
      itens_pedido: {
        Row: {
          cor: string | null
          created_at: string
          descricao: string
          id: string
          observacoes: string | null
          pedido_id: string
          quantidade: number
          tamanho: string | null
          tecido: Database["public"]["Enums"]["tipo_tecido"] | null
          tecnica: Database["public"]["Enums"]["tecnica_producao"]
          valor_total_calculado: number | null
          valor_unitario: number
        }
        Insert: {
          cor?: string | null
          created_at?: string
          descricao: string
          id?: string
          observacoes?: string | null
          pedido_id: string
          quantidade: number
          tamanho?: string | null
          tecido?: Database["public"]["Enums"]["tipo_tecido"] | null
          tecnica: Database["public"]["Enums"]["tecnica_producao"]
          valor_total_calculado?: number | null
          valor_unitario?: number
        }
        Update: {
          cor?: string | null
          created_at?: string
          descricao?: string
          id?: string
          observacoes?: string | null
          pedido_id?: string
          quantidade?: number
          tamanho?: string | null
          tecido?: Database["public"]["Enums"]["tipo_tecido"] | null
          tecnica?: Database["public"]["Enums"]["tecnica_producao"]
          valor_total_calculado?: number | null
          valor_unitario?: number
        }
        Relationships: [
          {
            foreignKeyName: "itens_pedido_pedido_id_fkey"
            columns: ["pedido_id"]
            isOneToOne: false
            referencedRelation: "pedidos"
            referencedColumns: ["id"]
          },
        ]
      }
      logs_auditoria: {
        Row: {
          acao: string
          created_at: string
          entidade: string
          entidade_id: string | null
          id: string
          payload: Json | null
          user_id: string | null
        }
        Insert: {
          acao: string
          created_at?: string
          entidade: string
          entidade_id?: string | null
          id?: string
          payload?: Json | null
          user_id?: string | null
        }
        Update: {
          acao?: string
          created_at?: string
          entidade?: string
          entidade_id?: string | null
          id?: string
          payload?: Json | null
          user_id?: string | null
        }
        Relationships: []
      }
      manutencoes: {
        Row: {
          created_at: string
          custo: number | null
          data_prevista: string | null
          data_realizada: string | null
          descricao: string | null
          id: string
          maquina_id: string
          responsavel_id: string | null
          tipo: string
        }
        Insert: {
          created_at?: string
          custo?: number | null
          data_prevista?: string | null
          data_realizada?: string | null
          descricao?: string | null
          id?: string
          maquina_id: string
          responsavel_id?: string | null
          tipo: string
        }
        Update: {
          created_at?: string
          custo?: number | null
          data_prevista?: string | null
          data_realizada?: string | null
          descricao?: string | null
          id?: string
          maquina_id?: string
          responsavel_id?: string | null
          tipo?: string
        }
        Relationships: [
          {
            foreignKeyName: "manutencoes_maquina_id_fkey"
            columns: ["maquina_id"]
            isOneToOne: false
            referencedRelation: "maquinas"
            referencedColumns: ["id"]
          },
        ]
      }
      maquinas: {
        Row: {
          created_at: string
          fabricante: string | null
          id: string
          modelo: string | null
          nome: string
          observacoes: string | null
          status: Database["public"]["Enums"]["status_maquina"]
          tecnica: Database["public"]["Enums"]["tecnica_producao"]
          updated_at: string
        }
        Insert: {
          created_at?: string
          fabricante?: string | null
          id?: string
          modelo?: string | null
          nome: string
          observacoes?: string | null
          status?: Database["public"]["Enums"]["status_maquina"]
          tecnica: Database["public"]["Enums"]["tecnica_producao"]
          updated_at?: string
        }
        Update: {
          created_at?: string
          fabricante?: string | null
          id?: string
          modelo?: string | null
          nome?: string
          observacoes?: string | null
          status?: Database["public"]["Enums"]["status_maquina"]
          tecnica?: Database["public"]["Enums"]["tecnica_producao"]
          updated_at?: string
        }
        Relationships: []
      }
      ordens_producao: {
        Row: {
          concluida_em: string | null
          created_at: string
          id: string
          iniciada_em: string | null
          item_id: string | null
          maquina_id: string | null
          observacoes: string | null
          pedido_id: string
          prioridade: Database["public"]["Enums"]["prioridade"]
          responsavel_id: string | null
          status: Database["public"]["Enums"]["status_ordem"]
          tecnica: Database["public"]["Enums"]["tecnica_producao"]
          updated_at: string
        }
        Insert: {
          concluida_em?: string | null
          created_at?: string
          id?: string
          iniciada_em?: string | null
          item_id?: string | null
          maquina_id?: string | null
          observacoes?: string | null
          pedido_id: string
          prioridade?: Database["public"]["Enums"]["prioridade"]
          responsavel_id?: string | null
          status?: Database["public"]["Enums"]["status_ordem"]
          tecnica: Database["public"]["Enums"]["tecnica_producao"]
          updated_at?: string
        }
        Update: {
          concluida_em?: string | null
          created_at?: string
          id?: string
          iniciada_em?: string | null
          item_id?: string | null
          maquina_id?: string | null
          observacoes?: string | null
          pedido_id?: string
          prioridade?: Database["public"]["Enums"]["prioridade"]
          responsavel_id?: string | null
          status?: Database["public"]["Enums"]["status_ordem"]
          tecnica?: Database["public"]["Enums"]["tecnica_producao"]
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "ordens_producao_item_id_fkey"
            columns: ["item_id"]
            isOneToOne: false
            referencedRelation: "itens_pedido"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "ordens_producao_maquina_id_fkey"
            columns: ["maquina_id"]
            isOneToOne: false
            referencedRelation: "maquinas"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "ordens_producao_pedido_id_fkey"
            columns: ["pedido_id"]
            isOneToOne: false
            referencedRelation: "pedidos"
            referencedColumns: ["id"]
          },
        ]
      }
      pedidos: {
        Row: {
          acrescimo: number | null
          cliente_id: string
          codigo: string
          created_at: string
          created_by: string | null
          data_entrega: string | null
          data_limite_producao: string | null
          desconto: number | null
          entrada_valor: number | null
          id: string
          margem_pct: number | null
          observacoes: string | null
          origem: string | null
          prioridade: Database["public"]["Enums"]["prioridade"]
          status: Database["public"]["Enums"]["status_pedido"]
          status_pagamento: Database["public"]["Enums"]["status_pagamento"]
          updated_at: string
          valor_total: number
        }
        Insert: {
          acrescimo?: number | null
          cliente_id: string
          codigo: string
          created_at?: string
          created_by?: string | null
          data_entrega?: string | null
          data_limite_producao?: string | null
          desconto?: number | null
          entrada_valor?: number | null
          id?: string
          margem_pct?: number | null
          observacoes?: string | null
          origem?: string | null
          prioridade?: Database["public"]["Enums"]["prioridade"]
          status?: Database["public"]["Enums"]["status_pedido"]
          status_pagamento?: Database["public"]["Enums"]["status_pagamento"]
          updated_at?: string
          valor_total?: number
        }
        Update: {
          acrescimo?: number | null
          cliente_id?: string
          codigo?: string
          created_at?: string
          created_by?: string | null
          data_entrega?: string | null
          data_limite_producao?: string | null
          desconto?: number | null
          entrada_valor?: number | null
          id?: string
          margem_pct?: number | null
          observacoes?: string | null
          origem?: string | null
          prioridade?: Database["public"]["Enums"]["prioridade"]
          status?: Database["public"]["Enums"]["status_pedido"]
          status_pagamento?: Database["public"]["Enums"]["status_pagamento"]
          updated_at?: string
          valor_total?: number
        }
        Relationships: [
          {
            foreignKeyName: "pedidos_cliente_id_fkey"
            columns: ["cliente_id"]
            isOneToOne: false
            referencedRelation: "clientes"
            referencedColumns: ["id"]
          },
        ]
      }
      profiles: {
        Row: {
          avatar_url: string | null
          created_at: string
          id: string
          nome: string
          telefone: string | null
          updated_at: string
        }
        Insert: {
          avatar_url?: string | null
          created_at?: string
          id: string
          nome: string
          telefone?: string | null
          updated_at?: string
        }
        Update: {
          avatar_url?: string | null
          created_at?: string
          id?: string
          nome?: string
          telefone?: string | null
          updated_at?: string
        }
        Relationships: []
      }
      tarefas: {
        Row: {
          created_at: string
          created_by: string | null
          descricao: string | null
          id: string
          pedido_id: string | null
          prazo: string | null
          prioridade: Database["public"]["Enums"]["prioridade"]
          responsavel_id: string | null
          status: Database["public"]["Enums"]["status_tarefa"]
          titulo: string
          updated_at: string
        }
        Insert: {
          created_at?: string
          created_by?: string | null
          descricao?: string | null
          id?: string
          pedido_id?: string | null
          prazo?: string | null
          prioridade?: Database["public"]["Enums"]["prioridade"]
          responsavel_id?: string | null
          status?: Database["public"]["Enums"]["status_tarefa"]
          titulo: string
          updated_at?: string
        }
        Update: {
          created_at?: string
          created_by?: string | null
          descricao?: string | null
          id?: string
          pedido_id?: string | null
          prazo?: string | null
          prioridade?: Database["public"]["Enums"]["prioridade"]
          responsavel_id?: string | null
          status?: Database["public"]["Enums"]["status_tarefa"]
          titulo?: string
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "tarefas_pedido_id_fkey"
            columns: ["pedido_id"]
            isOneToOne: false
            referencedRelation: "pedidos"
            referencedColumns: ["id"]
          },
        ]
      }
      user_roles: {
        Row: {
          created_at: string
          id: string
          role: Database["public"]["Enums"]["app_role"]
          user_id: string
        }
        Insert: {
          created_at?: string
          id?: string
          role: Database["public"]["Enums"]["app_role"]
          user_id: string
        }
        Update: {
          created_at?: string
          id?: string
          role?: Database["public"]["Enums"]["app_role"]
          user_id?: string
        }
        Relationships: []
      }
    }
    Views: {
      [_ in never]: never
    }
    Functions: {
      has_role: {
        Args: {
          _role: Database["public"]["Enums"]["app_role"]
          _user_id: string
        }
        Returns: boolean
      }
      is_authenticated_app_user: {
        Args: { _user_id: string }
        Returns: boolean
      }
    }
    Enums: {
      app_role: "dono" | "administrador" | "producao" | "financeiro"
      prioridade: "BAIXA" | "MEDIA" | "ALTA" | "URGENTE"
      status_arte: "PENDENTE" | "ENVIADA" | "APROVADA" | "AJUSTES" | "REJEITADA"
      status_maquina: "OPERACIONAL" | "MANUTENCAO" | "PARADA"
      status_ordem:
        | "FILA"
        | "EM_ANDAMENTO"
        | "PAUSADA"
        | "CONCLUIDA"
        | "REFAZER"
      status_pagamento: "PENDENTE" | "PARCIAL" | "PAGO" | "ATRASADO"
      status_pedido:
        | "ORCAMENTO"
        | "AGUARDANDO_ARTE"
        | "ARTE_APROVADA"
        | "EM_PRODUCAO"
        | "PRONTO"
        | "ENTREGUE"
        | "CANCELADO"
      status_tarefa: "ABERTA" | "EM_ANDAMENTO" | "CONCLUIDA" | "CANCELADA"
      tecnica_producao: "DTF" | "DTG" | "BORDADO" | "PRENSA"
      tipo_financeiro: "RECEITA" | "DESPESA"
      tipo_movimento_estoque: "ENTRADA" | "SAIDA" | "AJUSTE"
      tipo_tecido: "ALGODAO_100" | "PV" | "POLIESTER" | "OUTRO"
    }
    CompositeTypes: {
      [_ in never]: never
    }
  }
}

type DatabaseWithoutInternals = Omit<Database, "__InternalSupabase">

type DefaultSchema = DatabaseWithoutInternals[Extract<keyof Database, "public">]

export type Tables<
  DefaultSchemaTableNameOrOptions extends
    | keyof (DefaultSchema["Tables"] & DefaultSchema["Views"])
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
        DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
      DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])[TableName] extends {
      Row: infer R
    }
    ? R
    : never
  : DefaultSchemaTableNameOrOptions extends keyof (DefaultSchema["Tables"] &
        DefaultSchema["Views"])
    ? (DefaultSchema["Tables"] &
        DefaultSchema["Views"])[DefaultSchemaTableNameOrOptions] extends {
        Row: infer R
      }
      ? R
      : never
    : never

export type TablesInsert<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Insert: infer I
    }
    ? I
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Insert: infer I
      }
      ? I
      : never
    : never

export type TablesUpdate<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Update: infer U
    }
    ? U
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Update: infer U
      }
      ? U
      : never
    : never

export type Enums<
  DefaultSchemaEnumNameOrOptions extends
    | keyof DefaultSchema["Enums"]
    | { schema: keyof DatabaseWithoutInternals },
  EnumName extends DefaultSchemaEnumNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"]
    : never = never,
> = DefaultSchemaEnumNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"][EnumName]
  : DefaultSchemaEnumNameOrOptions extends keyof DefaultSchema["Enums"]
    ? DefaultSchema["Enums"][DefaultSchemaEnumNameOrOptions]
    : never

export type CompositeTypes<
  PublicCompositeTypeNameOrOptions extends
    | keyof DefaultSchema["CompositeTypes"]
    | { schema: keyof DatabaseWithoutInternals },
  CompositeTypeName extends PublicCompositeTypeNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"]
    : never = never,
> = PublicCompositeTypeNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"][CompositeTypeName]
  : PublicCompositeTypeNameOrOptions extends keyof DefaultSchema["CompositeTypes"]
    ? DefaultSchema["CompositeTypes"][PublicCompositeTypeNameOrOptions]
    : never

export const Constants = {
  public: {
    Enums: {
      app_role: ["dono", "administrador", "producao", "financeiro"],
      prioridade: ["BAIXA", "MEDIA", "ALTA", "URGENTE"],
      status_arte: ["PENDENTE", "ENVIADA", "APROVADA", "AJUSTES", "REJEITADA"],
      status_maquina: ["OPERACIONAL", "MANUTENCAO", "PARADA"],
      status_ordem: ["FILA", "EM_ANDAMENTO", "PAUSADA", "CONCLUIDA", "REFAZER"],
      status_pagamento: ["PENDENTE", "PARCIAL", "PAGO", "ATRASADO"],
      status_pedido: [
        "ORCAMENTO",
        "AGUARDANDO_ARTE",
        "ARTE_APROVADA",
        "EM_PRODUCAO",
        "PRONTO",
        "ENTREGUE",
        "CANCELADO",
      ],
      status_tarefa: ["ABERTA", "EM_ANDAMENTO", "CONCLUIDA", "CANCELADA"],
      tecnica_producao: ["DTF", "DTG", "BORDADO", "PRENSA"],
      tipo_financeiro: ["RECEITA", "DESPESA"],
      tipo_movimento_estoque: ["ENTRADA", "SAIDA", "AJUSTE"],
      tipo_tecido: ["ALGODAO_100", "PV", "POLIESTER", "OUTRO"],
    },
  },
} as const
