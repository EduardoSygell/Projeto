import type { Order, Machine } from "./types";

export const mockKPIs = {
  revenueMonth: 28450,
  revenueGoal: 40000,
  receivedMonth: 19880,
  receivable: 14570,
  estimatedProfit: 11320,
  ordersOpen: 23,
  ordersInProduction: 11,
  ordersDueToday: 4,
  ordersLate: 3,
  ordersAwaitingArt: 5,
  ordersAwaitingPayment: 7,
  customersInDebt: 6,
  customersTotal: 142,
  customersNewMonth: 9,
  pendingApprovals: 5,
  lowStock: 4,
  machinesMaintenance: 2,
  productionToday: { DTF: 8, DTG: 3, BORDADO: 2, PRENSA: 5 },
};

export const mockRevenue7d = [
  { day: "Seg", value: 3200 },
  { day: "Ter", value: 4100 },
  { day: "Qua", value: 2800 },
  { day: "Qui", value: 5200 },
  { day: "Sex", value: 6100 },
  { day: "Sáb", value: 4400 },
  { day: "Dom", value: 1800 },
];

export const mockTechniqueLoad = [
  { technique: "DTF", value: 42 },
  { technique: "DTG", value: 18 },
  { technique: "Bordado", value: 14 },
  { technique: "Prensa", value: 26 },
];

const mk = (o: Partial<Order> & Pick<Order, "id" | "code" | "customer_name" | "technique" | "fabric" | "quantity" | "due_date" | "status" | "priority" | "total_value" | "payment_status" | "art_status" | "entry_date">): Order => {
  const paid = o.paid_amount ?? (o.payment_status === "PAGO" ? o.total_value : o.payment_status === "PARCIAL" ? o.total_value * 0.5 : 0);
  return {
    customer_id: "c-" + o.id,
    fabric_color: "Preto",
    sizes: "P:5, M:10, G:8",
    paid_amount: paid,
    balance: o.total_value - paid,
    responsible: "Equipe VOX",
    art_link: "https://drive.google.com/arte-" + o.code,
    notes: "",
    created_at: o.entry_date,
    production_deadline: o.due_date,
    ...o,
  } as Order;
};

export const mockRecentOrders: Order[] = [
  mk({
    id: "1", code: "VX-1042", customer_name: "Loja Streetwear BH",
    technique: "DTF", fabric: "ALGODAO_100", fabric_color: "Branco", sizes: "P:30, M:50, G:40",
    quantity: 120, entry_date: "2026-05-01", due_date: "2026-05-09",
    status: "EM_PRODUCAO", priority: "ALTA", total_value: 2880,
    payment_status: "PARCIAL", art_status: "APROVADA", responsible: "Carlos",
  }),
  mk({
    id: "2", code: "VX-1041", customer_name: "Time Atlético Amador",
    technique: "BORDADO", fabric: "POLIESTER", fabric_color: "Azul", sizes: "M:12, G:12",
    quantity: 24, entry_date: "2026-05-02", due_date: "2026-05-08",
    status: "AGUARDANDO_ARTE", priority: "URGENTE", total_value: 1680,
    payment_status: "PENDENTE", art_status: "PENDENTE", responsible: "Ana",
  }),
  mk({
    id: "3", code: "VX-1040", customer_name: "Camila Modas",
    technique: "DTG", fabric: "ALGODAO_100", fabric_color: "Preto", sizes: "P:20, M:25, G:15",
    quantity: 60, entry_date: "2026-05-03", due_date: "2026-05-12",
    status: "ARTE_APROVADA", priority: "MEDIA", total_value: 1920,
    payment_status: "PAGO", art_status: "APROVADA", responsible: "Carlos",
  }),
  mk({
    id: "4", code: "VX-1039", customer_name: "Eventos PRO",
    technique: "PRENSA", fabric: "PV", fabric_color: "Vermelho", sizes: "Único:200",
    quantity: 200, entry_date: "2026-04-28", due_date: "2026-05-06",
    status: "PRONTO", priority: "ALTA", total_value: 3200,
    payment_status: "PAGO", art_status: "APROVADA", responsible: "Marina",
  }),
  mk({
    id: "5", code: "VX-1038", customer_name: "Academia Iron",
    technique: "DTF", fabric: "POLIESTER", fabric_color: "Cinza", sizes: "M:20, G:25",
    quantity: 45, entry_date: "2026-05-04", due_date: "2026-05-15",
    status: "ORCAMENTO", priority: "BAIXA", total_value: 990,
    payment_status: "PENDENTE", art_status: "PENDENTE", responsible: "Ana",
  }),
  mk({
    id: "6", code: "VX-1037", customer_name: "Igreja Vila Nova",
    technique: "MISTO", fabric: "ALGODAO_100", fabric_color: "Branco", sizes: "P:15, M:30, G:20, GG:10",
    quantity: 75, entry_date: "2026-05-05", due_date: "2026-05-18",
    status: "AGUARDANDO_PAGAMENTO", priority: "MEDIA", total_value: 2250,
    payment_status: "PENDENTE", art_status: "APROVADA", responsible: "Marina",
  }),
  mk({
    id: "7", code: "VX-1036", customer_name: "Studio Tattoo Z",
    technique: "DTG", fabric: "ALGODAO_100", fabric_color: "Preto", sizes: "M:5, G:5",
    quantity: 10, entry_date: "2026-05-06", due_date: "2026-05-10",
    status: "ARTE_AJUSTE", priority: "ALTA", total_value: 480,
    payment_status: "PARCIAL", art_status: "EM_AJUSTE", responsible: "Carlos",
  }),
  mk({
    id: "8", code: "VX-1035", customer_name: "Restaurante Sabor",
    technique: "BORDADO", fabric: "POLIESTER", fabric_color: "Vinho", sizes: "M:8, G:8, GG:4",
    quantity: 20, entry_date: "2026-04-30", due_date: "2026-05-07",
    status: "ACABAMENTO", priority: "MEDIA", total_value: 1400,
    payment_status: "PAGO", art_status: "APROVADA", responsible: "Marina",
  }),
  mk({
    id: "9", code: "VX-1034", customer_name: "Escola Futuro",
    technique: "PRENSA", fabric: "PV", fabric_color: "Azul Royal", sizes: "Vários",
    quantity: 150, entry_date: "2026-04-25", due_date: "2026-05-05",
    status: "ENTREGUE", priority: "MEDIA", total_value: 2700,
    payment_status: "PAGO", art_status: "APROVADA", responsible: "Carlos",
  }),
];

export const mockMachines: Machine[] = [
  { id: "m1", name: "DTF Audley A3+", technique: "DTF", status: "OPERACIONAL", next_maintenance: "2026-06-01" },
  { id: "m2", name: "DTG Epson F2100", technique: "DTG", status: "OPERACIONAL", next_maintenance: "2026-05-20" },
  { id: "m3", name: "Bordadeira Ricoma 6 cab.", technique: "BORDADO", status: "MANUTENCAO", next_maintenance: "2026-05-10" },
  { id: "m4", name: "Prensa Térmica 40x60", technique: "PRENSA", status: "OPERACIONAL", next_maintenance: "2026-07-01" },
];
