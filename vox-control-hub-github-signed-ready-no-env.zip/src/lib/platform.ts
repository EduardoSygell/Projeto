/**
 * Platform detection and native bridges.
 * Same React code roda em web, Capacitor (Android) e Electron (desktop).
 */
import { Capacitor } from "@capacitor/core";

export type Platform = "web" | "capacitor" | "electron";

declare global {
  interface Window {
    electron?: {
      isElectron: true;
      version: string;
      saveFile?: (name: string, data: ArrayBuffer) => Promise<string | null>;
    };
  }
}

export function getPlatform(): Platform {
  if (typeof window === "undefined") return "web";
  if (window.electron?.isElectron) return "electron";
  if (Capacitor.isNativePlatform()) return "capacitor";
  return "web";
}

export const isNative = () => {
  const p = getPlatform();
  return p === "capacitor" || p === "electron";
};

/** Salva um arquivo (PDF, ICS, etc) na plataforma atual. */
export async function downloadFile(
  filename: string,
  data: Blob | ArrayBuffer | string,
  mimeType = "application/octet-stream",
): Promise<void> {
  const platform = getPlatform();
  const blob =
    data instanceof Blob
      ? data
      : new Blob([data as BlobPart], { type: mimeType });

  if (platform === "capacitor") {
    const { Filesystem, Directory, Encoding } = await import(
      "@capacitor/filesystem"
    );
    const { Share } = await import("@capacitor/share");
    const base64 = await blobToBase64(blob);
    const result = await Filesystem.writeFile({
      path: filename,
      data: base64,
      directory: Directory.Documents,
      encoding: Encoding.UTF8 as never,
      recursive: true,
    });
    try {
      await Share.share({
        title: filename,
        url: result.uri,
        dialogTitle: "Compartilhar arquivo",
      });
    } catch {
      // user cancelled share
    }
    return;
  }

  if (platform === "electron" && window.electron?.saveFile) {
    const buf = await blob.arrayBuffer();
    await window.electron.saveFile(filename, buf);
    return;
  }

  // Web fallback
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url;
  a.download = filename;
  document.body.appendChild(a);
  a.click();
  document.body.removeChild(a);
  setTimeout(() => URL.revokeObjectURL(url), 1000);
}

function blobToBase64(blob: Blob): Promise<string> {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onloadend = () => {
      const result = reader.result as string;
      resolve(result.split(",")[1] ?? "");
    };
    reader.onerror = reject;
    reader.readAsDataURL(blob);
  });
}
