import jsPDF from "jspdf";
import autoTable from "jspdf-autotable";
import { db } from "@/lib/db";
import { downloadFile } from "@/lib/platform";
import { formatDateBR } from "@/lib/format";

const brl = (n: unknown) =>
  Number(n ?? 0).toLocaleString("pt-BR", { style: "currency", currency: "BRL" });

function header(doc: jsPDF, title: string) {
  const W = doc.internal.pageSize.getWidth();
  doc.setFillColor(30, 27, 75);
  doc.rect(0, 0, W, 22, "F");
  doc.setTextColor(255, 255, 255);
  doc.setFontSize(14).setFont("helvetica", "bold");
  doc.text("VOX CONTROL — Exportação Geral", 14, 14);
  doc.setFontSize(9).setFont("helvetica", "normal");
  doc.text(formatDateBR(new Date()), W - 14, 14, { align: "right" });
  doc.setTextColor(20, 20, 20);
  doc.setFontSize(13).setFont("helvetica", "bold");
  doc.text(title, 14, 32);
}

function section(doc: jsPDF, title: string) {
  // @ts-expect-error autoTable plugin attaches lastAutoTable
  const lastY = doc.lastAutoTable?.finalY ?? 32;
  if (lastY > doc.internal.pageSize.getHeight() - 40) doc.addPage();
  doc.setFontSize(12).setFont("helvetica", "bold");
  // @ts-expect-error see above
  const y = (doc.lastAutoTable?.finalY ?? 32) + 10;
  doc.text(title, 14, y);
  return y + 2;
}

export async function exportarTudoPDF() {
  const [clientes, pedidos, itens, estoque, maquinas, receber, pagar, tarefas] =
    await Promise.all([
      db.from("clientes").select("*").order("nome"),
      db.from("pedidos").select("*").order("created_at", { ascending: false }),
      db.from("itens_pedido").select("*"),
      db.from("estoque_itens").select("*").order("nome"),
      db.from("maquinas").select("*").order("nome"),
      db.from("financeiro_receber").select("*").order("vencimento"),
      db.from("financeiro_pagar").select("*").order("vencimento"),
      db.from("tarefas").select("*").order("prazo"),
    ]);

  const doc = new jsPDF();
  header(doc, "Resumo");

  const totalReceber = (receber.data ?? []).reduce((s, r) => s + Number(r.valor ?? 0), 0);
  const totalPagar = (pagar.data ?? []).reduce((s, p) => s + Number(p.valor ?? 0), 0);
  const totalPedidos = (pedidos.data ?? []).reduce((s, p) => s + Number(p.valor_total ?? 0), 0);

  autoTable(doc, {
    startY: 38,
    head: [["Indicador", "Valor"]],
    body: [
      ["Clientes cadastrados", String(clientes.data?.length ?? 0)],
      ["Pedidos totais", String(pedidos.data?.length ?? 0)],
      ["Faturamento de pedidos", brl(totalPedidos)],
      ["Total a receber", brl(totalReceber)],
      ["Total a pagar", brl(totalPagar)],
      ["Itens em estoque", String(estoque.data?.length ?? 0)],
      ["Máquinas", String(maquinas.data?.length ?? 0)],
      ["Tarefas", String(tarefas.data?.length ?? 0)],
    ],
    headStyles: { fillColor: [30, 27, 75] },
    styles: { fontSize: 9 },
  });

  // Clientes
  let y = section(doc, "Clientes");
  autoTable(doc, {
    startY: y,
    head: [["Nome", "Tipo", "Documento", "Telefone", "E-mail", "Status"]],
    body: (clientes.data ?? []).map((c) => [
      c.nome ?? "—",
      c.tipo ?? "—",
      c.documento ?? "—",
      c.telefone ?? "—",
      c.email ?? "—",
      c.status ?? "—",
    ]),
    headStyles: { fillColor: [30, 27, 75] },
    styles: { fontSize: 8 },
  });

  // Pedidos
  const cliMap = new Map((clientes.data ?? []).map((c) => [c.id, c.nome]));
  y = section(doc, "Pedidos");
  autoTable(doc, {
    startY: y,
    head: [["Código", "Cliente", "Status", "Pagamento", "Entrega", "Total"]],
    body: (pedidos.data ?? []).map((p) => [
      p.codigo,
      cliMap.get(p.cliente_id) ?? "—",
      p.status,
      p.status_pagamento,
      p.data_entrega ? formatDateBR(p.data_entrega) : "—",
      brl(p.valor_total),
    ]),
    headStyles: { fillColor: [30, 27, 75] },
    styles: { fontSize: 8 },
  });

  // Itens de pedido
  const pedMap = new Map((pedidos.data ?? []).map((p) => [p.id, p.codigo]));
  y = section(doc, "Itens de pedidos");
  autoTable(doc, {
    startY: y,
    head: [["Pedido", "Descrição", "Técnica", "Qtd", "Unitário", "Total"]],
    body: (itens.data ?? []).map((i) => [
      pedMap.get(i.pedido_id) ?? "—",
      i.descricao,
      i.tecnica ?? "—",
      String(i.quantidade ?? 0),
      brl(i.valor_unitario),
      brl(i.valor_total_calculado),
    ]),
    headStyles: { fillColor: [30, 27, 75] },
    styles: { fontSize: 8 },
  });

  // Estoque
  y = section(doc, "Estoque");
  autoTable(doc, {
    startY: y,
    head: [["Item", "Categoria", "Qtd", "Mín.", "Unidade", "Custo"]],
    body: (estoque.data ?? []).map((e) => [
      e.nome,
      e.categoria,
      String(e.quantidade ?? 0),
      String(e.quantidade_minima ?? 0),
      e.unidade,
      e.custo_unitario != null ? brl(e.custo_unitario) : "—",
    ]),
    headStyles: { fillColor: [30, 27, 75] },
    styles: { fontSize: 8 },
  });

  // Máquinas
  y = section(doc, "Máquinas");
  autoTable(doc, {
    startY: y,
    head: [["Nome", "Técnica", "Modelo", "Fabricante", "Status"]],
    body: (maquinas.data ?? []).map((m) => [
      m.nome,
      m.tecnica,
      m.modelo ?? "—",
      m.fabricante ?? "—",
      m.status,
    ]),
    headStyles: { fillColor: [30, 27, 75] },
    styles: { fontSize: 8 },
  });

  // Financeiro a receber
  y = section(doc, "Financeiro — A Receber");
  autoTable(doc, {
    startY: y,
    head: [["Descrição", "Cliente", "Vencimento", "Pago em", "Status", "Valor"]],
    body: (receber.data ?? []).map((r) => [
      r.descricao,
      cliMap.get(r.cliente_id ?? "") ?? "—",
      formatDateBR(r.vencimento),
      r.pago_em ? formatDateBR(r.pago_em) : "—",
      r.status,
      brl(r.valor),
    ]),
    headStyles: { fillColor: [30, 27, 75] },
    styles: { fontSize: 8 },
  });

  // Financeiro a pagar
  y = section(doc, "Financeiro — A Pagar");
  autoTable(doc, {
    startY: y,
    head: [["Descrição", "Fornecedor", "Categoria", "Vencimento", "Status", "Valor"]],
    body: (pagar.data ?? []).map((p) => [
      p.descricao,
      p.fornecedor ?? "—",
      p.categoria ?? "—",
      formatDateBR(p.vencimento),
      p.status,
      brl(p.valor),
    ]),
    headStyles: { fillColor: [30, 27, 75] },
    styles: { fontSize: 8 },
  });

  // Tarefas
  y = section(doc, "Tarefas");
  autoTable(doc, {
    startY: y,
    head: [["Título", "Status", "Prioridade", "Prazo"]],
    body: (tarefas.data ?? []).map((t) => [
      t.titulo,
      t.status,
      t.prioridade,
      t.prazo ? formatDateBR(t.prazo) : "—",
    ]),
    headStyles: { fillColor: [30, 27, 75] },
    styles: { fontSize: 8 },
  });

  // Rodapé com paginação
  const pages = doc.getNumberOfPages();
  for (let i = 1; i <= pages; i++) {
    doc.setPage(i);
    const W = doc.internal.pageSize.getWidth();
    const H = doc.internal.pageSize.getHeight();
    doc.setFontSize(8).setTextColor(120, 120, 120);
    doc.text(`Página ${i} de ${pages}`, W - 14, H - 8, { align: "right" });
    doc.text("VOX Control — Exportação Geral", 14, H - 8);
  }

  const blob = doc.output("blob");
  const stamp = new Date().toISOString().slice(0, 10);
  await downloadFile(`voxcontrol-export-${stamp}.pdf`, blob, "application/pdf");
}
