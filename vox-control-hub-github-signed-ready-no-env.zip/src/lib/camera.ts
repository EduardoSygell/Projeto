/**
 * Captura de imagens cross-platform.
 *
 * - No APK Android (Capacitor): usa @capacitor/camera, que pede permissão
 *   somente no momento da primeira captura — sem permissão ao instalar.
 * - Na web: cai no <input type="file" capture="environment"> que abre a
 *   câmera nativa do celular ou o seletor de arquivos no desktop.
 *
 * Sempre devolve um File para ser tratado pelo mesmo fluxo de upload do app.
 */
import { getPlatform } from "./platform";

export type CaptureSource = "camera" | "gallery" | "ask";

export interface CaptureResult {
  file: File;
  dataUrl: string;
}

const DEFAULT_QUALITY = 80;

export async function capturePhoto(
  source: CaptureSource = "ask",
): Promise<CaptureResult | null> {
  const platform = getPlatform();

  if (platform === "capacitor") {
    try {
      const { Camera, CameraResultType, CameraSource } = await import(
        "@capacitor/camera"
      );

      // Pede permissão somente neste momento.
      try {
        const perm = await Camera.checkPermissions();
        if (perm.camera !== "granted" || perm.photos !== "granted") {
          await Camera.requestPermissions({ permissions: ["camera", "photos"] });
        }
      } catch {
        /* o getPhoto abaixo também dispara o pedido se necessário */
      }

      const cameraSource =
        source === "camera"
          ? CameraSource.Camera
          : source === "gallery"
            ? CameraSource.Photos
            : CameraSource.Prompt;

      const photo = await Camera.getPhoto({
        quality: DEFAULT_QUALITY,
        allowEditing: false,
        resultType: CameraResultType.DataUrl,
        source: cameraSource,
        saveToGallery: false,
      });

      const dataUrl = photo.dataUrl ?? "";
      if (!dataUrl) return null;
      const file = await dataUrlToFile(dataUrl, `foto-${Date.now()}.jpg`);
      return { file, dataUrl };
    } catch (e) {
      const msg = e instanceof Error ? e.message : String(e);
      if (/cancel/i.test(msg)) return null;
      throw e;
    }
  }

  // Web / Electron — input file com capture
  return await pickWithInput(source);
}

function pickWithInput(source: CaptureSource): Promise<CaptureResult | null> {
  return new Promise((resolve) => {
    if (typeof document === "undefined") return resolve(null);
    const input = document.createElement("input");
    input.type = "file";
    input.accept = "image/*";
    if (source === "camera") input.setAttribute("capture", "environment");
    input.onchange = async () => {
      const f = input.files?.[0];
      if (!f) return resolve(null);
      const dataUrl = await fileToDataUrl(f);
      resolve({ file: f, dataUrl });
    };
    input.oncancel = () => resolve(null);
    input.click();
  });
}

function fileToDataUrl(file: File): Promise<string> {
  return new Promise((resolve, reject) => {
    const r = new FileReader();
    r.onload = () => resolve(String(r.result ?? ""));
    r.onerror = reject;
    r.readAsDataURL(file);
  });
}

async function dataUrlToFile(dataUrl: string, name: string): Promise<File> {
  const res = await fetch(dataUrl);
  const blob = await res.blob();
  return new File([blob], name, { type: blob.type || "image/jpeg" });
}
