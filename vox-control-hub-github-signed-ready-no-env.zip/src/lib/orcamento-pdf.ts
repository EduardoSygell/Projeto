import jsPDF from "jspdf";
import autoTable from "jspdf-autotable";
import type { WizardState } from "@/features/pedido-wizard/types";
import { totalPedido } from "@/features/pedido-wizard/pricing-engine";
import { downloadFile } from "@/lib/platform";

const brl = (n: number) => Number(n).toLocaleString("pt-BR", { style: "currency", currency: "BRL" });

export async function gerarOrcamentoPDF(state: WizardState) {
  const doc = new jsPDF();
  const W = doc.internal.pageSize.getWidth();

  // Cabeçalho
  doc.setFillColor(30, 27, 75);
  doc.rect(0, 0, W, 28, "F");
  doc.setTextColor(255, 255, 255);
  doc.setFontSize(20).setFont("helvetica", "bold");
  doc.text("VOX CONTROL", 14, 14);
  doc.setFontSize(9).setFont("helvetica", "normal");
  doc.text("VOX — Mode · Orçamento", 14, 21);
  doc.setFontSize(11).setFont("helvetica", "bold");
  doc.text(state.pedido.codigo, W - 14, 18, { align: "right" });

  doc.setTextColor(20, 20, 20);
  let y = 38;

  // Cliente
  doc.setFontSize(10).setFont("helvetica", "bold").text("Cliente", 14, y);
  y += 5;
  doc.setFont("helvetica", "normal").setFontSize(9);
  const c = state.cliente;
  const linhas = [
    `Nome: ${c.nome || "—"}`,
    `Documento: ${c.documento || "—"}    Tel: ${c.telefone || "—"}`,
    `E-mail: ${c.email || "—"}`,
    c.endereco ? `Endereço: ${c.endereco}` : null,
  ].filter(Boolean) as string[];
  linhas.forEach((l) => { doc.text(l, 14, y); y += 5; });

  y += 2;
  doc.setFont("helvetica", "bold").setFontSize(10).text("Pedido", 14, y);
  y += 5;
  doc.setFont("helvetica", "normal").setFontSize(9);
  doc.text(`Entrega: ${state.pedido.data_entrega || "—"}    Prioridade: ${state.pedido.prioridade}`, 14, y);
  y += 5;

  // Itens
  const rows = state.itens.map((it) => {
    const unit = it.override_unit ?? it.preco_sugerido ?? 0;
    return [it.tecnica, it.descricao || "—", String(it.quantidade), brl(unit), brl(unit * it.quantidade)];
  });

  autoTable(doc, {
    startY: y + 4,
    head: [["Técnica", "Descrição", "Qtd", "Unit.", "Total"]],
    body: rows,
    headStyles: { fillColor: [30, 27, 75] },
    styles: { fontSize: 9 },
    columnStyles: { 2: { halign: "right" }, 3: { halign: "right" }, 4: { halign: "right" } },
  });

  // @ts-expect-error — autotable adiciona lastAutoTable
  let yy = (doc.lastAutoTable?.finalY ?? y + 30) + 6;

  const itensTot = state.itens.map((it) => ({
    valorTotal: ((it.override_unit ?? it.preco_sugerido ?? 0) * it.quantidade),
  }));
  const t = totalPedido(itensTot, {
    desconto: state.precificacao.desconto,
    acrescimo: state.precificacao.acrescimo,
    entrada: state.precificacao.entrada,
  });

  doc.setFontSize(9);
  const right = W - 14;
  const writeRow = (label: string, val: string, bold = false) => {
    doc.setFont("helvetica", bold ? "bold" : "normal");
    doc.text(label, right - 60, yy);
    doc.text(val, right, yy, { align: "right" });
    yy += 5;
  };
  writeRow("Subtotal", brl(t.subtotal));
  if (state.precificacao.desconto) writeRow("Desconto", "- " + brl(state.precificacao.desconto));
  if (state.precificacao.acrescimo) writeRow("Acréscimo", "+ " + brl(state.precificacao.acrescimo));
  writeRow("Total", brl(t.total), true);
  if (t.entrada) writeRow("Entrada", brl(t.entrada));
  if (t.entrada) writeRow("Saldo", brl(t.saldo), true);

  yy += 6;
  doc.setFont("helvetica", "normal").setFontSize(8).setTextColor(90);
  doc.text(`Forma de pagamento: ${state.precificacao.forma_pagamento}`, 14, yy);
  yy += 4;
  doc.text(`Validade do orçamento: ${state.validade_dias} dias`, 14, yy);
  if (state.pedido.observacoes) {
    yy += 6;
    doc.setFont("helvetica", "bold").text("Observações:", 14, yy); yy += 4;
    doc.setFont("helvetica", "normal");
    const split = doc.splitTextToSize(state.pedido.observacoes, W - 28);
    doc.text(split, 14, yy);
  }

  const blob = doc.output("blob");
  await downloadFile(`Orcamento-${state.pedido.codigo}.pdf`, blob, "application/pdf");
}
