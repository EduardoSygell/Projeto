import { supabase } from "@/integrations/supabase/client";
import type { Database } from "@/integrations/supabase/types";

export type Cliente = Database["public"]["Tables"]["clientes"]["Row"];
export type Pedido = Database["public"]["Tables"]["pedidos"]["Row"];
export type ItemPedido = Database["public"]["Tables"]["itens_pedido"]["Row"];
export type EstoqueItem = Database["public"]["Tables"]["estoque_itens"]["Row"];
export type Maquina = Database["public"]["Tables"]["maquinas"]["Row"];
export type FinReceber = Database["public"]["Tables"]["financeiro_receber"]["Row"];
export type FinPagar = Database["public"]["Tables"]["financeiro_pagar"]["Row"];
export type Manutencao = Database["public"]["Tables"]["manutencoes"]["Row"];

export const db = supabase;

export function nextOrderCode() {
  const n = Math.floor(1000 + Math.random() * 9000);
  return `VX-${n}`;
}
