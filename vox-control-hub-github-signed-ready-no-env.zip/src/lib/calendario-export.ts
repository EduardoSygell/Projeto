import jsPDF from "jspdf";
import autoTable from "jspdf-autotable";
import { formatDateBR } from "./format";
import { downloadFile } from "@/lib/platform";

export type ExportEvento = {
  id: string;
  titulo: string;
  tipo?: string | null;
  inicio: string; // ISO
  fim?: string | null;
  local?: string | null;
  descricao?: string | null;
};

export type ExportEntrega = {
  id: string;
  codigo: string;
  cliente?: string | null;
  status: string;
  prioridade?: string | null;
  data_entrega: string; // YYYY-MM-DD
};

const pad = (n: number) => String(n).padStart(2, "0");
const toICSDate = (iso: string, allDay = false) => {
  const d = new Date(iso);
  if (allDay) {
    return `${d.getUTCFullYear()}${pad(d.getUTCMonth() + 1)}${pad(d.getUTCDate())}`;
  }
  return `${d.getUTCFullYear()}${pad(d.getUTCMonth() + 1)}${pad(d.getUTCDate())}T${pad(d.getUTCHours())}${pad(d.getUTCMinutes())}${pad(d.getUTCSeconds())}Z`;
};
const escICS = (s: string) =>
  s.replace(/\\/g, "\\\\").replace(/\n/g, "\\n").replace(/,/g, "\\,").replace(/;/g, "\\;");

export async function gerarCalendarioICS(
  eventos: ExportEvento[],
  entregas: ExportEntrega[],
  periodoLabel: string,
) {
  const stamp = toICSDate(new Date().toISOString());
  const lines: string[] = [
    "BEGIN:VCALENDAR",
    "VERSION:2.0",
    "PRODID:-//VOX Control//Calendario//PT-BR",
    "CALSCALE:GREGORIAN",
    "METHOD:PUBLISH",
    `X-WR-CALNAME:${escICS("VOX Control - " + periodoLabel)}`,
  ];

  for (const e of eventos) {
    const start = e.inicio;
    const end = e.fim ?? new Date(new Date(start).getTime() + 60 * 60 * 1000).toISOString();
    lines.push(
      "BEGIN:VEVENT",
      `UID:evento-${e.id}@voxcontrol`,
      `DTSTAMP:${stamp}`,
      `DTSTART:${toICSDate(start)}`,
      `DTEND:${toICSDate(end)}`,
      `SUMMARY:${escICS((e.tipo ? `[${e.tipo}] ` : "") + e.titulo)}`,
      e.local ? `LOCATION:${escICS(e.local)}` : "",
      e.descricao ? `DESCRIPTION:${escICS(e.descricao)}` : "",
      "END:VEVENT",
    );
  }

  for (const p of entregas) {
    const start = `${p.data_entrega}T00:00:00Z`;
    const endDate = new Date(`${p.data_entrega}T00:00:00Z`);
    endDate.setUTCDate(endDate.getUTCDate() + 1);
    lines.push(
      "BEGIN:VEVENT",
      `UID:entrega-${p.id}@voxcontrol`,
      `DTSTAMP:${stamp}`,
      `DTSTART;VALUE=DATE:${toICSDate(start, true)}`,
      `DTEND;VALUE=DATE:${toICSDate(endDate.toISOString(), true)}`,
      `SUMMARY:${escICS(`Entrega ${p.codigo}${p.cliente ? " - " + p.cliente : ""}`)}`,
      `DESCRIPTION:${escICS(`Status: ${p.status}${p.prioridade ? " | Prioridade: " + p.prioridade : ""}`)}`,
      "END:VEVENT",
    );
  }

  lines.push("END:VCALENDAR");
  const content = lines.filter(Boolean).join("\r\n");
  const blob = new Blob([content], { type: "text/calendar;charset=utf-8" });
  await downloadFile(
    `VOX-Calendario-${periodoLabel.replace(/\s+/g, "_")}.ics`,
    blob,
    "text/calendar",
  );
}

export async function gerarCalendarioPDF(
  eventos: ExportEvento[],
  entregas: ExportEntrega[],
  periodoLabel: string,
) {
  const doc = new jsPDF();
  const W = doc.internal.pageSize.getWidth();

  doc.setFillColor(30, 27, 75);
  doc.rect(0, 0, W, 28, "F");
  doc.setTextColor(255, 255, 255);
  doc.setFontSize(20).setFont("helvetica", "bold");
  doc.text("VOX CONTROL", 14, 14);
  doc.setFontSize(9).setFont("helvetica", "normal");
  doc.text("Calendário · " + periodoLabel, 14, 21);

  doc.setTextColor(20, 20, 20);
  let y = 38;

  // Entregas
  doc.setFont("helvetica", "bold").setFontSize(11).text(`Entregas (${entregas.length})`, 14, y);
  y += 2;
  if (entregas.length === 0) {
    doc.setFont("helvetica", "italic").setFontSize(9).text("Nenhuma entrega no período.", 14, y + 5);
    y += 10;
  } else {
    autoTable(doc, {
      startY: y + 2,
      head: [["Data", "Código", "Cliente", "Status", "Prioridade"]],
      body: entregas
        .slice()
        .sort((a, b) => a.data_entrega.localeCompare(b.data_entrega))
        .map((p) => [
          formatDateBR(p.data_entrega),
          p.codigo,
          p.cliente ?? "—",
          p.status,
          p.prioridade ?? "—",
        ]),
      headStyles: { fillColor: [30, 27, 75] },
      styles: { fontSize: 9 },
    });
    // @ts-expect-error autotable
    y = (doc.lastAutoTable?.finalY ?? y) + 8;
  }

  // Eventos
  doc.setFont("helvetica", "bold").setFontSize(11).text(`Eventos (${eventos.length})`, 14, y);
  if (eventos.length === 0) {
    doc.setFont("helvetica", "italic").setFontSize(9).text("Nenhum evento no período.", 14, y + 7);
  } else {
    autoTable(doc, {
      startY: y + 2,
      head: [["Data/Hora", "Tipo", "Título", "Local"]],
      body: eventos
        .slice()
        .sort((a, b) => a.inicio.localeCompare(b.inicio))
        .map((e) => {
          const d = new Date(e.inicio);
          return [
            `${formatDateBR(e.inicio)} ${String(d.getHours()).padStart(2, "0")}:${String(d.getMinutes()).padStart(2, "0")}`,
            e.tipo ?? "—",
            e.titulo,
            e.local ?? "—",
          ];
        }),
      headStyles: { fillColor: [30, 27, 75] },
      styles: { fontSize: 9 },
    });
  }

  const blob = doc.output("blob");
  await downloadFile(
    `VOX-Calendario-${periodoLabel.replace(/\s+/g, "_")}.pdf`,
    blob,
    "application/pdf",
  );
}
