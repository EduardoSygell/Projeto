/**
 * Sincronização Supabase ↔ IndexedDB com background auto-sync.
 *
 * - pullAll(): baixa tabelas principais para o cache local
 * - flushOutbox(): envia operações pendentes
 * - runOrEnqueue(): grava online ou enfileira offline
 * - startAutoSync(): listeners de online/offline (web + Capacitor Network),
 *   resume do app, intervalo periódico e retry com backoff
 * - subscribeSyncStatus(): permite a UI reagir aos estados
 *   "idle | syncing | error" e ao número de pendentes
 */
import { supabase } from "@/integrations/supabase/client";
import {
  bumpOutboxAttempt,
  clearStore,
  enqueueOutbox,
  listOutbox,
  putMany,
  removeOutbox,
  setMeta,
  type OutboxItem,
  type StoreName,
} from "./db";

type TableSpec = { table: string; store: StoreName };

const TABLES: TableSpec[] = [
  { table: "clientes", store: "clientes" },
  { table: "pedidos", store: "pedidos" },
  { table: "fichas_tecnicas", store: "fichas_tecnicas" },
  { table: "anexos", store: "anexos" },
  { table: "calendario_eventos", store: "eventos" },
  { table: "tarefas", store: "entregas" },
  { table: "config_precificacao", store: "config_precificacao" },
];

export type SyncState = "idle" | "syncing" | "error";
export interface SyncStatus {
  state: SyncState;
  pending: number;
  online: boolean;
  lastSyncAt: number | null;
  lastError: string | null;
}

let status: SyncStatus = {
  state: "idle",
  pending: 0,
  online: typeof navigator !== "undefined" ? navigator.onLine : true,
  lastSyncAt: null,
  lastError: null,
};

const listeners = new Set<(s: SyncStatus) => void>();
function emit(patch: Partial<SyncStatus>) {
  status = { ...status, ...patch };
  for (const l of listeners) l(status);
}

export function subscribeSyncStatus(fn: (s: SyncStatus) => void): () => void {
  listeners.add(fn);
  fn(status);
  return () => listeners.delete(fn);
}

export function getSyncStatus(): SyncStatus {
  return status;
}

async function refreshPending() {
  try {
    const items = await listOutbox();
    emit({ pending: items.length });
  } catch {
    /* noop */
  }
}

let pulling = false;

export async function pullAll(): Promise<void> {
  if (pulling) return;
  pulling = true;
  emit({ state: "syncing" });
  try {
    const { data: userData } = await supabase.auth.getUser();
    if (!userData?.user) {
      emit({ state: "idle" });
      return;
    }

    await Promise.all(
      TABLES.map(async ({ table, store }) => {
        try {
          const { data, error } = await supabase
            .from(table as never)
            .select("*")
            .limit(1000);
          if (error) throw error;
          if (Array.isArray(data)) {
            await clearStore(store);
            await putMany(
              store,
              data.map((r: Record<string, unknown>) => ({
                id: String(r.id ?? crypto.randomUUID()),
                ...r,
              })),
            );
          }
        } catch (e) {
          console.warn(`[sync] pull ${table} falhou`, e);
        }
      }),
    );
    await setMeta("last_pull_at", Date.now());
    emit({ state: "idle", lastSyncAt: Date.now(), lastError: null });
  } catch (e) {
    emit({
      state: "error",
      lastError: e instanceof Error ? e.message : String(e),
    });
  } finally {
    pulling = false;
    await refreshPending();
  }
}

/** Grava direto se online; enfileira na outbox se offline ou em caso de erro. */
export async function runOrEnqueue(
  table: string,
  op: OutboxItem["op"],
  payload: unknown,
  match?: Record<string, unknown>,
): Promise<{ queued: boolean; error?: string }> {
  if (typeof navigator !== "undefined" && navigator.onLine) {
    try {
      await execute(table, op, payload, match);
      return { queued: false };
    } catch (e) {
      const msg = e instanceof Error ? e.message : "erro desconhecido";
      await enqueueOutbox({ table, op, payload, match });
      await refreshPending();
      return { queued: true, error: msg };
    }
  }
  await enqueueOutbox({ table, op, payload, match });
  await refreshPending();
  return { queued: true };
}

async function execute(
  table: string,
  op: OutboxItem["op"],
  payload: unknown,
  match?: Record<string, unknown>,
): Promise<void> {
  const q = supabase.from(table as never);
  if (op === "insert") {
    const { error } = await q.insert(payload as never);
    if (error) throw error;
  } else if (op === "upsert") {
    const { error } = await q.upsert(payload as never);
    if (error) throw error;
  } else if (op === "update") {
    let qb = q.update(payload as never);
    for (const [k, v] of Object.entries(match ?? {}))
      qb = qb.eq(k as never, v as never);
    const { error } = await qb;
    if (error) throw error;
  } else if (op === "delete") {
    let qb = q.delete();
    for (const [k, v] of Object.entries(match ?? {}))
      qb = qb.eq(k as never, v as never);
    const { error } = await qb;
    if (error) throw error;
  }
}

let flushing = false;
const MAX_ATTEMPTS = 8;

export async function flushOutbox(): Promise<{ sent: number; failed: number }> {
  if (flushing) return { sent: 0, failed: 0 };
  flushing = true;
  emit({ state: "syncing" });
  let sent = 0;
  let failed = 0;
  try {
    const items = await listOutbox();
    for (const it of items) {
      // Backoff exponencial: pula itens cujo retry ainda não venceu.
      if (it.attempts > 0) {
        const delay = Math.min(60_000, 2 ** it.attempts * 1000);
        if (Date.now() - it.createdAt < delay && it.attempts < MAX_ATTEMPTS)
          continue;
      }
      try {
        await execute(it.table, it.op, it.payload, it.match);
        await removeOutbox(it.id);
        sent++;
      } catch (e) {
        failed++;
        await bumpOutboxAttempt(
          it.id,
          e instanceof Error ? e.message : String(e),
        );
      }
    }
    if (sent > 0) await pullAll();
    emit({
      state: failed > 0 ? "error" : "idle",
      lastSyncAt: Date.now(),
      lastError: failed > 0 ? `${failed} item(s) com erro` : null,
    });
  } finally {
    flushing = false;
    await refreshPending();
  }
  return { sent, failed };
}

let autoStarted = false;
let periodicId: ReturnType<typeof setInterval> | null = null;

/** Liga listeners de rede + ciclo de vida + intervalo periódico de sincronização. */
export function startAutoSync(): void {
  if (autoStarted || typeof window === "undefined") return;
  autoStarted = true;

  const triggerSync = () => {
    void flushOutbox().then(() => {
      if (status.online) void pullAll();
    });
  };

  const goOnline = () => {
    emit({ online: true });
    triggerSync();
  };
  const goOffline = () => emit({ online: false });

  // Web events
  window.addEventListener("online", goOnline);
  window.addEventListener("offline", goOffline);
  window.addEventListener("focus", () => {
    if (navigator.onLine) triggerSync();
  });

  // Capacitor Network + App lifecycle (carregados sob demanda; ignorados na web).
  void (async () => {
    try {
      const { Network } = await import("@capacitor/network");
      const st = await Network.getStatus();
      emit({ online: st.connected });
      Network.addListener("networkStatusChange", (s) => {
        if (s.connected) goOnline();
        else goOffline();
      });
    } catch {
      /* não-Capacitor — usa só window.online */
    }
    try {
      const { App } = await import("@capacitor/app");
      App.addListener("appStateChange", ({ isActive }) => {
        if (isActive && status.online) triggerSync();
      });
      App.addListener("resume", () => {
        if (status.online) triggerSync();
      });
    } catch {
      /* não-Capacitor */
    }
  })();

  // Pull inicial + intervalo de retry contínuo.
  if (status.online) triggerSync();
  periodicId = setInterval(() => {
    if (!status.online) return;
    if (status.pending > 0) void flushOutbox();
    else void pullAll();
  }, 60_000);

  void refreshPending();
}

export function stopAutoSync(): void {
  if (periodicId) clearInterval(periodicId);
  periodicId = null;
  autoStarted = false;
}
