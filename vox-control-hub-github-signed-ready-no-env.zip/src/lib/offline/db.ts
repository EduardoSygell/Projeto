/**
 * IndexedDB local-first cache.
 * Toda tela lê primeiro daqui (instantâneo, funciona offline) e
 * o sync revalida com o Supabase em background.
 */
import { openDB, type IDBPDatabase } from "idb";

const DB_NAME = "voxcontrol-offline";
const DB_VERSION = 1;

export type StoreName =
  | "clientes"
  | "pedidos"
  | "fichas_tecnicas"
  | "anexos"
  | "eventos"
  | "entregas"
  | "config_precificacao"
  | "outbox"
  | "meta";

export interface OutboxItem {
  id: string;
  table: string;
  op: "insert" | "update" | "delete" | "upsert";
  payload: unknown;
  match?: Record<string, unknown>;
  createdAt: number;
  attempts: number;
  lastError?: string;
}

let dbPromise: Promise<IDBPDatabase> | null = null;

export function getDB(): Promise<IDBPDatabase> {
  if (typeof indexedDB === "undefined") {
    return Promise.reject(new Error("IndexedDB indisponível"));
  }
  if (!dbPromise) {
    dbPromise = openDB(DB_NAME, DB_VERSION, {
      upgrade(db) {
        const stores: StoreName[] = [
          "clientes",
          "pedidos",
          "fichas_tecnicas",
          "anexos",
          "eventos",
          "entregas",
          "config_precificacao",
          "outbox",
          "meta",
        ];
        for (const s of stores) {
          if (!db.objectStoreNames.contains(s)) {
            db.createObjectStore(s, { keyPath: "id" });
          }
        }
      },
    });
  }
  return dbPromise;
}

export async function getAll<T = unknown>(store: StoreName): Promise<T[]> {
  try {
    const db = await getDB();
    return (await db.getAll(store)) as T[];
  } catch {
    return [];
  }
}

export async function getOne<T = unknown>(
  store: StoreName,
  id: string,
): Promise<T | undefined> {
  try {
    const db = await getDB();
    return (await db.get(store, id)) as T | undefined;
  } catch {
    return undefined;
  }
}

export async function putMany<T extends { id: string }>(
  store: StoreName,
  items: T[],
): Promise<void> {
  if (!items.length) return;
  try {
    const db = await getDB();
    const tx = db.transaction(store, "readwrite");
    await Promise.all(items.map((it) => tx.store.put(it)));
    await tx.done;
  } catch (e) {
    console.warn("[offline] putMany failed", store, e);
  }
}

export async function putOne<T extends { id: string }>(
  store: StoreName,
  item: T,
): Promise<void> {
  try {
    const db = await getDB();
    await db.put(store, item);
  } catch (e) {
    console.warn("[offline] putOne failed", store, e);
  }
}

export async function deleteOne(store: StoreName, id: string): Promise<void> {
  try {
    const db = await getDB();
    await db.delete(store, id);
  } catch (e) {
    console.warn("[offline] delete failed", store, e);
  }
}

export async function clearStore(store: StoreName): Promise<void> {
  try {
    const db = await getDB();
    await db.clear(store);
  } catch {
    /* noop */
  }
}

/* ---------- Outbox (operações pendentes) ---------- */

export async function enqueueOutbox(
  item: Omit<OutboxItem, "id" | "createdAt" | "attempts">,
): Promise<string> {
  const id = crypto.randomUUID();
  const full: OutboxItem = {
    id,
    createdAt: Date.now(),
    attempts: 0,
    ...item,
  };
  await putOne("outbox", full);
  return id;
}

export async function listOutbox(): Promise<OutboxItem[]> {
  return getAll<OutboxItem>("outbox");
}

export async function removeOutbox(id: string): Promise<void> {
  await deleteOne("outbox", id);
}

export async function bumpOutboxAttempt(
  id: string,
  error?: string,
): Promise<void> {
  const item = await getOne<OutboxItem>("outbox", id);
  if (!item) return;
  item.attempts += 1;
  item.lastError = error;
  await putOne("outbox", item);
}

/* ---------- Meta (metadados de sync) ---------- */

export async function setMeta(key: string, value: unknown): Promise<void> {
  await putOne("meta", { id: key, value, at: Date.now() });
}

export async function getMeta<T = unknown>(key: string): Promise<T | null> {
  const r = await getOne<{ value: T }>("meta", key);
  return r?.value ?? null;
}
