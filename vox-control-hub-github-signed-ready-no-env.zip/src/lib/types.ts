// VOX Control — domain models. Mirrors the planned Supabase schema.

export type ProductionTechnique = "DTF" | "DTG" | "BORDADO" | "PRENSA" | "MISTO";
export type FabricType = "ALGODAO_100" | "PV" | "POLIESTER";

// Fluxo completo do pedido na VOX Mode
export type OrderStatus =
  | "ORCAMENTO"
  | "AGUARDANDO_APROVACAO"
  | "AGUARDANDO_PAGAMENTO"
  | "AGUARDANDO_ARTE"
  | "ARTE_AJUSTE"
  | "ARTE_APROVADA"
  | "SEPARAR_PECAS"
  | "EM_PRODUCAO"
  | "ACABAMENTO"
  | "CONFERENCIA"
  | "PRONTO"
  | "ENTREGUE"
  | "FINALIZADO"
  | "CANCELADO";

export type ArtApprovalStatus = "PENDENTE" | "EM_AJUSTE" | "APROVADA" | "REJEITADA";
export type Priority = "BAIXA" | "MEDIA" | "ALTA" | "URGENTE";
export type PaymentStatus = "PENDENTE" | "PARCIAL" | "PAGO" | "ATRASADO";
export type MachineStatus = "OPERACIONAL" | "MANUTENCAO" | "PARADA";

export interface Customer {
  id: string;
  name: string;
  document?: string;
  phone?: string;
  email?: string;
  notes?: string;
  created_at: string;
}

export interface Order {
  id: string;
  code: string;
  customer_id: string;
  customer_name?: string;
  technique: ProductionTechnique;
  fabric: FabricType;
  fabric_color?: string;
  sizes?: string; // ex: "P:10, M:20, G:15"
  quantity: number;
  entry_date: string;       // data de entrada
  due_date: string;         // data prometida
  production_deadline?: string; // data limite de produção
  status: OrderStatus;
  payment_status: PaymentStatus;
  art_status: ArtApprovalStatus;
  priority: Priority;
  total_value: number;
  paid_amount: number;
  balance: number;
  responsible?: string;
  art_link?: string;
  notes?: string;
  created_at: string;
}

export interface ArtApproval {
  id: string;
  order_id: string;
  file_url?: string;
  status: ArtApprovalStatus;
  sent_at?: string;
  approved_at?: string;
  feedback?: string;
}

export interface ProductionTask {
  id: string;
  order_id: string;
  technique: ProductionTechnique;
  machine_id?: string;
  status: "FILA" | "EM_ANDAMENTO" | "CONCLUIDA" | "REFAZER";
  started_at?: string;
  finished_at?: string;
}

export interface StockItem {
  id: string;
  name: string;
  category: "TINTA" | "FILME" | "TECIDO" | "LINHA" | "OUTRO";
  unit: string;
  quantity: number;
  min_quantity: number;
}

export interface FinancialEntry {
  id: string;
  type: "RECEITA" | "DESPESA";
  description: string;
  amount: number;
  date: string;
  order_id?: string;
  category?: string;
}

export interface Machine {
  id: string;
  name: string;
  technique: ProductionTechnique;
  status: MachineStatus;
  last_maintenance?: string;
  next_maintenance?: string;
  notes?: string;
}

export interface FileAsset {
  id: string;
  order_id?: string;
  customer_id?: string;
  name: string;
  url: string;
  kind: "ARTE" | "MOCKUP" | "REFERENCIA" | "OUTRO";
  created_at: string;
}
