// Fila de sincronização — VOX Control
// Tenta executar uma operação online; se falhar por rede / offline,
// salva o payload em `fila_sincronizacao` (Supabase) ou no localStorage
// como fallback final, para reenviar mais tarde.

import { db } from "@/lib/db";

const LS_KEY = "vox-sync-queue";

type LocalEntry = { id: string; tipo: string; payload: unknown; created_at: string };

function readLocal(): LocalEntry[] {
  try { return JSON.parse(localStorage.getItem(LS_KEY) || "[]"); } catch { return []; }
}
function writeLocal(list: LocalEntry[]) {
  try { localStorage.setItem(LS_KEY, JSON.stringify(list)); } catch { /* ignore */ }
}

function isOffline() {
  return typeof navigator !== "undefined" && navigator.onLine === false;
}

function looksLikeNetworkError(e: unknown) {
  const msg = e instanceof Error ? e.message : String(e ?? "");
  return /fetch|network|failed to fetch|timeout|ECONN|ENOTFOUND/i.test(msg);
}

/**
 * Executa `fn` direto. Se offline ou falha de rede, persiste o payload
 * para reenvio posterior. Demais erros (validação, RLS, etc) sobem.
 */
export async function runOrEnqueue<T>(
  tipo: string,
  payload: unknown,
  fn: () => Promise<T>,
): Promise<{ ok: true; result: T } | { ok: false; queued: true; reason: string }> {
  if (isOffline()) {
    await enqueue(tipo, payload);
    return { ok: false, queued: true, reason: "offline" };
  }
  try {
    const result = await fn();
    return { ok: true, result };
  } catch (e) {
    if (looksLikeNetworkError(e)) {
      await enqueue(tipo, payload);
      return { ok: false, queued: true, reason: "network" };
    }
    throw e;
  }
}

async function enqueue(tipo: string, payload: unknown) {
  // Tenta gravar em `fila_sincronizacao`; se isso também falhar (offline real),
  // salva localmente e reenvia depois com `flushLocalQueue()`.
  try {
    const { error } = await db.from("fila_sincronizacao").insert({
      // eslint-disable-next-line @typescript-eslint/no-explicit-any
      payload: payload as any,
      tipo,
      status: "PENDENTE",
    });
    if (error) throw error;
  } catch {
    const list = readLocal();
    list.push({
      id: crypto.randomUUID(),
      tipo,
      payload,
      created_at: new Date().toISOString(),
    });
    writeLocal(list);
  }
}

/** Reenvia entradas locais para `fila_sincronizacao` quando voltar online. */
export async function flushLocalQueue() {
  if (isOffline()) return;
  const list = readLocal();
  if (list.length === 0) return;
  const remaining: LocalEntry[] = [];
  for (const item of list) {
    try {
      const { error } = await db.from("fila_sincronizacao").insert({
        // eslint-disable-next-line @typescript-eslint/no-explicit-any
        payload: item.payload as any,
        tipo: item.tipo,
        status: "PENDENTE",
      });
      if (error) remaining.push(item);
    } catch {
      remaining.push(item);
    }
  }
  writeLocal(remaining);
}

export function pendingLocalCount() {
  return readLocal().length;
}

if (typeof window !== "undefined") {
  window.addEventListener("online", () => { void flushLocalQueue(); });
}
