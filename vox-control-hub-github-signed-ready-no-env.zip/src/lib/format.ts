// Format a YYYY-MM-DD or ISO date deterministically (no locale/timezone issues during SSR hydration).
export function formatDateBR(value: string | Date | null | undefined): string {
  if (!value) return "—";
  const s = typeof value === "string" ? value : value.toISOString();
  // Take the date part only (YYYY-MM-DD), ignore time/zone.
  const datePart = s.slice(0, 10);
  const [y, m, d] = datePart.split("-");
  if (!y || !m || !d) return s;
  return `${d}/${m}/${y}`;
}
