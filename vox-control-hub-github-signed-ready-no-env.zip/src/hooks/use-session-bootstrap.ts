import { useEffect, useState } from "react";
import { supabase } from "@/integrations/supabase/client";

/**
 * Garante uma sessão ativa no Supabase. Se não houver, faz signInAnonymously.
 * Retorna `ready=true` quando há sessão para que o app possa fazer queries com RLS.
 */
export function useSessionBootstrap() {
  const [ready, setReady] = useState(false);

  useEffect(() => {
    let cancelled = false;

    const unlock = () => {
      if (!cancelled) setReady(true);
    };

    const fallbackTimer = window.setTimeout(unlock, 4000);

    const ensure = async () => {
      try {
        const { data } = await supabase.auth.getSession();
        if (data.session) {
          unlock();
          return;
        }
        const { error } = await supabase.auth.signInAnonymously();
        if (error) {
          console.error("[VOX] Falha ao iniciar sessão anônima:", error.message);
          unlock(); // libera UI mesmo assim
          return;
        }
        unlock();
      } catch (error) {
        console.error("[VOX] Bootstrap do Supabase falhou:", error);
        unlock(); // nunca deixa o APK preso numa tela vazia/spinner
      } finally {
        window.clearTimeout(fallbackTimer);
      }
    };

    void ensure();
    return () => {
      cancelled = true;
    };
  }, []);

  return ready;
}
