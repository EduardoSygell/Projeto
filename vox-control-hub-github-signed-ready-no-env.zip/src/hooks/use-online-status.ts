import { useEffect, useState } from "react";
import { subscribeSyncStatus, type SyncStatus } from "@/lib/offline/sync";

export function useOnlineStatus() {
  const [status, setStatus] = useState<SyncStatus>(() => ({
    state: "idle",
    pending: 0,
    online: typeof navigator !== "undefined" ? navigator.onLine : true,
    lastSyncAt: null,
    lastError: null,
  }));

  useEffect(() => subscribeSyncStatus(setStatus), []);

  return {
    online: status.online,
    pending: status.pending,
    syncing: status.state === "syncing",
    error: status.state === "error" ? status.lastError : null,
    lastSyncAt: status.lastSyncAt,
  };
}
