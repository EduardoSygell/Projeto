import { useMemo } from "react";
import { useQuery } from "@tanstack/react-query";
import { db } from "@/lib/db";
import type { PricingConfig } from "@/features/pedido-wizard/pricing-engine";
import { getGeral } from "@/features/pedido-wizard/pricing-engine";

export type PagamentoOption = { chave: string; label: string };

export type PrecificacaoConfig = {
  cfg: PricingConfig;
  geral: ReturnType<typeof getGeral>;
  pagamentos: PagamentoOption[];
  formaPadrao: string; // chave (ex: "pix")
  isLoading: boolean;
};

/**
 * Hook único e canônico para ler a configuração global de precificação.
 * Qualquer alteração feita em Configurações > Precificação reflete
 * automaticamente em todas as telas (wizard, recálculos, orçamentos).
 */
export function usePrecificacaoConfig(): PrecificacaoConfig {
  const { data: rows = [], isLoading } = useQuery({
    queryKey: ["config_precificacao"],
    queryFn: async () => {
      const { data, error } = await db
        .from("config_precificacao")
        .select("categoria, chave, valor, descricao");
      if (error) throw error;
      return data as { categoria: string; chave: string; valor: number; descricao: string | null }[];
    },
    staleTime: 60_000,
  });

  return useMemo(() => {
    const cfg: PricingConfig = {};
    const pagamentos: PagamentoOption[] = [];
    let formaPadrao = "pix";

    for (const r of rows) {
      cfg[`${r.categoria}_${r.chave}`] = Number(r.valor ?? 0);
      if (r.categoria === "PAGAMENTO") {
        if (r.chave === "forma_padrao") {
          formaPadrao = (r.descricao || "pix").toLowerCase();
        } else if (Number(r.valor) > 0) {
          pagamentos.push({ chave: r.chave, label: r.descricao || r.chave });
        }
      }
    }

    if (pagamentos.length === 0) {
      pagamentos.push(
        { chave: "pix", label: "PIX" },
        { chave: "dinheiro", label: "Dinheiro" },
        { chave: "cartao_credito", label: "Cartão de crédito" },
      );
    }

    return {
      cfg,
      geral: getGeral(cfg),
      pagamentos,
      formaPadrao,
      isLoading,
    };
  }, [rows, isLoading]);
}
