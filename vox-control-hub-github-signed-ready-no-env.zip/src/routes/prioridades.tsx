import { createFileRoute } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import { PageShell } from "@/components/page-shell";
import { OrderStatusBadge, PriorityBadge, PaymentBadge } from "@/components/status-badge";
import { db, type Pedido } from "@/lib/db";
import { formatDateBR } from "@/lib/format";

export const Route = createFileRoute("/prioridades")({
  head: () => ({ meta: [{ title: "Prioridades — VOX Control" }] }),
  component: Page,
});

type PedidoComCliente = Pedido & { cliente?: { nome: string } | null };

function Page() {
  const today = new Date().toISOString().slice(0, 10);

  const { data = [], isLoading } = useQuery({
    queryKey: ["prioridades"],
    queryFn: async () => {
      const { data, error } = await db
        .from("pedidos")
        .select("*, cliente:clientes(nome)")
        .not("status", "in", "(ENTREGUE,CANCELADO)")
        .order("data_entrega", { ascending: true });
      if (error) throw error;
      return data as PedidoComCliente[];
    },
  });

  const atrasados = data.filter((p) => p.data_entrega && p.data_entrega < today);
  const hoje = data.filter((p) => p.data_entrega === today);
  const urgentes = data.filter((p) => p.prioridade === "URGENTE" && !atrasados.includes(p) && !hoje.includes(p));
  const altas = data.filter((p) => p.prioridade === "ALTA" && !atrasados.includes(p) && !hoje.includes(p) && !urgentes.includes(p));

  const sections = [
    { title: "🚨 Atrasados", items: atrasados, tone: "border-destructive/40" },
    { title: "📅 Entrega hoje", items: hoje, tone: "border-warning/40" },
    { title: "⚡ Urgentes", items: urgentes, tone: "border-info/40" },
    { title: "🔥 Alta prioridade", items: altas, tone: "border-border" },
  ];

  return (
    <PageShell title="Prioridades" description="O que precisa de atenção agora.">
      {isLoading && <p className="text-sm text-muted-foreground">Carregando…</p>}
      {!isLoading && sections.every((s) => s.items.length === 0) && (
        <div className="rounded-xl border border-dashed border-border bg-card/40 p-10 text-center text-sm text-muted-foreground">
          Nada urgente no momento. ✨
        </div>
      )}
      <div className="space-y-6">
        {sections.map((s) =>
          s.items.length === 0 ? null : (
            <div key={s.title}>
              <h2 className="mb-2 text-sm font-semibold">{s.title} <span className="ml-2 text-xs text-muted-foreground">({s.items.length})</span></h2>
              <div className="grid gap-3 md:grid-cols-2 xl:grid-cols-3">
                {s.items.map((p) => (
                  <div key={p.id} className={`rounded-xl border bg-card p-4 ${s.tone}`}>
                    <div className="flex items-center justify-between">
                      <p className="text-sm font-semibold">{p.codigo}</p>
                      <PriorityBadge priority={p.prioridade} />
                    </div>
                    <p className="mt-1 text-xs text-muted-foreground">{p.cliente?.nome ?? "—"}</p>
                    <p className="mt-1 text-xs text-muted-foreground">Entrega: {formatDateBR(p.data_entrega)}</p>
                    <div className="mt-2 flex flex-wrap gap-1">
                      <OrderStatusBadge status={p.status as never} />
                      <PaymentBadge status={p.status_pagamento} />
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )
        )}
      </div>
    </PageShell>
  );
}
