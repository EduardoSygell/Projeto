import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { useEffect, useMemo, useRef, useState } from "react";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { toast } from "sonner";
import {
  ArrowLeft, ArrowRight, Save, Trash2, Sparkles, Loader2, Wifi, WifiOff,
  AlertCircle, CheckCircle2, History, X, Send, FileText,
} from "lucide-react";
import { PageShell } from "@/components/page-shell";
import { Button } from "@/components/ui/button";
import { WizardProvider, useWizard } from "@/features/pedido-wizard/wizard-context";
import { Stepper, STEPS } from "@/features/pedido-wizard/stepper";
import { StepCliente } from "@/features/pedido-wizard/step-cliente";
import { StepPedido } from "@/features/pedido-wizard/step-pedido";
import { StepTecnicas } from "@/features/pedido-wizard/step-tecnicas";
import { StepFichas } from "@/features/pedido-wizard/step-fichas";
import { StepArquivos } from "@/features/pedido-wizard/step-arquivos";
import { StepPrecificacao } from "@/features/pedido-wizard/step-precificacao";
import { StepResumo } from "@/features/pedido-wizard/step-resumo";
import { db } from "@/lib/db";
import { totalPedido } from "@/features/pedido-wizard/pricing-engine";
import { validateWizard } from "@/features/pedido-wizard/validation";
import { runOrEnqueue } from "@/lib/sync-queue";
import type { Database } from "@/integrations/supabase/types";

type StatusPedido = Database["public"]["Enums"]["status_pedido"];

export const Route = createFileRoute("/pedido-novo")({
  head: () => ({ meta: [{ title: "Novo Pedido — VOX Control" }] }),
  component: () => (
    <WizardProvider>
      <Page />
    </WizardProvider>
  ),
});

function Page() {
  const [step, setStep] = useState(1);
  const stepRef = useRef<HTMLDivElement>(null);
  const { state, reset, saveDraft, lastSavedAt, draftRecovered, dismissRecoveryBanner } = useWizard();
  const navigate = useNavigate();
  const qc = useQueryClient();
  const [online, setOnline] = useState(typeof navigator !== "undefined" ? navigator.onLine : true);

  // Ao trocar de etapa, leva o topo do conteúdo para a viewport — respeitando
  // o header sticky via scroll-padding-top definido em styles.css.
  useEffect(() => {
    const el = stepRef.current;
    if (!el) return;
    // Preferir scrollIntoView com behavior smooth; em mobile evita salto
    // após teclado abrir/fechar.
    requestAnimationFrame(() => {
      el.scrollIntoView({ behavior: "smooth", block: "start" });
    });
  }, [step]);

  useEffect(() => {
    const up = () => setOnline(true);
    const down = () => setOnline(false);
    window.addEventListener("online", up);
    window.addEventListener("offline", down);
    return () => {
      window.removeEventListener("online", up);
      window.removeEventListener("offline", down);
    };
  }, []);

  const validation = useMemo(() => validateWizard(state), [state]);
  const stepErrors = validation.errors[step] ?? [];

  const next = () => {
    if (stepErrors.length > 0) {
      toast.error(stepErrors[0]);
      return;
    }
    setStep((s) => Math.min(7, s + 1));
  };

  /** Persiste o pedido. `statusFinal` define se vira orçamento ou já entra em produção. */
  const submit = useMutation({
    mutationFn: async (statusFinal: StatusPedido) => {
      const v = validateWizard(state);
      if (v.firstInvalidStep !== null) {
        setStep(v.firstInvalidStep);
        throw new Error(v.errors[v.firstInvalidStep][0] ?? "Há campos pendentes");
      }

      // 1. Cliente
      let clienteId = state.cliente.cliente_id;
      if (!clienteId) {
        const { data, error } = await db.from("clientes").insert({
          nome: state.cliente.nome.trim(),
          documento: state.cliente.documento || null,
          telefone: state.cliente.telefone || null,
          email: state.cliente.email || null,
          endereco: state.cliente.endereco || null,
          observacoes: state.cliente.observacoes || null,
          tipo: state.cliente.tipo,
          status: state.cliente.status,
          atencoes_producao: state.cliente.atencoes_producao || null,
          origem: state.cliente.origem || null,
        }).select("id").single();
        if (error) throw error;
        clienteId = data.id;
      }

      // 2. Totais
      const itensTot = state.itens.map((it) => ({
        valorTotal: ((it.override_unit ?? it.preco_sugerido ?? 0) * it.quantidade),
      }));
      const t = totalPedido(itensTot, {
        desconto: state.precificacao.desconto,
        acrescimo: state.precificacao.acrescimo,
        entrada: state.precificacao.entrada,
      });

      // 3. Pedido
      const { data: pedido, error: errP } = await db.from("pedidos").insert({
        codigo: state.pedido.codigo,
        cliente_id: clienteId!,
        status: statusFinal,
        prioridade: state.pedido.prioridade,
        data_entrega: state.pedido.data_entrega || null,
        data_limite_producao: state.pedido.data_limite_producao || null,
        valor_total: t.total,
        observacoes: state.pedido.observacoes || null,
        origem: state.pedido.origem || null,
        entrada_valor: t.entrada,
        desconto: state.precificacao.desconto,
        acrescimo: state.precificacao.acrescimo,
        margem_pct: state.precificacao.margem_pct,
      }).select("id").single();
      if (errP) throw errP;

      // 4. Itens + fichas + anexos vinculados
      for (const it of state.itens) {
        const unit = it.override_unit ?? it.preco_sugerido ?? 0;
        const { data: itemRow, error: errI } = await db.from("itens_pedido").insert({
          pedido_id: pedido.id,
          descricao: it.descricao,
          quantidade: it.quantidade,
          valor_unitario: unit,
          valor_total_calculado: unit * it.quantidade,
          tecnica: it.tecnica,
        }).select("id").single();
        if (errI) throw errI;

        const dados =
          it.tecnica === "DTF" ? it.ficha_dtf :
          it.tecnica === "DTG" ? it.ficha_dtg :
          it.tecnica === "BORDADO" ? it.ficha_bordado :
          it.ficha_prensa;

        if (dados) {
          await db.from("fichas_tecnicas").insert({
            pedido_id: pedido.id,
            item_id: itemRow.id,
            tecnica: it.tecnica,
            // eslint-disable-next-line @typescript-eslint/no-explicit-any
            dados: dados as any,
          });
        }

        for (const a of state.anexos.filter((x) => x.item_uid === it.uid)) {
          await db.from("anexos").insert({
            nome: a.nome, url: a.url, tipo: a.tipo,
            tamanho_bytes: a.tamanho, pedido_id: pedido.id, cliente_id: clienteId!,
            item_id: itemRow.id, categoria: a.categoria, status: a.status, descricao: a.descricao || null,
          });
        }
      }

      // 5. Anexos sem item
      for (const a of state.anexos.filter((x) => !x.item_uid)) {
        await db.from("anexos").insert({
          nome: a.nome, url: a.url, tipo: a.tipo,
          tamanho_bytes: a.tamanho, pedido_id: pedido.id, cliente_id: clienteId!,
          categoria: a.categoria, status: a.status, descricao: a.descricao || null,
        });
      }

      // 6. Financeiro
      if (t.total > 0) {
        await db.from("financeiro_receber").insert({
          pedido_id: pedido.id, cliente_id: clienteId!,
          descricao: `Pedido ${state.pedido.codigo}`,
          valor: t.total,
          vencimento: state.pedido.data_entrega || new Date().toISOString().slice(0, 10),
          status: t.entrada >= t.total ? "PAGO" : (t.entrada > 0 ? "PARCIAL" : "PENDENTE"),
          metodo_pagamento: state.precificacao.forma_pagamento,
        });
      }

      return { id: pedido.id, statusFinal };
    },
    onSuccess: (res) => {
      const msg = res.statusFinal === "ORCAMENTO" ? "Orçamento salvo" : "Pedido enviado para produção";
      toast.success(msg);
      qc.invalidateQueries();
      reset();
      navigate({ to: "/pedidos" });
    },
    onError: (e: Error) => toast.error(e.message),
  });

  const finalizar = async (statusFinal: StatusPedido) => {
    const r = await runOrEnqueue("pedido_completo", { ...state, statusFinal }, async () => {
      return await submit.mutateAsync(statusFinal);
    }).catch((e: Error) => { toast.error(e.message); return null; });
    if (r && !r.ok && r.queued) {
      toast.message("Sem conexão", {
        description: "Pedido salvo na fila — será enviado automaticamente ao reconectar.",
      });
      reset();
      navigate({ to: "/pedidos" });
    }
  };

  const totalAtual = useMemo(() => {
    const itensTot = state.itens.map((it) => ({
      valorTotal: ((it.override_unit ?? it.preco_sugerido ?? 0) * it.quantidade),
    }));
    return totalPedido(itensTot, {
      desconto: state.precificacao.desconto,
      acrescimo: state.precificacao.acrescimo,
      entrada: state.precificacao.entrada,
    });
  }, [state]);

  return (
    <PageShell
      title="Novo Cliente / Pedido Completo"
      description="Fluxo guiado para registrar tudo: do primeiro contato até a produção."
      actions={
        <div className="flex items-center gap-2">
          <span
            className={`inline-flex items-center gap-1 rounded-full px-2 py-1 text-[11px] font-medium ${
              online ? "bg-success/15 text-success" : "bg-destructive/15 text-destructive"
            }`}
          >
            {online ? <Wifi className="h-3 w-3" /> : <WifiOff className="h-3 w-3" />}
            {online ? "Online" : "Offline"}
          </span>
          <Button
            variant="ghost"
            onClick={() => {
              if (confirm("Descartar rascunho?")) {
                reset();
                setStep(1);
              }
            }}
          >
            <Trash2 className="mr-2 h-4 w-4" />
            Descartar
          </Button>
        </div>
      }
    >
      {draftRecovered && (
        <div className="flex items-start justify-between gap-3 rounded-xl border border-info/30 bg-info/10 p-3 text-sm">
          <div className="flex items-start gap-2">
            <History className="mt-0.5 h-4 w-4 text-info" />
            <div>
              <p className="font-medium">Rascunho recuperado</p>
              <p className="text-xs text-muted-foreground">
                Continuamos de onde você parou{lastSavedAt ? ` (último salvamento: ${formatRelative(lastSavedAt)})` : ""}.
              </p>
            </div>
          </div>
          <div className="flex items-center gap-2">
            <Button size="sm" variant="ghost" onClick={() => { reset(); setStep(1); }}>
              Começar do zero
            </Button>
            <Button size="icon" variant="ghost" onClick={dismissRecoveryBanner}>
              <X className="h-4 w-4" />
            </Button>
          </div>
        </div>
      )}

      <Stepper current={step} onJump={setStep} invalidSteps={validation.invalidSteps} />

      {stepErrors.length > 0 && (
        <div className="rounded-xl border border-destructive/30 bg-destructive/10 p-3 text-sm">
          <div className="mb-1 flex items-center gap-2 font-medium text-destructive">
            <AlertCircle className="h-4 w-4" /> Pendências nesta etapa
          </div>
          <ul className="ml-6 list-disc space-y-0.5 text-xs text-destructive/90">
            {stepErrors.map((e, i) => <li key={i}>{e}</li>)}
          </ul>
        </div>
      )}

      <div ref={stepRef} className="scroll-mt-20 rounded-xl border border-border bg-card p-5">
        {step === 1 && <StepCliente />}
        {step === 2 && <StepPedido />}
        {step === 3 && <StepTecnicas />}
        {step === 4 && <StepFichas />}
        {step === 5 && <StepArquivos />}
        {step === 6 && <StepPrecificacao />}
        {step === 7 && <StepResumo />}
      </div>

      <div className="flex flex-wrap items-center justify-between gap-2 rounded-xl border border-border bg-card/40 p-3">
        <Button variant="outline" disabled={step === 1} onClick={() => setStep((s) => Math.max(1, s - 1))}>
          <ArrowLeft className="mr-2 h-4 w-4" /> Voltar
        </Button>

        <div className="flex flex-wrap items-center gap-2">
          <span className="hidden text-xs text-muted-foreground md:inline">
            Etapa {step} de {STEPS.length}
          </span>
          <span className="inline-flex items-center gap-1 text-xs text-muted-foreground">
            <CheckCircle2 className="h-3 w-3 text-success" />
            {lastSavedAt ? `Rascunho salvo ${formatRelative(lastSavedAt)}` : "Rascunho automático ativo"}
          </span>
          <Button variant="ghost" size="sm" onClick={() => { saveDraft(); toast.success("Rascunho salvo"); }}>
            <Save className="mr-2 h-4 w-4" /> Salvar rascunho
          </Button>

          {step < 7 ? (
            <Button onClick={next} disabled={stepErrors.length > 0}>
              Próximo <ArrowRight className="ml-2 h-4 w-4" />
            </Button>
          ) : (
            <>
              <span className="rounded-md border border-border bg-background px-3 py-1.5 text-sm font-semibold">
                Total: {brl(totalAtual.total)}
              </span>
              <Button
                variant="outline"
                onClick={() => finalizar("ORCAMENTO")}
                disabled={submit.isPending || validation.invalidSteps.size > 0}
              >
                {submit.isPending ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : <FileText className="mr-2 h-4 w-4" />}
                Salvar como orçamento
              </Button>
              <Button
                onClick={() => finalizar("AGUARDANDO_ARTE")}
                disabled={submit.isPending || validation.invalidSteps.size > 0}
                className="bg-gradient-to-r from-primary to-info"
              >
                {submit.isPending ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : <Send className="mr-2 h-4 w-4" />}
                Enviar para produção
              </Button>
            </>
          )}
        </div>
      </div>

      {step === 7 && validation.invalidSteps.size > 0 && (
        <div className="rounded-xl border border-warning/30 bg-warning/10 p-3 text-xs">
          <p className="flex items-center gap-2 font-medium text-warning">
            <Sparkles className="h-3 w-3" /> Antes de finalizar, resolva as etapas marcadas em vermelho no topo.
          </p>
        </div>
      )}
    </PageShell>
  );
}

function brl(n: number) {
  return Number(n).toLocaleString("pt-BR", { style: "currency", currency: "BRL" });
}

function formatRelative(ts: number) {
  const diff = Date.now() - ts;
  if (diff < 5000) return "agora";
  if (diff < 60_000) return `há ${Math.round(diff / 1000)}s`;
  if (diff < 3_600_000) return `há ${Math.round(diff / 60_000)}min`;
  const d = new Date(ts);
  return `às ${d.toLocaleTimeString("pt-BR", { hour: "2-digit", minute: "2-digit" })}`;
}
