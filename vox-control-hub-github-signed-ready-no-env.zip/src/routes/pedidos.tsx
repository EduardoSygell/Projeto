import { createFileRoute } from "@tanstack/react-router";
import { useMemo, useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { toast } from "sonner";
import { Plus, KanbanSquare, Table as TableIcon, Pencil, Trash2 } from "lucide-react";
import { PageShell } from "@/components/page-shell";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import {
  Select, SelectContent, SelectItem, SelectTrigger, SelectValue,
} from "@/components/ui/select";
import {
  Dialog, DialogContent, DialogFooter, DialogHeader, DialogTitle, DialogTrigger,
} from "@/components/ui/dialog";
import {
  AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent,
  AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle, AlertDialogTrigger,
} from "@/components/ui/alert-dialog";
import { OrderStatusBadge, PriorityBadge, PaymentBadge } from "@/components/status-badge";
import { db, type Pedido, type Cliente, nextOrderCode } from "@/lib/db";
import { formatDateBR } from "@/lib/format";
import type { Database } from "@/integrations/supabase/types";

export const Route = createFileRoute("/pedidos")({
  head: () => ({ meta: [{ title: "Pedidos — VOX Control" }] }),
  component: Page,
});

type StatusPedido = Database["public"]["Enums"]["status_pedido"];
type StatusPagamento = Database["public"]["Enums"]["status_pagamento"];
type Prioridade = Database["public"]["Enums"]["prioridade"];

const STATUS_FLOW: { key: StatusPedido; label: string }[] = [
  { key: "ORCAMENTO", label: "Orçamento" },
  { key: "AGUARDANDO_ARTE", label: "Aguard. arte" },
  { key: "ARTE_APROVADA", label: "Arte aprovada" },
  { key: "EM_PRODUCAO", label: "Em produção" },
  { key: "PRONTO", label: "Pronto" },
  { key: "ENTREGUE", label: "Entregue" },
  { key: "CANCELADO", label: "Cancelado" },
];

const PRIORIDADES: Prioridade[] = ["BAIXA", "MEDIA", "ALTA", "URGENTE"];
const PAGAMENTOS: StatusPagamento[] = ["PENDENTE", "PARCIAL", "PAGO", "ATRASADO"];

const brl = (n: number) => n.toLocaleString("pt-BR", { style: "currency", currency: "BRL" });

type PedidoComCliente = Pedido & { cliente?: { nome: string } | null };

function Page() {
  const qc = useQueryClient();

  const { data: pedidos = [], isLoading } = useQuery({
    queryKey: ["pedidos"],
    queryFn: async () => {
      const { data, error } = await db
        .from("pedidos")
        .select("*, cliente:clientes(nome)")
        .order("created_at", { ascending: false });
      if (error) throw error;
      return data as PedidoComCliente[];
    },
  });

  const del = useMutation({
    mutationFn: async (id: string) => {
      const { error } = await db.from("pedidos").delete().eq("id", id);
      if (error) throw error;
    },
    onSuccess: () => {
      toast.success("Pedido removido");
      qc.invalidateQueries({ queryKey: ["pedidos"] });
    },
    onError: (e: Error) => toast.error(e.message),
  });

  return (
    <PageShell
      title="Pedidos"
      description="Fluxo completo: orçamento → produção → entrega."
      actions={<PedidoDialog trigger={<Button><Plus className="mr-2 h-4 w-4" />Novo pedido</Button>} />}
    >
      <Tabs defaultValue="tabela">
        <TabsList>
          <TabsTrigger value="tabela"><TableIcon className="mr-2 h-4 w-4" />Tabela</TabsTrigger>
          <TabsTrigger value="kanban"><KanbanSquare className="mr-2 h-4 w-4" />Kanban</TabsTrigger>
        </TabsList>

        <TabsContent value="tabela" className="mt-4">
          {isLoading ? (
            <p className="p-6 text-sm text-muted-foreground">Carregando…</p>
          ) : pedidos.length === 0 ? (
            <Empty />
          ) : (
            <div className="overflow-auto rounded-xl border border-border bg-card">
              <table className="w-full text-sm">
                <thead>
                  <tr className="border-b border-border text-left text-xs uppercase tracking-wider text-muted-foreground">
                    <th className="px-4 py-3">Código</th>
                    <th className="px-4 py-3">Cliente</th>
                    <th className="px-4 py-3">Entrega</th>
                    <th className="px-4 py-3">Status</th>
                    <th className="px-4 py-3">Pagto</th>
                    <th className="px-4 py-3">Prior.</th>
                    <th className="px-4 py-3 text-right">Total</th>
                    <th className="px-4 py-3" />
                  </tr>
                </thead>
                <tbody>
                  {pedidos.map((p) => (
                    <tr key={p.id} className="border-b border-border/60 hover:bg-muted/30">
                      <td className="px-4 py-3 font-medium">{p.codigo}</td>
                      <td className="px-4 py-3 text-muted-foreground">{p.cliente?.nome ?? "—"}</td>
                      <td className="px-4 py-3 text-muted-foreground">{formatDateBR(p.data_entrega)}</td>
                      <td className="px-4 py-3"><OrderStatusBadge status={p.status as never} /></td>
                      <td className="px-4 py-3"><PaymentBadge status={p.status_pagamento} /></td>
                      <td className="px-4 py-3"><PriorityBadge priority={p.prioridade} /></td>
                      <td className="px-4 py-3 text-right font-medium">{brl(Number(p.valor_total))}</td>
                      <td className="px-4 py-3 text-right">
                        <div className="flex justify-end gap-1">
                          <PedidoDialog pedido={p} trigger={<Button size="icon" variant="ghost"><Pencil className="h-4 w-4" /></Button>} />
                          <AlertDialog>
                            <AlertDialogTrigger asChild>
                              <Button size="icon" variant="ghost"><Trash2 className="h-4 w-4 text-destructive" /></Button>
                            </AlertDialogTrigger>
                            <AlertDialogContent>
                              <AlertDialogHeader>
                                <AlertDialogTitle>Remover {p.codigo}?</AlertDialogTitle>
                                <AlertDialogDescription>Esta ação removerá o pedido e seus itens.</AlertDialogDescription>
                              </AlertDialogHeader>
                              <AlertDialogFooter>
                                <AlertDialogCancel>Cancelar</AlertDialogCancel>
                                <AlertDialogAction onClick={() => del.mutate(p.id)}>Remover</AlertDialogAction>
                              </AlertDialogFooter>
                            </AlertDialogContent>
                          </AlertDialog>
                        </div>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </TabsContent>

        <TabsContent value="kanban" className="mt-4">
          <Kanban pedidos={pedidos} />
        </TabsContent>
      </Tabs>
    </PageShell>
  );
}

function Empty() {
  return (
    <div className="rounded-xl border border-dashed border-border bg-card/40 p-10 text-center text-sm text-muted-foreground">
      Nenhum pedido cadastrado. Clique em <strong>Novo pedido</strong>.
    </div>
  );
}

function Kanban({ pedidos }: { pedidos: PedidoComCliente[] }) {
  const grouped = useMemo(() => {
    const g: Record<string, PedidoComCliente[]> = {};
    for (const c of STATUS_FLOW) g[c.key] = [];
    for (const p of pedidos) (g[p.status] ??= []).push(p);
    return g;
  }, [pedidos]);

  return (
    <div className="overflow-x-auto pb-2">
      <div className="flex min-w-max gap-3">
        {STATUS_FLOW.map((col) => (
          <div key={col.key} className="w-72 shrink-0 rounded-xl border border-border bg-card/50 p-3">
            <div className="mb-3 flex items-center justify-between">
              <h3 className="text-xs font-semibold uppercase tracking-wider text-muted-foreground">{col.label}</h3>
              <span className="rounded-full bg-muted px-2 py-0.5 text-xs">{grouped[col.key]?.length ?? 0}</span>
            </div>
            <div className="space-y-2">
              {(grouped[col.key] ?? []).map((p) => (
                <div key={p.id} className="rounded-lg border border-border bg-background p-3">
                  <div className="flex items-center justify-between">
                    <p className="text-sm font-semibold">{p.codigo}</p>
                    <PriorityBadge priority={p.prioridade} />
                  </div>
                  <p className="mt-1 text-xs text-muted-foreground">{p.cliente?.nome ?? "—"}</p>
                  <div className="mt-2 flex items-center justify-between text-xs">
                    <span className="text-muted-foreground">{formatDateBR(p.data_entrega)}</span>
                    <span className="font-medium">{brl(Number(p.valor_total))}</span>
                  </div>
                </div>
              ))}
              {(grouped[col.key] ?? []).length === 0 && (
                <p className="rounded-lg border border-dashed border-border/60 py-3 text-center text-xs text-muted-foreground">Vazio</p>
              )}
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}

function PedidoDialog({ pedido, trigger }: { pedido?: Pedido; trigger: React.ReactNode }) {
  const [open, setOpen] = useState(false);
  const qc = useQueryClient();

  const { data: clientes = [] } = useQuery({
    queryKey: ["clientes-min"],
    queryFn: async () => {
      const { data, error } = await db.from("clientes").select("id,nome").order("nome");
      if (error) throw error;
      return data as Pick<Cliente, "id" | "nome">[];
    },
    enabled: open,
  });

  const [form, setForm] = useState({
    codigo: pedido?.codigo ?? nextOrderCode(),
    cliente_id: pedido?.cliente_id ?? "",
    valor_total: String(pedido?.valor_total ?? ""),
    data_entrega: pedido?.data_entrega ?? "",
    status: (pedido?.status ?? "ORCAMENTO") as StatusPedido,
    status_pagamento: (pedido?.status_pagamento ?? "PENDENTE") as StatusPagamento,
    prioridade: (pedido?.prioridade ?? "MEDIA") as Prioridade,
    observacoes: pedido?.observacoes ?? "",
  });

  const save = useMutation({
    mutationFn: async () => {
      if (!form.codigo.trim()) throw new Error("Código é obrigatório");
      if (!form.cliente_id) throw new Error("Selecione o cliente");
      const payload = {
        codigo: form.codigo.trim(),
        cliente_id: form.cliente_id,
        valor_total: Number(form.valor_total) || 0,
        data_entrega: form.data_entrega || null,
        status: form.status,
        status_pagamento: form.status_pagamento,
        prioridade: form.prioridade,
        observacoes: form.observacoes || null,
      };
      if (pedido) {
        const { error } = await db.from("pedidos").update(payload).eq("id", pedido.id);
        if (error) throw error;
      } else {
        const { error } = await db.from("pedidos").insert(payload);
        if (error) throw error;
      }
    },
    onSuccess: () => {
      toast.success(pedido ? "Pedido atualizado" : "Pedido criado");
      qc.invalidateQueries({ queryKey: ["pedidos"] });
      qc.invalidateQueries({ queryKey: ["dashboard"] });
      setOpen(false);
    },
    onError: (e: Error) => toast.error(e.message),
  });

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild>{trigger}</DialogTrigger>
      <DialogContent className="max-w-2xl">
        <DialogHeader>
          <DialogTitle>{pedido ? `Editar ${pedido.codigo}` : "Novo pedido"}</DialogTitle>
        </DialogHeader>
        <div className="grid gap-3 sm:grid-cols-2">
          <div>
            <Label>Código *</Label>
            <Input value={form.codigo} onChange={(e) => setForm({ ...form, codigo: e.target.value })} />
          </div>
          <div>
            <Label>Cliente *</Label>
            <Select value={form.cliente_id} onValueChange={(v) => setForm({ ...form, cliente_id: v })}>
              <SelectTrigger><SelectValue placeholder="Selecione" /></SelectTrigger>
              <SelectContent>
                {clientes.length === 0 && <div className="px-3 py-2 text-xs text-muted-foreground">Cadastre um cliente primeiro</div>}
                {clientes.map((c) => <SelectItem key={c.id} value={c.id}>{c.nome}</SelectItem>)}
              </SelectContent>
            </Select>
          </div>
          <div>
            <Label>Valor total (R$)</Label>
            <Input type="number" step="0.01" value={form.valor_total} onChange={(e) => setForm({ ...form, valor_total: e.target.value })} />
          </div>
          <div>
            <Label>Data de entrega</Label>
            <Input type="date" value={form.data_entrega ?? ""} onChange={(e) => setForm({ ...form, data_entrega: e.target.value })} />
          </div>
          <div>
            <Label>Status</Label>
            <Select value={form.status} onValueChange={(v) => setForm({ ...form, status: v as StatusPedido })}>
              <SelectTrigger><SelectValue /></SelectTrigger>
              <SelectContent>
                {STATUS_FLOW.map((s) => <SelectItem key={s.key} value={s.key}>{s.label}</SelectItem>)}
              </SelectContent>
            </Select>
          </div>
          <div>
            <Label>Pagamento</Label>
            <Select value={form.status_pagamento} onValueChange={(v) => setForm({ ...form, status_pagamento: v as StatusPagamento })}>
              <SelectTrigger><SelectValue /></SelectTrigger>
              <SelectContent>
                {PAGAMENTOS.map((s) => <SelectItem key={s} value={s}>{s}</SelectItem>)}
              </SelectContent>
            </Select>
          </div>
          <div>
            <Label>Prioridade</Label>
            <Select value={form.prioridade} onValueChange={(v) => setForm({ ...form, prioridade: v as Prioridade })}>
              <SelectTrigger><SelectValue /></SelectTrigger>
              <SelectContent>
                {PRIORIDADES.map((s) => <SelectItem key={s} value={s}>{s}</SelectItem>)}
              </SelectContent>
            </Select>
          </div>
          <div className="sm:col-span-2">
            <Label>Observações</Label>
            <Textarea rows={3} value={form.observacoes ?? ""} onChange={(e) => setForm({ ...form, observacoes: e.target.value })} />
          </div>
        </div>
        <DialogFooter>
          <Button variant="ghost" onClick={() => setOpen(false)}>Cancelar</Button>
          <Button onClick={() => save.mutate()} disabled={save.isPending}>
            {save.isPending ? "Salvando..." : "Salvar"}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
