import { createFileRoute } from "@tanstack/react-router";
import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { toast } from "sonner";
import { Plus, Trash2, ExternalLink } from "lucide-react";
import { PageShell } from "@/components/page-shell";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import {
  Select, SelectContent, SelectItem, SelectTrigger, SelectValue,
} from "@/components/ui/select";
import {
  Dialog, DialogContent, DialogFooter, DialogHeader, DialogTitle, DialogTrigger,
} from "@/components/ui/dialog";
import { db } from "@/lib/db";
import { formatDateBR } from "@/lib/format";
import type { Database } from "@/integrations/supabase/types";

export const Route = createFileRoute("/aprovacao")({
  head: () => ({ meta: [{ title: "Aprovação de Arte — VOX Control" }] }),
  component: Page,
});

type StatusArte = Database["public"]["Enums"]["status_arte"];
type Arte = Database["public"]["Tables"]["artes"]["Row"];
type Pedido = Database["public"]["Tables"]["pedidos"]["Row"];

const STATUS: StatusArte[] = ["PENDENTE", "ENVIADA", "APROVADA", "AJUSTES", "REJEITADA"];

const statusCls: Record<StatusArte, string> = {
  PENDENTE: "bg-muted text-muted-foreground",
  ENVIADA: "bg-info/15 text-info border border-info/30",
  APROVADA: "bg-success/15 text-success border border-success/30",
  AJUSTES: "bg-warning/15 text-warning border border-warning/30",
  REJEITADA: "bg-destructive/15 text-destructive border border-destructive/30",
};

function Page() {
  const qc = useQueryClient();
  const [filter, setFilter] = useState<StatusArte | "ALL">("ALL");

  const { data = [], isLoading } = useQuery({
    queryKey: ["artes"],
    queryFn: async () => {
      const { data, error } = await db
        .from("artes")
        .select("*, pedido:pedidos(codigo, cliente_id, cliente:clientes(nome))")
        .order("created_at", { ascending: false });
      if (error) throw error;
      return data as (Arte & { pedido?: { codigo: string; cliente?: { nome: string } | null } | null })[];
    },
  });

  const updateStatus = useMutation({
    mutationFn: async ({ id, status }: { id: string; status: StatusArte }) => {
      const { error } = await db.from("artes").update({ status }).eq("id", id);
      if (error) throw error;
    },
    onSuccess: () => { toast.success("Status atualizado"); qc.invalidateQueries({ queryKey: ["artes"] }); },
    onError: (e: Error) => toast.error(e.message),
  });

  const del = useMutation({
    mutationFn: async (id: string) => {
      const { error } = await db.from("artes").delete().eq("id", id);
      if (error) throw error;
    },
    onSuccess: () => { toast.success("Arte removida"); qc.invalidateQueries({ queryKey: ["artes"] }); },
  });

  const filtered = filter === "ALL" ? data : data.filter((a) => a.status === filter);

  return (
    <PageShell
      title="Aprovação de Arte"
      description="Acompanhe artes enviadas, ajustes e aprovações dos clientes."
      actions={<NovaArteDialog />}
    >
      <div className="flex flex-wrap gap-2">
        <Button size="sm" variant={filter === "ALL" ? "default" : "outline"} onClick={() => setFilter("ALL")}>Todos</Button>
        {STATUS.map((s) => (
          <Button key={s} size="sm" variant={filter === s ? "default" : "outline"} onClick={() => setFilter(s)}>{s}</Button>
        ))}
      </div>

      {isLoading ? <p className="text-sm text-muted-foreground">Carregando…</p> : filtered.length === 0 ? (
        <div className="rounded-xl border border-dashed border-border bg-card/40 p-10 text-center text-sm text-muted-foreground">
          Nenhuma arte cadastrada.
        </div>
      ) : (
        <div className="grid gap-4 md:grid-cols-2 xl:grid-cols-3">
          {filtered.map((a) => (
            <div key={a.id} className="rounded-xl border border-border bg-card p-5">
              <div className="flex items-start justify-between gap-2">
                <div className="min-w-0">
                  <p className="truncate text-sm font-semibold">{a.nome}</p>
                  <p className="mt-0.5 text-xs text-muted-foreground">
                    {a.pedido?.codigo ?? "Sem pedido"} · {a.pedido?.cliente?.nome ?? "—"}
                  </p>
                  <p className="text-xs text-muted-foreground">v{a.versao} · {formatDateBR(a.created_at)}</p>
                </div>
                <span className={`inline-flex items-center rounded-full px-2.5 py-0.5 text-xs font-medium ${statusCls[a.status]}`}>
                  {a.status}
                </span>
              </div>
              {a.arquivo_url && (
                <a href={a.arquivo_url} target="_blank" rel="noreferrer" className="mt-3 inline-flex items-center gap-1 text-xs text-info hover:underline">
                  <ExternalLink className="h-3 w-3" /> Ver arquivo
                </a>
              )}
              <div className="mt-4 flex items-center gap-2">
                <Select value={a.status} onValueChange={(v) => updateStatus.mutate({ id: a.id, status: v as StatusArte })}>
                  <SelectTrigger className="h-8 text-xs"><SelectValue /></SelectTrigger>
                  <SelectContent>{STATUS.map((s) => <SelectItem key={s} value={s}>{s}</SelectItem>)}</SelectContent>
                </Select>
                <Button size="icon" variant="ghost" onClick={() => del.mutate(a.id)}>
                  <Trash2 className="h-4 w-4 text-destructive" />
                </Button>
              </div>
            </div>
          ))}
        </div>
      )}
    </PageShell>
  );
}

function NovaArteDialog() {
  const [open, setOpen] = useState(false);
  const qc = useQueryClient();
  const [form, setForm] = useState({ nome: "", pedido_id: "", arquivo_url: "", versao: 1, status: "PENDENTE" as StatusArte, feedback: "" });

  const { data: pedidos = [] } = useQuery({
    queryKey: ["pedidos-min"],
    queryFn: async () => {
      const { data, error } = await db.from("pedidos").select("id, codigo, cliente:clientes(nome)").order("created_at", { ascending: false }).limit(200);
      if (error) throw error;
      return data as (Pick<Pedido, "id" | "codigo"> & { cliente?: { nome: string } | null })[];
    },
    enabled: open,
  });

  const save = useMutation({
    mutationFn: async () => {
      if (!form.nome.trim()) throw new Error("Nome é obrigatório");
      if (!form.pedido_id) throw new Error("Selecione o pedido");
      const { error } = await db.from("artes").insert({
        nome: form.nome.trim(),
        pedido_id: form.pedido_id,
        arquivo_url: form.arquivo_url || null,
        versao: Number(form.versao) || 1,
        status: form.status,
      });
      if (error) throw error;
    },
    onSuccess: () => {
      toast.success("Arte cadastrada");
      qc.invalidateQueries({ queryKey: ["artes"] });
      setOpen(false);
      setForm({ nome: "", pedido_id: "", arquivo_url: "", versao: 1, status: "PENDENTE", feedback: "" });
    },
    onError: (e: Error) => toast.error(e.message),
  });

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild><Button><Plus className="mr-2 h-4 w-4" />Nova arte</Button></DialogTrigger>
      <DialogContent>
        <DialogHeader><DialogTitle>Nova arte</DialogTitle></DialogHeader>
        <div className="space-y-3">
          <div><Label>Nome *</Label><Input value={form.nome} onChange={(e) => setForm({ ...form, nome: e.target.value })} /></div>
          <div>
            <Label>Pedido *</Label>
            <Select value={form.pedido_id} onValueChange={(v) => setForm({ ...form, pedido_id: v })}>
              <SelectTrigger><SelectValue placeholder="Selecione…" /></SelectTrigger>
              <SelectContent>
                {pedidos.map((p) => (
                  <SelectItem key={p.id} value={p.id}>{p.codigo} — {p.cliente?.nome ?? "—"}</SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
          <div><Label>Link do arquivo</Label><Input placeholder="https://…" value={form.arquivo_url} onChange={(e) => setForm({ ...form, arquivo_url: e.target.value })} /></div>
          <div className="grid grid-cols-2 gap-3">
            <div><Label>Versão</Label><Input type="number" min={1} value={form.versao} onChange={(e) => setForm({ ...form, versao: Number(e.target.value) })} /></div>
            <div>
              <Label>Status</Label>
              <Select value={form.status} onValueChange={(v) => setForm({ ...form, status: v as StatusArte })}>
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent>{STATUS.map((s) => <SelectItem key={s} value={s}>{s}</SelectItem>)}</SelectContent>
              </Select>
            </div>
          </div>
          <div><Label>Feedback (opcional)</Label><Textarea rows={3} value={form.feedback} onChange={(e) => setForm({ ...form, feedback: e.target.value })} /></div>
        </div>
        <DialogFooter>
          <Button variant="ghost" onClick={() => setOpen(false)}>Cancelar</Button>
          <Button onClick={() => save.mutate()} disabled={save.isPending}>Salvar</Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
