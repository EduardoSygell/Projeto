import { createFileRoute } from "@tanstack/react-router";
import { PageShell } from "@/components/page-shell";
import { MessageCircle, Package, HardDrive, CreditCard, FileText } from "lucide-react";

export const Route = createFileRoute("/integracoes")({
  head: () => ({ meta: [{ title: "Integrações — VOX Control" }] }),
  component: () => {
    const items = [
      { icon: MessageCircle, name: "WhatsApp", desc: "Notificações e aprovação de arte." },
      { icon: Package, name: "Bling", desc: "Sincronização de pedidos e estoque." },
      { icon: Package, name: "Tiny ERP", desc: "Gestão fiscal e logística." },
      { icon: HardDrive, name: "Google Drive", desc: "Backup e armazenamento de artes." },
      { icon: CreditCard, name: "Pagamentos", desc: "Cobranças via Pix, cartão e boleto." },
      { icon: FileText, name: "Emissão Fiscal", desc: "NF-e / NFS-e automatizada." },
    ];
    return (
      <PageShell title="Integrações" description="Conexões externas (em breve).">
        <div className="grid gap-4 md:grid-cols-2 xl:grid-cols-3">
          {items.map((it) => (
            <div key={it.name} className="rounded-xl border border-border bg-card p-5">
              <div className="flex items-center gap-3">
                <div className="rounded-lg bg-muted p-2 text-info"><it.icon className="h-5 w-5" /></div>
                <div>
                  <p className="text-sm font-semibold">{it.name}</p>
                  <p className="text-xs text-muted-foreground">{it.desc}</p>
                </div>
              </div>
              <p className="mt-4 text-xs uppercase tracking-wider text-warning">Em breve</p>
            </div>
          ))}
        </div>
      </PageShell>
    );
  },
});
