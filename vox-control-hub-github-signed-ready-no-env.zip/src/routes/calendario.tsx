import { createFileRoute, Link } from "@tanstack/react-router";
import { useMemo, useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { toast } from "sonner";
import {
  Plus,
  Trash2,
  CalendarClock,
  ChevronLeft,
  ChevronRight,
  Truck,
  Filter,
  Download,
  FileText,
  CalendarDays,
} from "lucide-react";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { gerarCalendarioPDF, gerarCalendarioICS } from "@/lib/calendario-export";
import { PageShell } from "@/components/page-shell";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import {
  Dialog,
  DialogContent,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import {
  Sheet,
  SheetContent,
  SheetDescription,
  SheetHeader,
  SheetTitle,
} from "@/components/ui/sheet";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Popover,
  PopoverContent,
  PopoverTrigger,
} from "@/components/ui/popover";
import { Checkbox } from "@/components/ui/checkbox";
import { db } from "@/lib/db";
import type { Database } from "@/integrations/supabase/types";
import { cn } from "@/lib/utils";

export const Route = createFileRoute("/calendario")({
  head: () => ({ meta: [{ title: "Calendário — VOX Control" }] }),
  component: Page,
});

type Evento = Database["public"]["Tables"]["calendario_eventos"]["Row"];
type StatusPedido = Database["public"]["Enums"]["status_pedido"];

type PedidoEntrega = {
  id: string;
  codigo: string;
  status: StatusPedido;
  prioridade: string;
  data_entrega: string;
  cliente: { nome: string } | null;
};

type ViewMode = "mes" | "semana";

const STATUS_PEDIDO: StatusPedido[] = [
  "ORCAMENTO",
  "AGUARDANDO_ARTE",
  "ARTE_APROVADA",
  "EM_PRODUCAO",
  "PRONTO",
  "ENTREGUE",
  "CANCELADO",
];

const STATUS_LABEL: Record<StatusPedido, string> = {
  ORCAMENTO: "Orçamento",
  AGUARDANDO_ARTE: "Aguard. arte",
  ARTE_APROVADA: "Arte aprovada",
  EM_PRODUCAO: "Em produção",
  PRONTO: "Pronto",
  ENTREGUE: "Entregue",
  CANCELADO: "Cancelado",
};

const STATUS_DOT: Record<StatusPedido, string> = {
  ORCAMENTO: "bg-muted-foreground",
  AGUARDANDO_ARTE: "bg-warning",
  ARTE_APROVADA: "bg-info",
  EM_PRODUCAO: "bg-primary",
  PRONTO: "bg-success",
  ENTREGUE: "bg-success",
  CANCELADO: "bg-destructive",
};

const STATUS_BADGE: Record<StatusPedido, string> = {
  ORCAMENTO: "bg-muted text-muted-foreground",
  AGUARDANDO_ARTE: "bg-warning/15 text-warning",
  ARTE_APROVADA: "bg-info/15 text-info",
  EM_PRODUCAO: "bg-primary/15 text-primary",
  PRONTO: "bg-success/15 text-success",
  ENTREGUE: "bg-success/20 text-success",
  CANCELADO: "bg-destructive/15 text-destructive",
};

const WEEKDAYS = ["Dom", "Seg", "Ter", "Qua", "Qui", "Sex", "Sáb"];

// ---------- date helpers ----------
const startOfDay = (d: Date) => {
  const x = new Date(d);
  x.setHours(0, 0, 0, 0);
  return x;
};
const endOfDay = (d: Date) => {
  const x = new Date(d);
  x.setHours(23, 59, 59, 999);
  return x;
};
const addDays = (d: Date, n: number) => {
  const x = new Date(d);
  x.setDate(x.getDate() + n);
  return x;
};
const startOfWeek = (d: Date) => addDays(startOfDay(d), -d.getDay());
const endOfWeek = (d: Date) => endOfDay(addDays(startOfWeek(d), 6));
const startOfMonthGrid = (d: Date) =>
  startOfWeek(new Date(d.getFullYear(), d.getMonth(), 1));
const endOfMonthGrid = (d: Date) =>
  endOfWeek(new Date(d.getFullYear(), d.getMonth() + 1, 0));
const isSameDay = (a: Date, b: Date) =>
  a.getFullYear() === b.getFullYear() &&
  a.getMonth() === b.getMonth() &&
  a.getDate() === b.getDate();
const isoDay = (d: Date) =>
  `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}-${String(
    d.getDate(),
  ).padStart(2, "0")}`;

function fmtTime(dt: string | null) {
  if (!dt) return "";
  const d = new Date(dt);
  return d.toLocaleTimeString("pt-BR", { hour: "2-digit", minute: "2-digit" });
}

function Page() {
  const qc = useQueryClient();
  const [viewMode, setViewMode] = useState<ViewMode>("mes");
  const [cursor, setCursor] = useState<Date>(new Date());
  const [selectedDay, setSelectedDay] = useState<Date | null>(null);
  const [statusFilter, setStatusFilter] = useState<StatusPedido[]>([
    ...STATUS_PEDIDO.filter((s) => s !== "ENTREGUE" && s !== "CANCELADO"),
  ]);
  const [showEntregas, setShowEntregas] = useState(true);
  const [showEventos, setShowEventos] = useState(true);
  const [tipoFilter, setTipoFilter] = useState<string>("__all__");
  const [novoEventoOpen, setNovoEventoOpen] = useState(false);
  const [novoEventoDate, setNovoEventoDate] = useState<Date | null>(null);

  const { rangeStart, rangeEnd } = useMemo(() => {
    if (viewMode === "mes") {
      return { rangeStart: startOfMonthGrid(cursor), rangeEnd: endOfMonthGrid(cursor) };
    }
    return { rangeStart: startOfWeek(cursor), rangeEnd: endOfWeek(cursor) };
  }, [cursor, viewMode]);

  const days = useMemo(() => {
    const arr: Date[] = [];
    for (let d = new Date(rangeStart); d <= rangeEnd; d = addDays(d, 1)) {
      arr.push(new Date(d));
    }
    return arr;
  }, [rangeStart, rangeEnd]);

  const { data: eventos = [] } = useQuery({
    queryKey: ["eventos", isoDay(rangeStart), isoDay(rangeEnd)],
    queryFn: async () => {
      const { data, error } = await db
        .from("calendario_eventos")
        .select("*")
        .gte("inicio", rangeStart.toISOString())
        .lte("inicio", rangeEnd.toISOString())
        .order("inicio", { ascending: true });
      if (error) throw error;
      return data as Evento[];
    },
  });

  const { data: pedidos = [] } = useQuery({
    queryKey: ["pedidos-entrega", isoDay(rangeStart), isoDay(rangeEnd)],
    queryFn: async () => {
      const { data, error } = await db
        .from("pedidos")
        .select("id, codigo, status, prioridade, data_entrega, cliente:clientes(nome)")
        .not("data_entrega", "is", null)
        .gte("data_entrega", isoDay(rangeStart))
        .lte("data_entrega", isoDay(rangeEnd));
      if (error) throw error;
      return (data ?? []) as unknown as PedidoEntrega[];
    },
  });

  const tiposDisponiveis = useMemo(() => {
    const s = new Set<string>();
    eventos.forEach((e) => e.tipo && s.add(e.tipo));
    return Array.from(s).sort();
  }, [eventos]);

  const eventosFiltrados = useMemo(() => {
    if (!showEventos) return [];
    return eventos.filter(
      (e) => tipoFilter === "__all__" || e.tipo === tipoFilter,
    );
  }, [eventos, showEventos, tipoFilter]);

  const entregasFiltradas = useMemo(() => {
    if (!showEntregas) return [];
    return pedidos.filter((p) => statusFilter.includes(p.status));
  }, [pedidos, showEntregas, statusFilter]);

  const byDay = useMemo(() => {
    const m = new Map<string, { eventos: Evento[]; entregas: PedidoEntrega[] }>();
    days.forEach((d) => m.set(isoDay(d), { eventos: [], entregas: [] }));
    eventosFiltrados.forEach((e) => {
      const k = isoDay(new Date(e.inicio));
      const slot = m.get(k);
      if (slot) slot.eventos.push(e);
    });
    entregasFiltradas.forEach((p) => {
      const k = p.data_entrega.slice(0, 10);
      const slot = m.get(k);
      if (slot) slot.entregas.push(p);
    });
    return m;
  }, [days, eventosFiltrados, entregasFiltradas]);

  const today = new Date();
  const headerLabel =
    viewMode === "mes"
      ? cursor.toLocaleDateString("pt-BR", { month: "long", year: "numeric" })
      : `${rangeStart.toLocaleDateString("pt-BR", { day: "2-digit", month: "short" })} – ${rangeEnd.toLocaleDateString("pt-BR", { day: "2-digit", month: "short" })}`;

  const move = (dir: -1 | 1) => {
    const next = new Date(cursor);
    if (viewMode === "mes") next.setMonth(next.getMonth() + dir);
    else next.setDate(next.getDate() + dir * 7);
    setCursor(next);
  };

  const openNovoEvento = (d?: Date) => {
    setNovoEventoDate(d ?? null);
    setNovoEventoOpen(true);
  };

  const selectedSlot = selectedDay ? byDay.get(isoDay(selectedDay)) : null;

  return (
    <PageShell
      title="Calendário"
      description="Eventos e entregas previstas em visualização visual."
      actions={
        <div className="flex items-center gap-2">
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button variant="outline" size="sm">
                <Download className="mr-2 h-4 w-4" />
                Exportar
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="end">
              <DropdownMenuItem
                onClick={async () => {
                  await gerarCalendarioPDF(
                    eventosFiltrados.map((e) => ({
                      id: e.id,
                      titulo: e.titulo,
                      tipo: e.tipo,
                      inicio: e.inicio,
                      fim: e.fim,
                      local: null,
                      descricao: e.descricao,
                    })),
                    entregasFiltradas.map((p) => ({
                      id: p.id,
                      codigo: p.codigo,
                      cliente: p.cliente?.nome ?? null,
                      status: STATUS_LABEL[p.status],
                      prioridade: p.prioridade,
                      data_entrega: p.data_entrega.slice(0, 10),
                    })),
                    headerLabel,
                  );
                  toast.success("PDF gerado");
                }}
              >
                <FileText className="mr-2 h-4 w-4" />
                PDF do período
              </DropdownMenuItem>
              <DropdownMenuItem
                onClick={async () => {
                  await gerarCalendarioICS(
                    eventosFiltrados.map((e) => ({
                      id: e.id,
                      titulo: e.titulo,
                      tipo: e.tipo,
                      inicio: e.inicio,
                      fim: e.fim,
                      local: null,
                      descricao: e.descricao,
                    })),
                    entregasFiltradas.map((p) => ({
                      id: p.id,
                      codigo: p.codigo,
                      cliente: p.cliente?.nome ?? null,
                      status: STATUS_LABEL[p.status],
                      prioridade: p.prioridade,
                      data_entrega: p.data_entrega.slice(0, 10),
                    })),
                    headerLabel,
                  );
                  toast.success("ICS gerado");
                }}
              >
                <CalendarDays className="mr-2 h-4 w-4" />
                ICS (calendário)
              </DropdownMenuItem>
            </DropdownMenuContent>
          </DropdownMenu>
          <Button onClick={() => openNovoEvento()}>
            <Plus className="mr-2 h-4 w-4" />
            Novo evento
          </Button>
        </div>
      }
    >
      {/* Toolbar */}
      <div className="mb-4 flex flex-col gap-3">
        <div className="flex flex-wrap items-center gap-2">
          <div className="flex items-center gap-1 rounded-lg border border-border bg-card p-1">
            <Button size="icon" variant="ghost" className="h-8 w-8" onClick={() => move(-1)}>
              <ChevronLeft className="h-4 w-4" />
            </Button>
            <button
              onClick={() => setCursor(new Date())}
              className="px-3 text-xs font-semibold uppercase tracking-wider text-muted-foreground hover:text-foreground"
            >
              Hoje
            </button>
            <Button size="icon" variant="ghost" className="h-8 w-8" onClick={() => move(1)}>
              <ChevronRight className="h-4 w-4" />
            </Button>
          </div>
          <h2 className="text-sm font-semibold capitalize">{headerLabel}</h2>
          <div className="ml-auto flex items-center gap-1 rounded-lg border border-border bg-card p-1">
            {(["mes", "semana"] as ViewMode[]).map((m) => (
              <button
                key={m}
                onClick={() => setViewMode(m)}
                className={cn(
                  "rounded-md px-3 py-1 text-xs font-semibold uppercase tracking-wider transition",
                  viewMode === m
                    ? "bg-primary text-primary-foreground"
                    : "text-muted-foreground hover:text-foreground",
                )}
              >
                {m === "mes" ? "Mês" : "Semana"}
              </button>
            ))}
          </div>
        </div>

        <div className="flex flex-wrap items-center gap-2">
          <Popover>
            <PopoverTrigger asChild>
              <Button variant="outline" size="sm" className="h-8">
                <Filter className="mr-2 h-3.5 w-3.5" />
                Status ({statusFilter.length})
              </Button>
            </PopoverTrigger>
            <PopoverContent align="start" className="w-56 p-2">
              <div className="space-y-1">
                {STATUS_PEDIDO.map((s) => (
                  <label
                    key={s}
                    className="flex cursor-pointer items-center gap-2 rounded px-2 py-1.5 text-sm hover:bg-muted"
                  >
                    <Checkbox
                      checked={statusFilter.includes(s)}
                      onCheckedChange={(v) =>
                        setStatusFilter((prev) =>
                          v ? [...prev, s] : prev.filter((x) => x !== s),
                        )
                      }
                    />
                    <span className={cn("h-2 w-2 rounded-full", STATUS_DOT[s])} />
                    {STATUS_LABEL[s]}
                  </label>
                ))}
              </div>
            </PopoverContent>
          </Popover>

          <Select value={tipoFilter} onValueChange={setTipoFilter}>
            <SelectTrigger className="h-8 w-[160px]">
              <SelectValue placeholder="Tipo evento" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="__all__">Todos os tipos</SelectItem>
              {tiposDisponiveis.map((t) => (
                <SelectItem key={t} value={t}>
                  {t}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>

          <label className="flex cursor-pointer items-center gap-1.5 text-xs text-muted-foreground">
            <Checkbox
              checked={showEntregas}
              onCheckedChange={(v) => setShowEntregas(!!v)}
            />
            Entregas
          </label>
          <label className="flex cursor-pointer items-center gap-1.5 text-xs text-muted-foreground">
            <Checkbox
              checked={showEventos}
              onCheckedChange={(v) => setShowEventos(!!v)}
            />
            Eventos
          </label>
        </div>
      </div>

      {/* Calendar */}
      {viewMode === "mes" ? (
        <MesGrid
          days={days}
          cursor={cursor}
          today={today}
          byDay={byDay}
          onSelect={setSelectedDay}
        />
      ) : (
        <SemanaList days={days} today={today} byDay={byDay} onSelect={setSelectedDay} />
      )}

      {/* Day sheet */}
      <Sheet open={!!selectedDay} onOpenChange={(o) => !o && setSelectedDay(null)}>
        <SheetContent className="w-full sm:max-w-md overflow-y-auto">
          <SheetHeader>
            <SheetTitle className="capitalize">
              {selectedDay?.toLocaleDateString("pt-BR", {
                weekday: "long",
                day: "2-digit",
                month: "long",
                year: "numeric",
              })}
            </SheetTitle>
            <SheetDescription>
              {(selectedSlot?.eventos.length ?? 0) +
                (selectedSlot?.entregas.length ?? 0)}{" "}
              item(ns) neste dia
            </SheetDescription>
          </SheetHeader>

          <div className="mt-6 space-y-6">
            {/* Entregas */}
            <section>
              <h3 className="mb-2 text-xs font-semibold uppercase tracking-wider text-muted-foreground">
                Entregas previstas
              </h3>
              {selectedSlot && selectedSlot.entregas.length > 0 ? (
                <div className="space-y-2">
                  {selectedSlot.entregas.map((p) => (
                    <div
                      key={p.id}
                      className="flex items-start gap-3 rounded-xl border border-border bg-card p-3"
                    >
                      <div className="rounded-lg bg-muted p-2">
                        <Truck className="h-4 w-4 text-primary" />
                      </div>
                      <div className="flex-1 min-w-0">
                        <div className="flex items-center gap-2">
                          <p className="text-sm font-semibold">{p.codigo}</p>
                          <Badge className={cn("text-[10px]", STATUS_BADGE[p.status])}>
                            {STATUS_LABEL[p.status]}
                          </Badge>
                        </div>
                        <p className="text-xs text-muted-foreground">
                          {p.cliente?.nome ?? "Sem cliente"}
                        </p>
                      </div>
                      <Link to="/pedidos">
                        <Button size="sm" variant="ghost" className="h-7 text-xs">
                          Ver
                        </Button>
                      </Link>
                    </div>
                  ))}
                </div>
              ) : (
                <p className="text-xs text-muted-foreground">Nenhuma entrega prevista.</p>
              )}
            </section>

            {/* Eventos */}
            <section>
              <div className="mb-2 flex items-center justify-between">
                <h3 className="text-xs font-semibold uppercase tracking-wider text-muted-foreground">
                  Eventos
                </h3>
                <Button
                  size="sm"
                  variant="ghost"
                  className="h-7 text-xs"
                  onClick={() => selectedDay && openNovoEvento(selectedDay)}
                >
                  <Plus className="mr-1 h-3 w-3" />
                  Novo
                </Button>
              </div>
              {selectedSlot && selectedSlot.eventos.length > 0 ? (
                <div className="space-y-2">
                  {selectedSlot.eventos.map((e) => (
                    <EventoCard
                      key={e.id}
                      evento={e}
                      onDeleted={() => qc.invalidateQueries({ queryKey: ["eventos"] })}
                    />
                  ))}
                </div>
              ) : (
                <p className="text-xs text-muted-foreground">Nenhum evento agendado.</p>
              )}
            </section>
          </div>
        </SheetContent>
      </Sheet>

      <NovoEventoDialog
        open={novoEventoOpen}
        onOpenChange={setNovoEventoOpen}
        defaultDate={novoEventoDate}
      />
    </PageShell>
  );
}

function MesGrid({
  days,
  cursor,
  today,
  byDay,
  onSelect,
}: {
  days: Date[];
  cursor: Date;
  today: Date;
  byDay: Map<string, { eventos: Evento[]; entregas: PedidoEntrega[] }>;
  onSelect: (d: Date) => void;
}) {
  return (
    <div className="rounded-xl border border-border bg-card overflow-hidden">
      <div className="grid grid-cols-7 border-b border-border bg-muted/40">
        {WEEKDAYS.map((w) => (
          <div
            key={w}
            className="px-1 py-2 text-center text-[10px] font-semibold uppercase tracking-wider text-muted-foreground"
          >
            {w}
          </div>
        ))}
      </div>
      <div className="grid grid-cols-7">
        {days.map((d) => {
          const slot = byDay.get(isoDay(d))!;
          const total = slot.eventos.length + slot.entregas.length;
          const inMonth = d.getMonth() === cursor.getMonth();
          const isToday = isSameDay(d, today);
          return (
            <button
              key={isoDay(d)}
              onClick={() => onSelect(d)}
              className={cn(
                "relative flex min-h-[64px] flex-col items-stretch gap-1 border-b border-r border-border p-1 text-left transition hover:bg-muted/40 sm:min-h-[96px]",
                !inMonth && "bg-muted/10 text-muted-foreground/60",
              )}
              aria-label={d.toLocaleDateString("pt-BR")}
            >
              <span
                className={cn(
                  "flex h-6 w-6 items-center justify-center rounded-full text-xs font-semibold",
                  isToday && "bg-primary text-primary-foreground",
                )}
              >
                {d.getDate()}
              </span>
              {/* Mobile: dots; sm+: chips */}
              <div className="flex flex-wrap gap-0.5 sm:hidden">
                {slot.entregas.slice(0, 3).map((p) => (
                  <span
                    key={p.id}
                    className={cn("h-1.5 w-1.5 rounded-full", STATUS_DOT[p.status])}
                  />
                ))}
                {slot.eventos.length > 0 && (
                  <span className="h-1.5 w-1.5 rounded-full bg-info" />
                )}
                {total > 4 && (
                  <span className="text-[9px] text-muted-foreground">+{total - 4}</span>
                )}
              </div>
              <div className="hidden flex-col gap-0.5 sm:flex">
                {slot.entregas.slice(0, 2).map((p) => (
                  <span
                    key={p.id}
                    className={cn(
                      "truncate rounded px-1 py-0.5 text-[10px] font-medium",
                      STATUS_BADGE[p.status],
                    )}
                  >
                    {p.codigo}
                  </span>
                ))}
                {slot.eventos.slice(0, 2).map((e) => (
                  <span
                    key={e.id}
                    className="truncate rounded bg-info/15 px-1 py-0.5 text-[10px] font-medium text-info"
                  >
                    {e.titulo}
                  </span>
                ))}
                {total > 4 && (
                  <span className="px-1 text-[10px] text-muted-foreground">
                    +{total - 4} mais
                  </span>
                )}
              </div>
            </button>
          );
        })}
      </div>
    </div>
  );
}

function SemanaList({
  days,
  today,
  byDay,
  onSelect,
}: {
  days: Date[];
  today: Date;
  byDay: Map<string, { eventos: Evento[]; entregas: PedidoEntrega[] }>;
  onSelect: (d: Date) => void;
}) {
  return (
    <div className="space-y-3">
      {days.map((d) => {
        const slot = byDay.get(isoDay(d))!;
        const isToday = isSameDay(d, today);
        return (
          <div
            key={isoDay(d)}
            className={cn(
              "rounded-xl border border-border bg-card p-3",
              isToday && "ring-1 ring-primary",
            )}
          >
            <button
              onClick={() => onSelect(d)}
              className="mb-2 flex w-full items-center justify-between text-left"
            >
              <div>
                <p className="text-xs uppercase tracking-wider text-muted-foreground">
                  {d.toLocaleDateString("pt-BR", { weekday: "short" })}
                </p>
                <p className="text-lg font-bold capitalize">
                  {d.toLocaleDateString("pt-BR", { day: "2-digit", month: "short" })}
                </p>
              </div>
              <Badge variant="outline" className="text-[10px]">
                {slot.eventos.length + slot.entregas.length} item(ns)
              </Badge>
            </button>
            <div className="space-y-1.5">
              {slot.entregas.map((p) => (
                <div
                  key={p.id}
                  className="flex items-center gap-2 rounded-lg bg-muted/40 px-2 py-1.5"
                >
                  <Truck className="h-3.5 w-3.5 text-primary" />
                  <span className="text-xs font-semibold">{p.codigo}</span>
                  <span className="truncate text-xs text-muted-foreground">
                    {p.cliente?.nome ?? ""}
                  </span>
                  <Badge className={cn("ml-auto text-[10px]", STATUS_BADGE[p.status])}>
                    {STATUS_LABEL[p.status]}
                  </Badge>
                </div>
              ))}
              {slot.eventos.map((e) => (
                <div
                  key={e.id}
                  className="flex items-center gap-2 rounded-lg bg-info/10 px-2 py-1.5"
                >
                  <CalendarClock className="h-3.5 w-3.5 text-info" />
                  <span className="text-xs font-semibold">{e.titulo}</span>
                  {e.inicio && (
                    <span className="ml-auto text-[10px] text-muted-foreground">
                      {fmtTime(e.inicio)}
                    </span>
                  )}
                </div>
              ))}
              {slot.eventos.length + slot.entregas.length === 0 && (
                <p className="text-xs text-muted-foreground">Sem itens.</p>
              )}
            </div>
          </div>
        );
      })}
    </div>
  );
}

function EventoCard({ evento, onDeleted }: { evento: Evento; onDeleted: () => void }) {
  const del = useMutation({
    mutationFn: async () => {
      const { error } = await db.from("calendario_eventos").delete().eq("id", evento.id);
      if (error) throw error;
    },
    onSuccess: () => {
      toast.success("Evento removido");
      onDeleted();
    },
    onError: (e: Error) => toast.error(e.message),
  });
  return (
    <div className="flex items-start gap-3 rounded-xl border border-border bg-card p-3">
      <div className="rounded-lg bg-muted p-2">
        <CalendarClock className="h-4 w-4 text-info" />
      </div>
      <div className="flex-1 min-w-0">
        <p className="text-sm font-semibold">{evento.titulo}</p>
        <p className="text-xs text-muted-foreground">
          {fmtTime(evento.inicio)}
          {evento.fim ? ` → ${fmtTime(evento.fim)}` : ""}
        </p>
        {evento.descricao && (
          <p className="mt-1 text-xs text-muted-foreground">{evento.descricao}</p>
        )}
        {evento.tipo && (
          <span className="mt-1 inline-block rounded-full bg-muted px-2 py-0.5 text-[10px] uppercase tracking-wider">
            {evento.tipo}
          </span>
        )}
      </div>
      <button
        onClick={() => del.mutate()}
        className="text-destructive hover:opacity-70"
        aria-label="Remover evento"
      >
        <Trash2 className="h-4 w-4" />
      </button>
    </div>
  );
}

function NovoEventoDialog({
  open,
  onOpenChange,
  defaultDate,
}: {
  open: boolean;
  onOpenChange: (o: boolean) => void;
  defaultDate: Date | null;
}) {
  const qc = useQueryClient();
  const baseDate = defaultDate ?? new Date();
  const defaultInicio = `${baseDate.getFullYear()}-${String(baseDate.getMonth() + 1).padStart(2, "0")}-${String(baseDate.getDate()).padStart(2, "0")}T09:00`;
  const [form, setForm] = useState({
    titulo: "",
    descricao: "",
    inicio: defaultInicio,
    fim: "",
    tipo: "",
  });

  // reset when opened with new defaultDate
  const dateKey = defaultDate ? isoDay(defaultDate) : "now";
  useMemo(() => {
    setForm((f) => ({ ...f, inicio: defaultInicio }));
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [dateKey, open]);

  const save = useMutation({
    mutationFn: async () => {
      if (!form.titulo.trim() || !form.inicio)
        throw new Error("Título e início são obrigatórios");
      const { error } = await db.from("calendario_eventos").insert({
        titulo: form.titulo.trim(),
        descricao: form.descricao || null,
        inicio: new Date(form.inicio).toISOString(),
        fim: form.fim ? new Date(form.fim).toISOString() : null,
        tipo: form.tipo || null,
      });
      if (error) throw error;
    },
    onSuccess: () => {
      toast.success("Evento criado");
      qc.invalidateQueries({ queryKey: ["eventos"] });
      onOpenChange(false);
      setForm({ titulo: "", descricao: "", inicio: defaultInicio, fim: "", tipo: "" });
    },
    onError: (e: Error) => toast.error(e.message),
  });

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogTrigger asChild>
        <span className="hidden" />
      </DialogTrigger>
      <DialogContent>
        <DialogHeader>
          <DialogTitle>Novo evento</DialogTitle>
        </DialogHeader>
        <div className="space-y-3">
          <div>
            <Label>Título *</Label>
            <Input
              value={form.titulo}
              onChange={(e) => setForm({ ...form, titulo: e.target.value })}
            />
          </div>
          <div className="grid grid-cols-2 gap-3">
            <div>
              <Label>Início *</Label>
              <Input
                type="datetime-local"
                value={form.inicio}
                onChange={(e) => setForm({ ...form, inicio: e.target.value })}
              />
            </div>
            <div>
              <Label>Fim</Label>
              <Input
                type="datetime-local"
                value={form.fim}
                onChange={(e) => setForm({ ...form, fim: e.target.value })}
              />
            </div>
          </div>
          <div>
            <Label>Tipo</Label>
            <Input
              placeholder="Entrega, Manutenção, Reunião…"
              value={form.tipo}
              onChange={(e) => setForm({ ...form, tipo: e.target.value })}
            />
          </div>
          <div>
            <Label>Descrição</Label>
            <Textarea
              rows={3}
              value={form.descricao}
              onChange={(e) => setForm({ ...form, descricao: e.target.value })}
            />
          </div>
        </div>
        <DialogFooter>
          <Button variant="ghost" onClick={() => onOpenChange(false)}>
            Cancelar
          </Button>
          <Button onClick={() => save.mutate()} disabled={save.isPending}>
            Salvar
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
