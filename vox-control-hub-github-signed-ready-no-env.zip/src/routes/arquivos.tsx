import { createFileRoute } from "@tanstack/react-router";
import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { toast } from "sonner";
import { Plus, Trash2, ExternalLink, FileText, CheckCircle2, Link2 } from "lucide-react";
import { Progress } from "@/components/ui/progress";
import { PageShell } from "@/components/page-shell";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Select, SelectContent, SelectItem, SelectTrigger, SelectValue,
} from "@/components/ui/select";
import {
  Dialog, DialogContent, DialogFooter, DialogHeader, DialogTitle, DialogTrigger,
} from "@/components/ui/dialog";
import { db } from "@/lib/db";
import { formatDateBR } from "@/lib/format";
import type { Database } from "@/integrations/supabase/types";

export const Route = createFileRoute("/arquivos")({
  head: () => ({ meta: [{ title: "Arquivos — VOX Control" }] }),
  component: Page,
});

type Anexo = Database["public"]["Tables"]["anexos"]["Row"];

function Page() {
  const qc = useQueryClient();

  const { data = [], isLoading } = useQuery({
    queryKey: ["anexos"],
    queryFn: async () => {
      const { data, error } = await db
        .from("anexos")
        .select("*, pedido:pedidos(codigo), cliente:clientes(nome)")
        .order("created_at", { ascending: false });
      if (error) throw error;
      return data as (Anexo & { pedido?: { codigo: string } | null; cliente?: { nome: string } | null })[];
    },
  });

  const del = useMutation({
    mutationFn: async (id: string) => { const { error } = await db.from("anexos").delete().eq("id", id); if (error) throw error; },
    onSuccess: () => { toast.success("Removido"); qc.invalidateQueries({ queryKey: ["anexos"] }); },
  });

  return (
    <PageShell title="Arquivos / Artes" description="Mockups, contratos e arquivos vinculados." actions={<NovoAnexoDialog />}>
      {isLoading ? <p className="text-sm text-muted-foreground">Carregando…</p> : data.length === 0 ? (
        <div className="rounded-xl border border-dashed border-border bg-card/40 p-10 text-center text-sm text-muted-foreground">
          Nenhum arquivo cadastrado.
        </div>
      ) : (
        <div className="overflow-hidden rounded-xl border border-border">
          <table className="w-full text-sm">
            <thead className="bg-muted/40 text-xs uppercase text-muted-foreground">
              <tr>
                <th className="px-3 py-2 text-left">Nome</th>
                <th className="px-3 py-2 text-left">Tipo</th>
                <th className="px-3 py-2 text-left">Pedido</th>
                <th className="px-3 py-2 text-left">Cliente</th>
                <th className="px-3 py-2 text-left">Data</th>
                <th className="px-3 py-2"></th>
              </tr>
            </thead>
            <tbody>
              {data.map((a) => (
                <tr key={a.id} className="border-t border-border">
                  <td className="px-3 py-2"><div className="flex items-center gap-2"><FileText className="h-4 w-4 text-muted-foreground" />{a.nome}</div></td>
                  <td className="px-3 py-2 text-muted-foreground">{a.tipo ?? "—"}</td>
                  <td className="px-3 py-2">{a.pedido?.codigo ?? "—"}</td>
                  <td className="px-3 py-2">{a.cliente?.nome ?? "—"}</td>
                  <td className="px-3 py-2 text-muted-foreground">{formatDateBR(a.created_at)}</td>
                  <td className="px-3 py-2 text-right">
                    <a href={a.url} target="_blank" rel="noreferrer" className="mr-2 inline-flex items-center text-info hover:underline"><ExternalLink className="h-4 w-4" /></a>
                    <button onClick={() => del.mutate(a.id)} className="text-destructive"><Trash2 className="inline h-4 w-4" /></button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </PageShell>
  );
}

function NovoAnexoDialog() {
  const [open, setOpen] = useState(false);
  const qc = useQueryClient();
  const [form, setForm] = useState({ nome: "", url: "", tipo: "", pedido_id: "", cliente_id: "" });
  const [file, setFile] = useState<File | null>(null);
  const [uploading, setUploading] = useState(false);
  const [progress, setProgress] = useState(0);
  const [doneInfo, setDoneInfo] = useState<{ pedido?: string; cliente?: string } | null>(null);


  const { data: pedidos = [] } = useQuery({
    queryKey: ["anexos-pedidos"],
    queryFn: async () => {
      const { data, error } = await db.from("pedidos").select("id, codigo").order("created_at", { ascending: false }).limit(300);
      if (error) throw error;
      return data;
    },
    enabled: open,
  });
  const { data: clientes = [] } = useQuery({
    queryKey: ["anexos-clientes"],
    queryFn: async () => {
      const { data, error } = await db.from("clientes").select("id, nome").order("nome");
      if (error) throw error;
      return data;
    },
    enabled: open,
  });

  const pedidoLabel = (id: string) => pedidos.find((p) => p.id === id)?.codigo;
  const clienteLabel = (id: string) => clientes.find((c) => c.id === id)?.nome;

  const save = useMutation({
    mutationFn: async () => {
      let finalUrl = form.url.trim();
      let finalNome = form.nome.trim();
      let finalTipo = form.tipo || null;
      let tamanho: number | null = null;

      if (file) {
        setUploading(true);
        setProgress(5);
        // Supabase JS não emite progresso real — simulamos avanço suave até concluir.
        const ticker = setInterval(() => {
          setProgress((p) => (p < 90 ? p + Math.max(1, Math.round((90 - p) / 8)) : p));
        }, 200);
        const ext = file.name.split(".").pop() ?? "bin";
        const path = `${form.cliente_id || form.pedido_id || "geral"}/${Date.now()}-${Math.random().toString(36).slice(2, 8)}.${ext}`;
        const { error: upErr } = await db.storage.from("anexos").upload(path, file, {
          contentType: file.type || undefined,
          upsert: false,
        });
        clearInterval(ticker);
        if (upErr) { setUploading(false); setProgress(0); throw upErr; }
        setProgress(100);
        const { data: pub } = db.storage.from("anexos").getPublicUrl(path);
        finalUrl = pub.publicUrl;
        if (!finalNome) finalNome = file.name;
        if (!finalTipo) finalTipo = file.type || ext.toUpperCase();
        tamanho = file.size;
      }

      if (!finalNome || !finalUrl) throw new Error("Envie um arquivo ou informe nome e URL");

      const { error } = await db.from("anexos").insert({
        nome: finalNome,
        url: finalUrl,
        tipo: finalTipo,
        tamanho_bytes: tamanho,
        pedido_id: form.pedido_id || null,
        cliente_id: form.cliente_id || null,
      });
      if (error) throw error;

      return {
        url: finalUrl,
        pedido: form.pedido_id ? pedidoLabel(form.pedido_id) : undefined,
        cliente: form.cliente_id ? clienteLabel(form.cliente_id) : undefined,
      };
    },
    onSuccess: (info) => {
      setUploading(false);
      toast.success(
        `Arquivo enviado${info.pedido ? ` • Pedido ${info.pedido}` : ""}${info.cliente ? ` • Cliente ${info.cliente}` : ""}`
      );
      qc.invalidateQueries({ queryKey: ["anexos"] });
      setDoneInfo({ pedido: info.pedido, cliente: info.cliente });
    },
    onError: (e: Error) => { setUploading(false); setProgress(0); toast.error(e.message); },
  });

  function reset() {
    setForm({ nome: "", url: "", tipo: "", pedido_id: "", cliente_id: "" });
    setFile(null);
    setProgress(0);
    setDoneInfo(null);
  }
  function handleOpenChange(o: boolean) {
    setOpen(o);
    if (!o) reset();
  }


  return (
    <Dialog open={open} onOpenChange={handleOpenChange}>
      <DialogTrigger asChild><Button><Plus className="mr-2 h-4 w-4" />Novo arquivo</Button></DialogTrigger>
      <DialogContent>
        <DialogHeader><DialogTitle>Novo arquivo</DialogTitle></DialogHeader>

        {doneInfo ? (
          <div className="space-y-4 py-2">
            <div className="flex items-center gap-2 text-success">
              <CheckCircle2 className="h-5 w-5" />
              <span className="font-medium">Arquivo enviado com sucesso</span>
            </div>
            <div className="rounded-lg border border-border bg-muted/30 p-3 text-sm space-y-1">
              <div className="flex items-center gap-2">
                <Link2 className="h-4 w-4 text-muted-foreground" />
                <span className="font-medium">Vínculos confirmados:</span>
              </div>
              <p>Pedido: <span className="font-medium">{doneInfo.pedido ?? "— nenhum —"}</span></p>
              <p>Cliente: <span className="font-medium">{doneInfo.cliente ?? "— nenhum —"}</span></p>
            </div>
            <DialogFooter>
              <Button variant="ghost" onClick={() => { reset(); }}>Enviar outro</Button>
              <Button onClick={() => handleOpenChange(false)}>Fechar</Button>
            </DialogFooter>
          </div>
        ) : (
          <>
            <div className="space-y-3">
              <div>
                <Label>Arquivo (upload)</Label>
                <Input type="file" disabled={uploading} onChange={(e) => setFile(e.target.files?.[0] ?? null)} />
                {file && <p className="mt-1 text-xs text-muted-foreground">{file.name} — {(file.size/1024).toFixed(1)} KB</p>}
              </div>

              {(uploading || progress > 0) && (
                <div className="space-y-1">
                  <Progress value={progress} />
                  <p className="text-xs text-muted-foreground">
                    {progress >= 100 ? "Finalizando…" : `Enviando arquivo… ${progress}%`}
                  </p>
                </div>
              )}

              <div className="text-center text-xs text-muted-foreground">— ou informe um link externo —</div>
              <div><Label>Nome</Label><Input value={form.nome} onChange={(e) => setForm({ ...form, nome: e.target.value })} /></div>
              <div><Label>URL externa</Label><Input placeholder="https://…" value={form.url} onChange={(e) => setForm({ ...form, url: e.target.value })} /></div>
              <div><Label>Tipo</Label><Input placeholder="PDF, PNG, contrato…" value={form.tipo} onChange={(e) => setForm({ ...form, tipo: e.target.value })} /></div>
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <Label>Pedido</Label>
                  <Select value={form.pedido_id} onValueChange={(v) => setForm({ ...form, pedido_id: v })}>
                    <SelectTrigger><SelectValue placeholder="—" /></SelectTrigger>
                    <SelectContent>{pedidos.map((p) => <SelectItem key={p.id} value={p.id}>{p.codigo}</SelectItem>)}</SelectContent>
                  </Select>
                </div>
                <div>
                  <Label>Cliente</Label>
                  <Select value={form.cliente_id} onValueChange={(v) => setForm({ ...form, cliente_id: v })}>
                    <SelectTrigger><SelectValue placeholder="—" /></SelectTrigger>
                    <SelectContent>{clientes.map((c) => <SelectItem key={c.id} value={c.id}>{c.nome}</SelectItem>)}</SelectContent>
                  </Select>
                </div>
              </div>
              {(form.pedido_id || form.cliente_id) && (
                <p className="text-xs text-muted-foreground">
                  Será vinculado a{form.pedido_id ? ` Pedido ${pedidoLabel(form.pedido_id)}` : ""}
                  {form.pedido_id && form.cliente_id ? " e" : ""}
                  {form.cliente_id ? ` Cliente ${clienteLabel(form.cliente_id)}` : ""}.
                </p>
              )}
            </div>
            <DialogFooter>
              <Button variant="ghost" onClick={() => handleOpenChange(false)} disabled={uploading}>Cancelar</Button>
              <Button onClick={() => save.mutate()} disabled={save.isPending || uploading}>
                {uploading ? "Enviando…" : "Salvar"}
              </Button>
            </DialogFooter>
          </>
        )}
      </DialogContent>
    </Dialog>
  );
}
