import { createFileRoute } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import { useState } from "react";
import { Download } from "lucide-react";
import { toast } from "sonner";
import { PageShell } from "@/components/page-shell";
import { Button } from "@/components/ui/button";
import { db } from "@/lib/db";
import { exportarTudoPDF } from "@/lib/export-all-pdf";

export const Route = createFileRoute("/relatorios")({
  head: () => ({ meta: [{ title: "Relatórios — VOX Control" }] }),
  component: Page,
});

const brl = (n: number) => n.toLocaleString("pt-BR", { style: "currency", currency: "BRL" });

function Page() {
  const { data, isLoading } = useQuery({
    queryKey: ["relatorios"],
    queryFn: async () => {
      const monthStart = new Date(); monthStart.setDate(1); monthStart.setHours(0, 0, 0, 0);
      const monthIso = monthStart.toISOString().slice(0, 10);

      const [pedidosRes, recRes, pagRes, clientesRes] = await Promise.all([
        db.from("pedidos").select("id, status, valor_total, prioridade, created_at, cliente_id"),
        db.from("financeiro_receber").select("valor, status, pago_em, vencimento, cliente_id"),
        db.from("financeiro_pagar").select("valor, status, pago_em, vencimento, categoria"),
        db.from("clientes").select("id, nome"),
      ]);

      const pedidos = pedidosRes.data ?? [];
      const recs = recRes.data ?? [];
      const pags = pagRes.data ?? [];
      const clientes = clientesRes.data ?? [];

      const totalPedidosMes = pedidos.filter((p) => p.created_at >= monthIso).reduce((s, p) => s + Number(p.valor_total ?? 0), 0);
      const recebidoMes = recs.filter((r) => r.status === "PAGO" && (r.pago_em ?? "") >= monthIso).reduce((s, r) => s + Number(r.valor), 0);
      const aReceber = recs.filter((r) => r.status !== "PAGO").reduce((s, r) => s + Number(r.valor), 0);
      const pagoMes = pags.filter((p) => p.status === "PAGO" && (p.pago_em ?? "") >= monthIso).reduce((s, p) => s + Number(p.valor), 0);
      const aPagar = pags.filter((p) => p.status !== "PAGO").reduce((s, p) => s + Number(p.valor), 0);
      const lucroMes = recebidoMes - pagoMes;

      const porStatus = pedidos.reduce<Record<string, number>>((acc, p) => { acc[p.status] = (acc[p.status] ?? 0) + 1; return acc; }, {});
      const porCliente: Record<string, { nome: string; total: number; count: number }> = {};
      for (const p of pedidos) {
        if (!p.cliente_id) continue;
        const cli = clientes.find((c) => c.id === p.cliente_id);
        const k = p.cliente_id;
        porCliente[k] ||= { nome: cli?.nome ?? "—", total: 0, count: 0 };
        porCliente[k].total += Number(p.valor_total ?? 0);
        porCliente[k].count += 1;
      }
      const topClientes = Object.values(porCliente).sort((a, b) => b.total - a.total).slice(0, 8);

      const porCategoria = pags.reduce<Record<string, number>>((acc, p) => {
        const k = p.categoria ?? "Sem categoria"; acc[k] = (acc[k] ?? 0) + Number(p.valor); return acc;
      }, {});

      return { totalPedidosMes, recebidoMes, aReceber, pagoMes, aPagar, lucroMes, porStatus, topClientes, porCategoria, totalPedidos: pedidos.length };
    },
  });

  if (isLoading || !data) return <PageShell title="Relatórios"><p className="text-sm text-muted-foreground">Carregando…</p></PageShell>;

  const cards = [
    { label: "Vendido no mês", value: brl(data.totalPedidosMes) },
    { label: "Recebido no mês", value: brl(data.recebidoMes), tone: "text-success" },
    { label: "A receber", value: brl(data.aReceber), tone: "text-warning" },
    { label: "Pago no mês", value: brl(data.pagoMes) },
    { label: "A pagar", value: brl(data.aPagar), tone: "text-destructive" },
    { label: "Lucro estimado", value: brl(data.lucroMes), tone: data.lucroMes >= 0 ? "text-success" : "text-destructive" },
  ];

  return (
    <PageShell
      title="Relatórios"
      description="Visão consolidada de vendas, financeiro e clientes."
      actions={<ExportButton />}
    >
      <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-3">
        {cards.map((c) => (
          <div key={c.label} className="rounded-xl border border-border bg-card p-5">
            <p className="text-xs uppercase tracking-wider text-muted-foreground">{c.label}</p>
            <p className={`mt-2 text-2xl font-bold ${c.tone ?? ""}`}>{c.value}</p>
          </div>
        ))}
      </div>

      <div className="grid gap-5 lg:grid-cols-2">
        <div className="rounded-xl border border-border bg-card p-5">
          <h3 className="mb-3 text-sm font-semibold">Pedidos por status</h3>
          <ul className="space-y-2 text-sm">
            {Object.entries(data.porStatus).map(([k, v]) => {
              const pct = data.totalPedidos ? Math.round((v / data.totalPedidos) * 100) : 0;
              return (
                <li key={k}>
                  <div className="flex justify-between text-xs"><span>{k}</span><span className="text-muted-foreground">{v} ({pct}%)</span></div>
                  <div className="mt-1 h-2 rounded-full bg-muted"><div className="h-2 rounded-full bg-primary" style={{ width: `${pct}%` }} /></div>
                </li>
              );
            })}
          </ul>
        </div>

        <div className="rounded-xl border border-border bg-card p-5">
          <h3 className="mb-3 text-sm font-semibold">Top clientes (faturamento)</h3>
          <ul className="space-y-2 text-sm">
            {data.topClientes.length === 0 ? <li className="text-xs text-muted-foreground">Sem dados.</li> : data.topClientes.map((c) => (
              <li key={c.nome} className="flex justify-between border-b border-border/50 pb-1">
                <span>{c.nome} <span className="text-xs text-muted-foreground">({c.count})</span></span>
                <span className="font-semibold">{brl(c.total)}</span>
              </li>
            ))}
          </ul>
        </div>

        <div className="rounded-xl border border-border bg-card p-5 lg:col-span-2">
          <h3 className="mb-3 text-sm font-semibold">Despesas por categoria</h3>
          {Object.keys(data.porCategoria).length === 0 ? <p className="text-xs text-muted-foreground">Nenhuma despesa lançada.</p> : (
            <ul className="space-y-1 text-sm">
              {Object.entries(data.porCategoria).sort((a, b) => b[1] - a[1]).map(([k, v]) => (
                <li key={k} className="flex justify-between"><span>{k}</span><span className="font-semibold">{brl(v)}</span></li>
              ))}
            </ul>
          )}
        </div>
      </div>
    </PageShell>
  );
}

function ExportButton() {
  const [loading, setLoading] = useState(false);
  return (
    <Button
      size="sm"
      disabled={loading}
      onClick={async () => {
        try {
          setLoading(true);
          await exportarTudoPDF();
          toast.success("PDF gerado com sucesso");
        } catch (e) {
          console.error(e);
          toast.error("Falha ao gerar PDF");
        } finally {
          setLoading(false);
        }
      }}
    >
      <Download className="mr-2 size-4" />
      {loading ? "Gerando…" : "Exportar tudo (PDF)"}
    </Button>
  );
}
