import { createFileRoute } from "@tanstack/react-router";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { toast } from "sonner";
import { PageShell } from "@/components/page-shell";
import { OrderStatusBadge, PriorityBadge } from "@/components/status-badge";
import { Button } from "@/components/ui/button";
import {
  Select, SelectContent, SelectItem, SelectTrigger, SelectValue,
} from "@/components/ui/select";
import { db, type Pedido } from "@/lib/db";
import { formatDateBR } from "@/lib/format";
import type { Database } from "@/integrations/supabase/types";

export const Route = createFileRoute("/producao")({
  head: () => ({ meta: [{ title: "Produção — VOX Control" }] }),
  component: Page,
});

type StatusPedido = Database["public"]["Enums"]["status_pedido"];
type PedidoComCliente = Pedido & { cliente?: { nome: string } | null };

const NEXT_STATUS: Record<string, StatusPedido | undefined> = {
  ORCAMENTO: "AGUARDANDO_ARTE",
  AGUARDANDO_ARTE: "ARTE_APROVADA",
  ARTE_APROVADA: "EM_PRODUCAO",
  EM_PRODUCAO: "PRONTO",
  PRONTO: "ENTREGUE",
};

const STATUS_OPTIONS: StatusPedido[] = [
  "ORCAMENTO", "AGUARDANDO_ARTE", "ARTE_APROVADA", "EM_PRODUCAO", "PRONTO", "ENTREGUE", "CANCELADO",
];

const ACTIVE: StatusPedido[] = ["ARTE_APROVADA", "EM_PRODUCAO", "PRONTO"];

function Page() {
  const qc = useQueryClient();
  const { data: pedidos = [], isLoading } = useQuery({
    queryKey: ["producao"],
    queryFn: async () => {
      const { data, error } = await db
        .from("pedidos")
        .select("*, cliente:clientes(nome)")
        .in("status", ACTIVE)
        .order("data_entrega", { ascending: true });
      if (error) throw error;
      return data as PedidoComCliente[];
    },
  });

  const updateStatus = useMutation({
    mutationFn: async ({ id, status }: { id: string; status: StatusPedido }) => {
      const { error } = await db.from("pedidos").update({ status }).eq("id", id);
      if (error) throw error;
    },
    onSuccess: () => {
      toast.success("Status atualizado");
      qc.invalidateQueries({ queryKey: ["producao"] });
      qc.invalidateQueries({ queryKey: ["pedidos"] });
      qc.invalidateQueries({ queryKey: ["dashboard"] });
    },
    onError: (e: Error) => toast.error(e.message),
  });

  const cols: { key: StatusPedido; label: string }[] = [
    { key: "ARTE_APROVADA", label: "Arte aprovada" },
    { key: "EM_PRODUCAO", label: "Em produção" },
    { key: "PRONTO", label: "Pronto p/ entrega" },
  ];

  return (
    <PageShell title="Produção" description="Acompanhamento de ordens em chão de fábrica.">
      {isLoading ? (
        <p className="text-sm text-muted-foreground">Carregando…</p>
      ) : (
        <div className="grid gap-4 md:grid-cols-3">
          {cols.map((c) => {
            const items = pedidos.filter((p) => p.status === c.key);
            return (
              <div key={c.key} className="rounded-xl border border-border bg-card p-4">
                <div className="mb-3 flex items-center justify-between">
                  <h3 className="text-sm font-semibold">{c.label}</h3>
                  <span className="rounded-full bg-muted px-2 py-0.5 text-xs">{items.length}</span>
                </div>
                <div className="space-y-2">
                  {items.length === 0 && <p className="text-xs text-muted-foreground">Sem itens.</p>}
                  {items.map((p) => {
                    const next = NEXT_STATUS[p.status];
                    return (
                      <div key={p.id} className="rounded-lg border border-border bg-background p-3">
                        <div className="flex items-center justify-between">
                          <p className="text-sm font-semibold">{p.codigo}</p>
                          <PriorityBadge priority={p.prioridade} />
                        </div>
                        <p className="mt-1 text-xs text-muted-foreground">{p.cliente?.nome ?? "—"}</p>
                        <p className="mt-1 text-xs text-muted-foreground">Entrega {formatDateBR(p.data_entrega)}</p>
                        <div className="mt-2"><OrderStatusBadge status={p.status as never} /></div>
                        <div className="mt-3 flex gap-2">
                          <Select value={p.status} onValueChange={(v) => updateStatus.mutate({ id: p.id, status: v as StatusPedido })}>
                            <SelectTrigger className="h-8 text-xs"><SelectValue /></SelectTrigger>
                            <SelectContent>
                              {STATUS_OPTIONS.map((s) => <SelectItem key={s} value={s}>{s}</SelectItem>)}
                            </SelectContent>
                          </Select>
                          {next && (
                            <Button size="sm" className="shrink-0" onClick={() => updateStatus.mutate({ id: p.id, status: next })}>
                              Avançar
                            </Button>
                          )}
                        </div>
                      </div>
                    );
                  })}
                </div>
              </div>
            );
          })}
        </div>
      )}
    </PageShell>
  );
}
