import { createFileRoute } from "@tanstack/react-router";
import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { toast } from "sonner";
import { Plus, Trash2, Check } from "lucide-react";
import { PageShell } from "@/components/page-shell";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import {
  Dialog, DialogContent, DialogFooter, DialogHeader, DialogTitle, DialogTrigger,
} from "@/components/ui/dialog";
import { PaymentBadge } from "@/components/status-badge";
import { db, type FinReceber, type FinPagar } from "@/lib/db";
import { formatDateBR } from "@/lib/format";

export const Route = createFileRoute("/financeiro")({
  head: () => ({ meta: [{ title: "Financeiro — VOX Control" }] }),
  component: Page,
});

const brl = (n: number) => Number(n).toLocaleString("pt-BR", { style: "currency", currency: "BRL" });

function Page() {
  return (
    <PageShell title="Financeiro" description="Contas a receber e a pagar.">
      <Tabs defaultValue="receber">
        <TabsList>
          <TabsTrigger value="receber">A receber</TabsTrigger>
          <TabsTrigger value="pagar">A pagar</TabsTrigger>
        </TabsList>
        <TabsContent value="receber" className="mt-4"><Receber /></TabsContent>
        <TabsContent value="pagar" className="mt-4"><Pagar /></TabsContent>
      </Tabs>
    </PageShell>
  );
}

function Receber() {
  const qc = useQueryClient();
  const { data = [], isLoading } = useQuery({
    queryKey: ["fin-receber"],
    queryFn: async () => {
      const { data, error } = await db.from("financeiro_receber").select("*").order("vencimento");
      if (error) throw error;
      return data as FinReceber[];
    },
  });

  const total = data.reduce((s, r) => s + Number(r.valor), 0);
  const pendente = data.filter((r) => r.status !== "PAGO").reduce((s, r) => s + Number(r.valor), 0);

  const marcarPago = useMutation({
    mutationFn: async (id: string) => {
      const { error } = await db.from("financeiro_receber")
        .update({ status: "PAGO", pago_em: new Date().toISOString().slice(0, 10) }).eq("id", id);
      if (error) throw error;
    },
    onSuccess: () => { toast.success("Marcado como pago"); qc.invalidateQueries({ queryKey: ["fin-receber"] }); qc.invalidateQueries({ queryKey: ["dashboard"] }); },
    onError: (e: Error) => toast.error(e.message),
  });

  const del = useMutation({
    mutationFn: async (id: string) => {
      const { error } = await db.from("financeiro_receber").delete().eq("id", id);
      if (error) throw error;
    },
    onSuccess: () => { toast.success("Removido"); qc.invalidateQueries({ queryKey: ["fin-receber"] }); },
  });

  return (
    <div className="space-y-4">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div className="flex gap-3 text-xs">
          <span className="rounded-lg bg-muted px-3 py-1.5">Total <strong className="ml-1 text-foreground">{brl(total)}</strong></span>
          <span className="rounded-lg bg-warning/10 px-3 py-1.5 text-warning">Em aberto <strong className="ml-1">{brl(pendente)}</strong></span>
        </div>
        <ReceberDialog />
      </div>
      {isLoading ? <p className="text-sm text-muted-foreground">Carregando…</p> : data.length === 0 ? (
        <Empty msg="Nenhuma conta a receber." />
      ) : (
        <div className="overflow-auto rounded-xl border border-border bg-card">
          <table className="w-full text-sm">
            <thead><tr className="border-b border-border text-left text-xs uppercase text-muted-foreground">
              <th className="px-4 py-3">Descrição</th>
              <th className="px-4 py-3">Vencimento</th>
              <th className="px-4 py-3">Status</th>
              <th className="px-4 py-3 text-right">Valor</th>
              <th className="px-4 py-3" />
            </tr></thead>
            <tbody>
              {data.map((r) => (
                <tr key={r.id} className="border-b border-border/60 hover:bg-muted/30">
                  <td className="px-4 py-3 font-medium">{r.descricao}</td>
                  <td className="px-4 py-3 text-muted-foreground">{formatDateBR(r.vencimento)}</td>
                  <td className="px-4 py-3"><PaymentBadge status={r.status} /></td>
                  <td className="px-4 py-3 text-right font-medium">{brl(Number(r.valor))}</td>
                  <td className="px-4 py-3 text-right">
                    <div className="flex justify-end gap-1">
                      {r.status !== "PAGO" && (
                        <Button size="icon" variant="ghost" onClick={() => marcarPago.mutate(r.id)} title="Marcar pago">
                          <Check className="h-4 w-4 text-success" />
                        </Button>
                      )}
                      <Button size="icon" variant="ghost" onClick={() => del.mutate(r.id)}>
                        <Trash2 className="h-4 w-4 text-destructive" />
                      </Button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
}

function ReceberDialog() {
  const [open, setOpen] = useState(false);
  const qc = useQueryClient();
  const [form, setForm] = useState({ descricao: "", valor: "", vencimento: "" });

  const save = useMutation({
    mutationFn: async () => {
      if (!form.descricao || !form.valor || !form.vencimento) throw new Error("Preencha descrição, valor e vencimento");
      const { error } = await db.from("financeiro_receber").insert({
        descricao: form.descricao, valor: Number(form.valor), vencimento: form.vencimento,
      });
      if (error) throw error;
    },
    onSuccess: () => {
      toast.success("Conta cadastrada");
      qc.invalidateQueries({ queryKey: ["fin-receber"] });
      qc.invalidateQueries({ queryKey: ["dashboard"] });
      setOpen(false);
      setForm({ descricao: "", valor: "", vencimento: "" });
    },
    onError: (e: Error) => toast.error(e.message),
  });

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild><Button><Plus className="mr-2 h-4 w-4" />Nova conta</Button></DialogTrigger>
      <DialogContent>
        <DialogHeader><DialogTitle>Nova conta a receber</DialogTitle></DialogHeader>
        <div className="space-y-3">
          <div><Label>Descrição *</Label><Input value={form.descricao} onChange={(e) => setForm({ ...form, descricao: e.target.value })} /></div>
          <div className="grid grid-cols-2 gap-3">
            <div><Label>Valor *</Label><Input type="number" step="0.01" value={form.valor} onChange={(e) => setForm({ ...form, valor: e.target.value })} /></div>
            <div><Label>Vencimento *</Label><Input type="date" value={form.vencimento} onChange={(e) => setForm({ ...form, vencimento: e.target.value })} /></div>
          </div>
        </div>
        <DialogFooter>
          <Button variant="ghost" onClick={() => setOpen(false)}>Cancelar</Button>
          <Button onClick={() => save.mutate()} disabled={save.isPending}>Salvar</Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}

function Pagar() {
  const qc = useQueryClient();
  const { data = [], isLoading } = useQuery({
    queryKey: ["fin-pagar"],
    queryFn: async () => {
      const { data, error } = await db.from("financeiro_pagar").select("*").order("vencimento");
      if (error) throw error;
      return data as FinPagar[];
    },
  });

  const marcarPago = useMutation({
    mutationFn: async (id: string) => {
      const { error } = await db.from("financeiro_pagar")
        .update({ status: "PAGO", pago_em: new Date().toISOString().slice(0, 10) }).eq("id", id);
      if (error) throw error;
    },
    onSuccess: () => { toast.success("Pago"); qc.invalidateQueries({ queryKey: ["fin-pagar"] }); },
  });
  const del = useMutation({
    mutationFn: async (id: string) => { const { error } = await db.from("financeiro_pagar").delete().eq("id", id); if (error) throw error; },
    onSuccess: () => { toast.success("Removido"); qc.invalidateQueries({ queryKey: ["fin-pagar"] }); },
  });

  const total = data.reduce((s, r) => s + Number(r.valor), 0);

  return (
    <div className="space-y-4">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <span className="rounded-lg bg-muted px-3 py-1.5 text-xs">Total <strong className="ml-1">{brl(total)}</strong></span>
        <PagarDialog />
      </div>
      {isLoading ? <p className="text-sm text-muted-foreground">Carregando…</p> : data.length === 0 ? (
        <Empty msg="Nenhuma conta a pagar." />
      ) : (
        <div className="overflow-auto rounded-xl border border-border bg-card">
          <table className="w-full text-sm">
            <thead><tr className="border-b border-border text-left text-xs uppercase text-muted-foreground">
              <th className="px-4 py-3">Descrição</th>
              <th className="px-4 py-3">Fornecedor</th>
              <th className="px-4 py-3">Vencimento</th>
              <th className="px-4 py-3">Status</th>
              <th className="px-4 py-3 text-right">Valor</th>
              <th className="px-4 py-3" />
            </tr></thead>
            <tbody>
              {data.map((r) => (
                <tr key={r.id} className="border-b border-border/60 hover:bg-muted/30">
                  <td className="px-4 py-3 font-medium">{r.descricao}</td>
                  <td className="px-4 py-3 text-muted-foreground">{r.fornecedor ?? "—"}</td>
                  <td className="px-4 py-3 text-muted-foreground">{formatDateBR(r.vencimento)}</td>
                  <td className="px-4 py-3"><PaymentBadge status={r.status} /></td>
                  <td className="px-4 py-3 text-right font-medium">{brl(Number(r.valor))}</td>
                  <td className="px-4 py-3 text-right">
                    <div className="flex justify-end gap-1">
                      {r.status !== "PAGO" && (
                        <Button size="icon" variant="ghost" onClick={() => marcarPago.mutate(r.id)}><Check className="h-4 w-4 text-success" /></Button>
                      )}
                      <Button size="icon" variant="ghost" onClick={() => del.mutate(r.id)}><Trash2 className="h-4 w-4 text-destructive" /></Button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
}

function PagarDialog() {
  const [open, setOpen] = useState(false);
  const qc = useQueryClient();
  const [form, setForm] = useState({ descricao: "", fornecedor: "", valor: "", vencimento: "" });

  const save = useMutation({
    mutationFn: async () => {
      if (!form.descricao || !form.valor || !form.vencimento) throw new Error("Preencha descrição, valor e vencimento");
      const { error } = await db.from("financeiro_pagar").insert({
        descricao: form.descricao, fornecedor: form.fornecedor || null,
        valor: Number(form.valor), vencimento: form.vencimento,
      });
      if (error) throw error;
    },
    onSuccess: () => {
      toast.success("Conta cadastrada");
      qc.invalidateQueries({ queryKey: ["fin-pagar"] });
      setOpen(false);
      setForm({ descricao: "", fornecedor: "", valor: "", vencimento: "" });
    },
    onError: (e: Error) => toast.error(e.message),
  });

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild><Button><Plus className="mr-2 h-4 w-4" />Nova conta</Button></DialogTrigger>
      <DialogContent>
        <DialogHeader><DialogTitle>Nova conta a pagar</DialogTitle></DialogHeader>
        <div className="space-y-3">
          <div><Label>Descrição *</Label><Input value={form.descricao} onChange={(e) => setForm({ ...form, descricao: e.target.value })} /></div>
          <div><Label>Fornecedor</Label><Input value={form.fornecedor} onChange={(e) => setForm({ ...form, fornecedor: e.target.value })} /></div>
          <div className="grid grid-cols-2 gap-3">
            <div><Label>Valor *</Label><Input type="number" step="0.01" value={form.valor} onChange={(e) => setForm({ ...form, valor: e.target.value })} /></div>
            <div><Label>Vencimento *</Label><Input type="date" value={form.vencimento} onChange={(e) => setForm({ ...form, vencimento: e.target.value })} /></div>
          </div>
        </div>
        <DialogFooter>
          <Button variant="ghost" onClick={() => setOpen(false)}>Cancelar</Button>
          <Button onClick={() => save.mutate()} disabled={save.isPending}>Salvar</Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}

function Empty({ msg }: { msg: string }) {
  return <div className="rounded-xl border border-dashed border-border bg-card/40 p-10 text-center text-sm text-muted-foreground">{msg}</div>;
}
