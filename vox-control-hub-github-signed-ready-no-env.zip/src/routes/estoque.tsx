import { createFileRoute } from "@tanstack/react-router";
import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { toast } from "sonner";
import { Plus, Trash2, AlertTriangle } from "lucide-react";
import { PageShell } from "@/components/page-shell";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Dialog, DialogContent, DialogFooter, DialogHeader, DialogTitle, DialogTrigger,
} from "@/components/ui/dialog";
import { db, type EstoqueItem } from "@/lib/db";

export const Route = createFileRoute("/estoque")({
  head: () => ({ meta: [{ title: "Estoque — VOX Control" }] }),
  component: Page,
});

function Page() {
  const qc = useQueryClient();
  const { data = [], isLoading } = useQuery({
    queryKey: ["estoque"],
    queryFn: async () => {
      const { data, error } = await db.from("estoque_itens").select("*").order("nome");
      if (error) throw error;
      return data as EstoqueItem[];
    },
  });

  const del = useMutation({
    mutationFn: async (id: string) => { const { error } = await db.from("estoque_itens").delete().eq("id", id); if (error) throw error; },
    onSuccess: () => { toast.success("Item removido"); qc.invalidateQueries({ queryKey: ["estoque"] }); },
  });

  return (
    <PageShell title="Estoque" description="Insumos: tintas, filmes, tecidos, linhas." actions={<ItemDialog />}>
      {isLoading ? <p className="text-sm text-muted-foreground">Carregando…</p> : data.length === 0 ? (
        <div className="rounded-xl border border-dashed border-border bg-card/40 p-10 text-center text-sm text-muted-foreground">
          Nenhum item cadastrado.
        </div>
      ) : (
        <div className="overflow-auto rounded-xl border border-border bg-card">
          <table className="w-full text-sm">
            <thead><tr className="border-b border-border text-left text-xs uppercase text-muted-foreground">
              <th className="px-4 py-3">Item</th>
              <th className="px-4 py-3">Categoria</th>
              <th className="px-4 py-3 text-right">Qtd</th>
              <th className="px-4 py-3 text-right">Mínimo</th>
              <th className="px-4 py-3">Status</th>
              <th className="px-4 py-3" />
            </tr></thead>
            <tbody>
              {data.map((i) => {
                const baixo = Number(i.quantidade) <= Number(i.quantidade_minima);
                return (
                  <tr key={i.id} className="border-b border-border/60 hover:bg-muted/30">
                    <td className="px-4 py-3 font-medium">{i.nome}</td>
                    <td className="px-4 py-3 text-muted-foreground">{i.categoria}</td>
                    <td className="px-4 py-3 text-right">{Number(i.quantidade)} {i.unidade}</td>
                    <td className="px-4 py-3 text-right text-muted-foreground">{Number(i.quantidade_minima)} {i.unidade}</td>
                    <td className="px-4 py-3">
                      {baixo ? (
                        <span className="inline-flex items-center gap-1 rounded-full bg-warning/15 px-2 py-0.5 text-xs text-warning">
                          <AlertTriangle className="h-3 w-3" />Baixo
                        </span>
                      ) : <span className="text-xs text-success">● OK</span>}
                    </td>
                    <td className="px-4 py-3 text-right">
                      <Button size="icon" variant="ghost" onClick={() => del.mutate(i.id)}>
                        <Trash2 className="h-4 w-4 text-destructive" />
                      </Button>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      )}
    </PageShell>
  );
}

function ItemDialog() {
  const [open, setOpen] = useState(false);
  const qc = useQueryClient();
  const [form, setForm] = useState({ nome: "", categoria: "TINTA", unidade: "un", quantidade: "0", quantidade_minima: "0" });

  const save = useMutation({
    mutationFn: async () => {
      if (!form.nome.trim()) throw new Error("Nome é obrigatório");
      const { error } = await db.from("estoque_itens").insert({
        nome: form.nome.trim(), categoria: form.categoria, unidade: form.unidade,
        quantidade: Number(form.quantidade), quantidade_minima: Number(form.quantidade_minima),
      });
      if (error) throw error;
    },
    onSuccess: () => {
      toast.success("Item cadastrado");
      qc.invalidateQueries({ queryKey: ["estoque"] });
      qc.invalidateQueries({ queryKey: ["dashboard"] });
      setOpen(false);
      setForm({ nome: "", categoria: "TINTA", unidade: "un", quantidade: "0", quantidade_minima: "0" });
    },
    onError: (e: Error) => toast.error(e.message),
  });

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild><Button><Plus className="mr-2 h-4 w-4" />Novo item</Button></DialogTrigger>
      <DialogContent>
        <DialogHeader><DialogTitle>Novo item de estoque</DialogTitle></DialogHeader>
        <div className="space-y-3">
          <div><Label>Nome *</Label><Input value={form.nome} onChange={(e) => setForm({ ...form, nome: e.target.value })} /></div>
          <div className="grid grid-cols-2 gap-3">
            <div><Label>Categoria</Label><Input value={form.categoria} onChange={(e) => setForm({ ...form, categoria: e.target.value })} placeholder="TINTA / FILME / TECIDO..." /></div>
            <div><Label>Unidade</Label><Input value={form.unidade} onChange={(e) => setForm({ ...form, unidade: e.target.value })} placeholder="un, m, kg..." /></div>
          </div>
          <div className="grid grid-cols-2 gap-3">
            <div><Label>Quantidade</Label><Input type="number" step="0.01" value={form.quantidade} onChange={(e) => setForm({ ...form, quantidade: e.target.value })} /></div>
            <div><Label>Mínimo</Label><Input type="number" step="0.01" value={form.quantidade_minima} onChange={(e) => setForm({ ...form, quantidade_minima: e.target.value })} /></div>
          </div>
        </div>
        <DialogFooter>
          <Button variant="ghost" onClick={() => setOpen(false)}>Cancelar</Button>
          <Button onClick={() => save.mutate()} disabled={save.isPending}>Salvar</Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
