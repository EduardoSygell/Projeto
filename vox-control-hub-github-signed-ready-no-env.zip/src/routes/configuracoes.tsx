import { createFileRoute } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { toast } from "sonner";
import { Plus, Trash2, Check } from "lucide-react";
import { PageShell } from "@/components/page-shell";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import {
  Select, SelectContent, SelectItem, SelectTrigger, SelectValue,
} from "@/components/ui/select";
import {
  Dialog, DialogContent, DialogFooter, DialogHeader, DialogTitle, DialogTrigger,
} from "@/components/ui/dialog";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { supabase } from "@/integrations/supabase/client";
import { db } from "@/lib/db";
import type { Database } from "@/integrations/supabase/types";
import { PrecificacaoTab } from "@/features/configuracoes/precificacao-tab";

export const Route = createFileRoute("/configuracoes")({
  head: () => ({ meta: [{ title: "Configurações — VOX Control" }] }),
  component: Page,
});

type Tarefa = Database["public"]["Tables"]["tarefas"]["Row"];
type StatusTarefa = Database["public"]["Enums"]["status_tarefa"];
type Prioridade = Database["public"]["Enums"]["prioridade"];

const STATUS_TAREFA: StatusTarefa[] = ["ABERTA", "EM_ANDAMENTO", "CONCLUIDA", "CANCELADA"];
const PRIORIDADES: Prioridade[] = ["BAIXA", "MEDIA", "ALTA", "URGENTE"];

function Page() {
  const qc = useQueryClient();
  const [nome, setNome] = useState("");
  const [telefone, setTelefone] = useState("");

  const { data: profile } = useQuery({
    queryKey: ["profile-self"],
    queryFn: async () => {
      const { data: u } = await supabase.auth.getUser();
      if (!u.user) return null;
      const { data, error } = await db.from("profiles").select("*").eq("id", u.user.id).maybeSingle();
      if (error) throw error;
      return data;
    },
  });

  useEffect(() => {
    if (profile) { setNome(profile.nome ?? ""); setTelefone(profile.telefone ?? ""); }
  }, [profile]);

  const saveProfile = useMutation({
    mutationFn: async () => {
      const { data: u } = await supabase.auth.getUser();
      if (!u.user) throw new Error("Sem sessão");
      if (!nome.trim()) throw new Error("Nome é obrigatório");
      const { error } = await db.from("profiles").upsert({ id: u.user.id, nome: nome.trim(), telefone: telefone || null });
      if (error) throw error;
    },
    onSuccess: () => { toast.success("Perfil salvo"); qc.invalidateQueries({ queryKey: ["profile-self"] }); },
    onError: (e: Error) => toast.error(e.message),
  });

  const { data: tarefas = [] } = useQuery({
    queryKey: ["tarefas"],
    queryFn: async () => {
      const { data, error } = await db.from("tarefas").select("*").order("created_at", { ascending: false });
      if (error) throw error;
      return data as Tarefa[];
    },
  });

  const updateTarefa = useMutation({
    mutationFn: async ({ id, status }: { id: string; status: StatusTarefa }) => {
      const { error } = await db.from("tarefas").update({ status }).eq("id", id);
      if (error) throw error;
    },
    onSuccess: () => { qc.invalidateQueries({ queryKey: ["tarefas"] }); },
  });

  const delTarefa = useMutation({
    mutationFn: async (id: string) => { const { error } = await db.from("tarefas").delete().eq("id", id); if (error) throw error; },
    onSuccess: () => { toast.success("Tarefa removida"); qc.invalidateQueries({ queryKey: ["tarefas"] }); },
  });

  return (
    <PageShell title="Configurações" description="Perfil, tarefas internas e preferências.">
      <Tabs defaultValue="perfil" className="space-y-4">
        <TabsList>
          <TabsTrigger value="perfil">Perfil</TabsTrigger>
          <TabsTrigger value="tarefas">Tarefas</TabsTrigger>
          <TabsTrigger value="precificacao">Precificação</TabsTrigger>
        </TabsList>

        <TabsContent value="perfil" className="space-y-4">
          <div className="rounded-xl border border-border bg-card p-5 max-w-xl">
            <h3 className="mb-3 text-sm font-semibold">Perfil</h3>
            <div className="space-y-3">
              <div><Label>Nome</Label><Input value={nome} onChange={(e) => setNome(e.target.value)} /></div>
              <div><Label>Telefone</Label><Input value={telefone} onChange={(e) => setTelefone(e.target.value)} /></div>
              <Button onClick={() => saveProfile.mutate()} disabled={saveProfile.isPending}>Salvar perfil</Button>
            </div>
          </div>
          <div className="rounded-xl border border-border bg-card p-5 max-w-xl">
            <h3 className="mb-2 text-sm font-semibold">Sobre o VOX Control</h3>
            <p className="text-xs text-muted-foreground">
              Sistema interno da VOX Mode. Versão 0.1 · PWA instalável · pronto para empacotamento Android com Capacitor.
            </p>
          </div>
        </TabsContent>

        <TabsContent value="tarefas">
          <div className="rounded-xl border border-border bg-card p-5">
            <div className="mb-3 flex items-center justify-between">
              <h3 className="text-sm font-semibold">Tarefas internas</h3>
              <NovaTarefaDialog />
            </div>
            {tarefas.length === 0 ? <p className="text-xs text-muted-foreground">Sem tarefas.</p> : (
              <ul className="space-y-2">
                {tarefas.map((t) => (
                  <li key={t.id} className="flex items-center gap-2 rounded-lg border border-border/60 p-2">
                    <button
                      onClick={() => updateTarefa.mutate({ id: t.id, status: t.status === "CONCLUIDA" ? "ABERTA" : "CONCLUIDA" })}
                      className={`flex h-5 w-5 items-center justify-center rounded border ${t.status === "CONCLUIDA" ? "bg-success/20 border-success/40" : "border-border"}`}
                    >
                      {t.status === "CONCLUIDA" && <Check className="h-3 w-3 text-success" />}
                    </button>
                    <div className="flex-1 min-w-0">
                      <p className={`text-sm ${t.status === "CONCLUIDA" ? "line-through text-muted-foreground" : ""}`}>{t.titulo}</p>
                      {t.descricao && <p className="text-xs text-muted-foreground truncate">{t.descricao}</p>}
                    </div>
                    <span className="text-[10px] uppercase tracking-wider text-muted-foreground">{t.prioridade}</span>
                    <button onClick={() => delTarefa.mutate(t.id)} className="text-destructive"><Trash2 className="h-4 w-4" /></button>
                  </li>
                ))}
              </ul>
            )}
          </div>
        </TabsContent>

        <TabsContent value="precificacao">
          <PrecificacaoTab />
        </TabsContent>
      </Tabs>
    </PageShell>
  );
}

function NovaTarefaDialog() {
  const [open, setOpen] = useState(false);
  const qc = useQueryClient();
  const [form, setForm] = useState({ titulo: "", descricao: "", prioridade: "MEDIA" as Prioridade, status: "ABERTA" as StatusTarefa });

  const save = useMutation({
    mutationFn: async () => {
      if (!form.titulo.trim()) throw new Error("Título é obrigatório");
      const { error } = await db.from("tarefas").insert({
        titulo: form.titulo.trim(),
        descricao: form.descricao || null,
        prioridade: form.prioridade,
        status: form.status,
      });
      if (error) throw error;
    },
    onSuccess: () => {
      toast.success("Tarefa criada");
      qc.invalidateQueries({ queryKey: ["tarefas"] });
      setOpen(false);
      setForm({ titulo: "", descricao: "", prioridade: "MEDIA", status: "ABERTA" });
    },
    onError: (e: Error) => toast.error(e.message),
  });

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild><Button size="sm"><Plus className="mr-1 h-4 w-4" />Nova</Button></DialogTrigger>
      <DialogContent>
        <DialogHeader><DialogTitle>Nova tarefa</DialogTitle></DialogHeader>
        <div className="space-y-3">
          <div><Label>Título *</Label><Input value={form.titulo} onChange={(e) => setForm({ ...form, titulo: e.target.value })} /></div>
          <div><Label>Descrição</Label><Textarea rows={3} value={form.descricao} onChange={(e) => setForm({ ...form, descricao: e.target.value })} /></div>
          <div className="grid grid-cols-2 gap-3">
            <div>
              <Label>Prioridade</Label>
              <Select value={form.prioridade} onValueChange={(v) => setForm({ ...form, prioridade: v as Prioridade })}>
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent>{PRIORIDADES.map((p) => <SelectItem key={p} value={p}>{p}</SelectItem>)}</SelectContent>
              </Select>
            </div>
            <div>
              <Label>Status</Label>
              <Select value={form.status} onValueChange={(v) => setForm({ ...form, status: v as StatusTarefa })}>
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent>{STATUS_TAREFA.map((s) => <SelectItem key={s} value={s}>{s}</SelectItem>)}</SelectContent>
              </Select>
            </div>
          </div>
        </div>
        <DialogFooter>
          <Button variant="ghost" onClick={() => setOpen(false)}>Cancelar</Button>
          <Button onClick={() => save.mutate()} disabled={save.isPending}>Salvar</Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
