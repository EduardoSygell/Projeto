import { createFileRoute } from "@tanstack/react-router";
import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { toast } from "sonner";
import { Plus, Trash2 } from "lucide-react";
import { PageShell } from "@/components/page-shell";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Select, SelectContent, SelectItem, SelectTrigger, SelectValue,
} from "@/components/ui/select";
import {
  Dialog, DialogContent, DialogFooter, DialogHeader, DialogTitle, DialogTrigger,
} from "@/components/ui/dialog";
import { MachineBadge } from "@/components/status-badge";
import { db, type Maquina } from "@/lib/db";
import type { Database } from "@/integrations/supabase/types";

export const Route = createFileRoute("/maquinas")({
  head: () => ({ meta: [{ title: "Máquinas — VOX Control" }] }),
  component: Page,
});

type Tecnica = Database["public"]["Enums"]["tecnica_producao"];
type StatusMaquina = Database["public"]["Enums"]["status_maquina"];

const TECNICAS: Tecnica[] = ["DTF", "DTG", "BORDADO", "PRENSA"];
const STATUS: StatusMaquina[] = ["OPERACIONAL", "MANUTENCAO", "PARADA"];

function Page() {
  const qc = useQueryClient();
  const { data = [], isLoading } = useQuery({
    queryKey: ["maquinas"],
    queryFn: async () => {
      const { data, error } = await db.from("maquinas").select("*").order("nome");
      if (error) throw error;
      return data as Maquina[];
    },
  });

  const updateStatus = useMutation({
    mutationFn: async ({ id, status }: { id: string; status: StatusMaquina }) => {
      const { error } = await db.from("maquinas").update({ status }).eq("id", id);
      if (error) throw error;
    },
    onSuccess: () => { toast.success("Status atualizado"); qc.invalidateQueries({ queryKey: ["maquinas"] }); qc.invalidateQueries({ queryKey: ["dashboard"] }); },
  });

  const del = useMutation({
    mutationFn: async (id: string) => { const { error } = await db.from("maquinas").delete().eq("id", id); if (error) throw error; },
    onSuccess: () => { toast.success("Removida"); qc.invalidateQueries({ queryKey: ["maquinas"] }); },
  });

  return (
    <PageShell title="Máquinas e Manutenção" description="Estado e técnica de cada máquina." actions={<MaquinaDialog />}>
      {isLoading ? <p className="text-sm text-muted-foreground">Carregando…</p> : data.length === 0 ? (
        <div className="rounded-xl border border-dashed border-border bg-card/40 p-10 text-center text-sm text-muted-foreground">
          Nenhuma máquina cadastrada.
        </div>
      ) : (
        <div className="grid gap-4 md:grid-cols-2 xl:grid-cols-3">
          {data.map((m) => (
            <div key={m.id} className="rounded-xl border border-border bg-card p-5">
              <div className="flex items-start justify-between gap-2">
                <div>
                  <h3 className="text-sm font-semibold">{m.nome}</h3>
                  <p className="mt-0.5 text-xs text-muted-foreground">{m.tecnica}</p>
                </div>
                <MachineBadge status={m.status} />
              </div>
              {m.modelo && <p className="mt-3 text-xs text-muted-foreground">Modelo: {m.modelo}</p>}
              {m.fabricante && <p className="text-xs text-muted-foreground">Fabricante: {m.fabricante}</p>}
              <div className="mt-4 flex items-center gap-2">
                <Select value={m.status} onValueChange={(v) => updateStatus.mutate({ id: m.id, status: v as StatusMaquina })}>
                  <SelectTrigger className="h-8 text-xs"><SelectValue /></SelectTrigger>
                  <SelectContent>{STATUS.map((s) => <SelectItem key={s} value={s}>{s}</SelectItem>)}</SelectContent>
                </Select>
                <Button size="icon" variant="ghost" onClick={() => del.mutate(m.id)}>
                  <Trash2 className="h-4 w-4 text-destructive" />
                </Button>
              </div>
            </div>
          ))}
        </div>
      )}
    </PageShell>
  );
}

function MaquinaDialog() {
  const [open, setOpen] = useState(false);
  const qc = useQueryClient();
  const [form, setForm] = useState({ nome: "", tecnica: "DTF" as Tecnica, modelo: "", fabricante: "" });

  const save = useMutation({
    mutationFn: async () => {
      if (!form.nome.trim()) throw new Error("Nome é obrigatório");
      const { error } = await db.from("maquinas").insert({
        nome: form.nome.trim(), tecnica: form.tecnica,
        modelo: form.modelo || null, fabricante: form.fabricante || null,
      });
      if (error) throw error;
    },
    onSuccess: () => {
      toast.success("Máquina cadastrada");
      qc.invalidateQueries({ queryKey: ["maquinas"] });
      setOpen(false);
      setForm({ nome: "", tecnica: "DTF", modelo: "", fabricante: "" });
    },
    onError: (e: Error) => toast.error(e.message),
  });

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild><Button><Plus className="mr-2 h-4 w-4" />Nova máquina</Button></DialogTrigger>
      <DialogContent>
        <DialogHeader><DialogTitle>Nova máquina</DialogTitle></DialogHeader>
        <div className="space-y-3">
          <div><Label>Nome *</Label><Input value={form.nome} onChange={(e) => setForm({ ...form, nome: e.target.value })} /></div>
          <div>
            <Label>Técnica</Label>
            <Select value={form.tecnica} onValueChange={(v) => setForm({ ...form, tecnica: v as Tecnica })}>
              <SelectTrigger><SelectValue /></SelectTrigger>
              <SelectContent>{TECNICAS.map((t) => <SelectItem key={t} value={t}>{t}</SelectItem>)}</SelectContent>
            </Select>
          </div>
          <div className="grid grid-cols-2 gap-3">
            <div><Label>Modelo</Label><Input value={form.modelo} onChange={(e) => setForm({ ...form, modelo: e.target.value })} /></div>
            <div><Label>Fabricante</Label><Input value={form.fabricante} onChange={(e) => setForm({ ...form, fabricante: e.target.value })} /></div>
          </div>
        </div>
        <DialogFooter>
          <Button variant="ghost" onClick={() => setOpen(false)}>Cancelar</Button>
          <Button onClick={() => save.mutate()} disabled={save.isPending}>Salvar</Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
