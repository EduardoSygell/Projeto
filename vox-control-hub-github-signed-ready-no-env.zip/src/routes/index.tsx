import { createFileRoute, Link } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import {
  TrendingUp, Factory, AlertTriangle, Palette, Boxes, Wallet, CalendarClock, Clock,
  CreditCard, Wrench, PiggyBank, ArrowDownToLine, Plus, UserPlus, PackagePlus,
  FileWarning, CheckCircle2, Banknote, DollarSign,
} from "lucide-react";
import { PageShell } from "@/components/page-shell";
import { OrderStatusBadge, PaymentBadge } from "@/components/status-badge";
import { db } from "@/lib/db";
import { formatDateBR } from "@/lib/format";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "Dashboard — VOX Control" },
      { name: "description", content: "Visão geral da operação VOX Mode em tempo real." },
    ],
  }),
  component: Dashboard,
});

const brl = (n: number) => Number(n).toLocaleString("pt-BR", { style: "currency", currency: "BRL" });

type Tone = "primary" | "info" | "warning" | "danger" | "success";
const toneMap: Record<Tone, string> = {
  primary: "from-primary/20 to-primary/5 text-primary",
  info: "from-info/20 to-info/5 text-info",
  warning: "from-warning/20 to-warning/5 text-warning",
  danger: "from-destructive/20 to-destructive/5 text-destructive",
  success: "from-success/20 to-success/5 text-success",
};

function KpiCard({ icon: Icon, label, value, hint, tone = "primary", to }: {
  icon: React.ElementType; label: string; value: string; hint?: string; tone?: Tone; to?: string;
}) {
  const cls = toneMap[tone];
  const Body = (
    <div className="group relative h-full overflow-hidden rounded-xl border border-border bg-card p-5 transition hover:border-primary/40">
      <div className={`absolute -right-8 -top-8 h-32 w-32 rounded-full bg-gradient-to-br ${cls} opacity-40 blur-2xl`} />
      <div className="relative flex items-start justify-between">
        <div>
          <p className="text-xs uppercase tracking-wider text-muted-foreground">{label}</p>
          <p className="mt-2 text-2xl font-bold">{value}</p>
          {hint && <p className="mt-1 text-xs text-muted-foreground">{hint}</p>}
        </div>
        <div className={`rounded-lg bg-gradient-to-br p-2 ${cls}`}><Icon className="h-5 w-5" /></div>
      </div>
    </div>
  );
  return to ? <Link to={to as never} className="block">{Body}</Link> : Body;
}

function QuickAction({ icon: Icon, label, to, tone = "primary" }: {
  icon: React.ElementType; label: string; to: string; tone?: Tone;
}) {
  const cls = toneMap[tone];
  return (
    <Link to={to as never} className="group flex flex-col items-center justify-center gap-2 rounded-xl border border-border bg-card p-4 text-center transition hover:-translate-y-0.5 hover:border-primary/40 hover:shadow-lg">
      <div className={`rounded-lg bg-gradient-to-br p-2 ${cls}`}><Icon className="h-5 w-5" /></div>
      <span className="text-xs font-medium">{label}</span>
    </Link>
  );
}

function Dashboard() {
  const today = new Date().toISOString().slice(0, 10);
  const monthStart = new Date(); monthStart.setDate(1);
  const monthStartStr = monthStart.toISOString().slice(0, 10);

  const { data: stats } = useQuery({
    queryKey: ["dashboard"],
    queryFn: async () => {
      const [pedidosRes, receberRes, estoqueRes, maquinasRes] = await Promise.all([
        db.from("pedidos").select("*, cliente:clientes(nome)").order("created_at", { ascending: false }),
        db.from("financeiro_receber").select("*"),
        db.from("estoque_itens").select("*"),
        db.from("maquinas").select("*"),
      ]);
      if (pedidosRes.error) throw pedidosRes.error;
      if (receberRes.error) throw receberRes.error;
      if (estoqueRes.error) throw estoqueRes.error;
      if (maquinasRes.error) throw maquinasRes.error;
      return {
        pedidos: pedidosRes.data,
        receber: receberRes.data,
        estoque: estoqueRes.data,
        maquinas: maquinasRes.data,
      };
    },
  });

  const pedidos = stats?.pedidos ?? [];
  const receber = stats?.receber ?? [];
  const estoque = stats?.estoque ?? [];
  const maquinas = stats?.maquinas ?? [];

  const ordersDueToday = pedidos.filter((p) => p.data_entrega === today && p.status !== "ENTREGUE" && p.status !== "CANCELADO").length;
  const ordersLate = pedidos.filter((p) => p.data_entrega && p.data_entrega < today && p.status !== "ENTREGUE" && p.status !== "CANCELADO").length;
  const ordersAwaitingArt = pedidos.filter((p) => p.status === "AGUARDANDO_ARTE").length;
  const ordersAwaitingPayment = pedidos.filter((p) => p.status_pagamento === "PENDENTE" || p.status_pagamento === "ATRASADO").length;
  const customersInDebt = new Set(pedidos.filter((p) => p.status_pagamento !== "PAGO").map((p) => p.cliente_id)).size;

  const revenueMonth = pedidos
    .filter((p) => p.created_at >= monthStartStr && p.status !== "CANCELADO")
    .reduce((s, p) => s + Number(p.valor_total), 0);
  const receivedMonth = receber
    .filter((r) => r.status === "PAGO" && r.pago_em && r.pago_em >= monthStartStr)
    .reduce((s, r) => s + Number(r.valor), 0);
  const receivable = receber.filter((r) => r.status !== "PAGO").reduce((s, r) => s + Number(r.valor), 0);
  const estimatedProfit = revenueMonth * 0.4;

  const lowStock = estoque.filter((i) => Number(i.quantidade) <= Number(i.quantidade_minima)).length;
  const machinesMaintenance = maquinas.filter((m) => m.status === "MANUTENCAO" || m.status === "PARADA").length;

  const recent = pedidos.slice(0, 5);

  return (
    <PageShell title="Dashboard" description="Visão geral da operação VOX Mode.">
      <Link
        to="/pedido-novo"
        className="group relative block overflow-hidden rounded-2xl border border-primary/40 bg-gradient-to-br from-primary/20 via-info/10 to-background p-6 transition hover:border-primary"
      >
        <div className="absolute -right-10 -top-10 h-40 w-40 rounded-full bg-primary/30 blur-3xl" />
        <div className="relative flex items-center gap-4">
          <div className="rounded-xl bg-gradient-to-br from-primary to-info p-3 text-primary-foreground shadow-lg">
            <Plus className="h-6 w-6" />
          </div>
          <div className="flex-1">
            <p className="text-xs uppercase tracking-widest text-muted-foreground">Comece por aqui</p>
            <h2 className="text-xl font-bold sm:text-2xl">+ Novo Cliente / Pedido Completo</h2>
            <p className="text-xs text-muted-foreground">Cliente, pedido, técnicas, arquivos, precificação e orçamento — em um único fluxo.</p>
          </div>
          <span className="hidden text-sm font-semibold text-primary group-hover:underline sm:inline">Abrir →</span>
        </div>
      </Link>

      <div>
        <h2 className="mb-3 text-xs font-semibold uppercase tracking-wider text-muted-foreground">Ações rápidas</h2>
        <div className="grid grid-cols-2 gap-3 sm:grid-cols-4 lg:grid-cols-7">
          <QuickAction icon={Plus} label="Novo Pedido" to="/pedidos" tone="primary" />
          <QuickAction icon={UserPlus} label="Novo Cliente" to="/clientes" tone="info" />
          <QuickAction icon={Banknote} label="Lançar Pagamento" to="/financeiro" tone="success" />
          <QuickAction icon={FileWarning} label="Registrar Perda" to="/estoque" tone="danger" />
          <QuickAction icon={Wrench} label="Nova Manutenção" to="/maquinas" tone="warning" />
          <QuickAction icon={PackagePlus} label="Entrada Estoque" to="/estoque" tone="info" />
          <QuickAction icon={CheckCircle2} label="Aprovar Arte" to="/aprovacao" tone="warning" />
        </div>
      </div>

      <div>
        <h2 className="mb-3 text-xs font-semibold uppercase tracking-wider text-muted-foreground">Operação do dia</h2>
        <div className="grid gap-4 sm:grid-cols-2 xl:grid-cols-4">
          <KpiCard icon={CalendarClock} label="Entregar hoje" value={String(ordersDueToday)} hint="Pedidos com prazo hoje" tone="info" to="/pedidos" />
          <KpiCard icon={Clock} label="Atrasados" value={String(ordersLate)} hint="Ação imediata" tone="danger" to="/prioridades" />
          <KpiCard icon={Palette} label="Aguardando arte" value={String(ordersAwaitingArt)} tone="warning" to="/aprovacao" />
          <KpiCard icon={CreditCard} label="Aguardando pagto" value={String(ordersAwaitingPayment)} hint={`${customersInDebt} clientes em débito`} tone="warning" to="/financeiro" />
        </div>
      </div>

      <div>
        <h2 className="mb-3 text-xs font-semibold uppercase tracking-wider text-muted-foreground">Financeiro do mês</h2>
        <div className="grid gap-4 sm:grid-cols-2 xl:grid-cols-4">
          <KpiCard icon={TrendingUp} label="Total vendido" value={brl(revenueMonth)} tone="primary" />
          <KpiCard icon={ArrowDownToLine} label="Total recebido" value={brl(receivedMonth)} tone="success" />
          <KpiCard icon={Wallet} label="A receber" value={brl(receivable)} tone="info" to="/financeiro" />
          <KpiCard icon={PiggyBank} label="Lucro estimado" value={brl(estimatedProfit)} hint="40% da receita (estimado)" tone="success" />
        </div>
      </div>

      <div className="grid gap-4 lg:grid-cols-3">
        <div className="rounded-xl border border-border bg-card p-5">
          <div className="mb-3 flex items-center justify-between">
            <h3 className="text-sm font-semibold">Estoque baixo</h3>
            <Boxes className="h-4 w-4 text-warning" />
          </div>
          <p className="text-3xl font-bold">{lowStock}</p>
          <p className="mt-1 text-xs text-muted-foreground">itens abaixo do mínimo</p>
          <Link to="/estoque" className="mt-3 inline-block text-xs text-primary hover:underline">Ver estoque →</Link>
        </div>
        <div className="rounded-xl border border-border bg-card p-5">
          <div className="mb-3 flex items-center justify-between">
            <h3 className="text-sm font-semibold">Máquinas com problema</h3>
            <Wrench className="h-4 w-4 text-warning" />
          </div>
          <p className="text-3xl font-bold">{machinesMaintenance}</p>
          <p className="mt-1 text-xs text-muted-foreground">em manutenção ou paradas</p>
          <Link to="/maquinas" className="mt-3 inline-block text-xs text-primary hover:underline">Ver máquinas →</Link>
        </div>
        <div className="rounded-xl border border-border bg-card p-5">
          <div className="mb-3 flex items-center justify-between">
            <h3 className="text-sm font-semibold">Clientes em débito</h3>
            <DollarSign className="h-4 w-4 text-destructive" />
          </div>
          <p className="text-3xl font-bold">{customersInDebt}</p>
          <p className="mt-1 text-xs text-muted-foreground">com valores em aberto</p>
          <Link to="/clientes" className="mt-3 inline-block text-xs text-primary hover:underline">Ver clientes →</Link>
        </div>
      </div>

      <div className="rounded-xl border border-border bg-card">
        <div className="flex items-center justify-between border-b border-border p-5">
          <div>
            <h3 className="text-sm font-semibold">Pedidos recentes</h3>
            <p className="text-xs text-muted-foreground">Últimas movimentações</p>
          </div>
          <Link to="/pedidos" className="text-xs text-primary hover:underline">Ver todos →</Link>
        </div>
        {recent.length === 0 ? (
          <p className="p-8 text-center text-sm text-muted-foreground">Nenhum pedido cadastrado ainda.</p>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead>
                <tr className="border-b border-border text-left text-xs uppercase tracking-wider text-muted-foreground">
                  <th className="px-5 py-3">Pedido</th>
                  <th className="px-5 py-3">Cliente</th>
                  <th className="px-5 py-3">Entrega</th>
                  <th className="px-5 py-3">Status</th>
                  <th className="px-5 py-3">Pagto</th>
                  <th className="px-5 py-3 text-right">Valor</th>
                </tr>
              </thead>
              <tbody>
                {recent.map((o) => (
                  <tr key={o.id} className="border-b border-border/60 last:border-0 hover:bg-muted/30">
                    <td className="px-5 py-3 font-medium">{o.codigo}</td>
                    <td className="px-5 py-3 text-muted-foreground">{(o as { cliente?: { nome: string } }).cliente?.nome ?? "—"}</td>
                    <td className="px-5 py-3 text-muted-foreground">{formatDateBR(o.data_entrega)}</td>
                    <td className="px-5 py-3"><OrderStatusBadge status={o.status as never} /></td>
                    <td className="px-5 py-3"><PaymentBadge status={o.status_pagamento} /></td>
                    <td className="px-5 py-3 text-right font-medium">{brl(Number(o.valor_total))}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>

      <p className="flex items-center gap-2 text-xs text-muted-foreground">
        <Factory className="h-3.5 w-3.5" />
        Todos os números são puxados em tempo real do seu banco.
      </p>
      <span className="hidden"><AlertTriangle /></span>
    </PageShell>
  );
}
