import { memo, useEffect, useState } from "react";
import { Link, useRouterState } from "@tanstack/react-router";
import {
  LayoutDashboard,
  ShoppingBag,
  PlusCircle,
  Factory,
  Menu,
  Users,
  Palette,
  Boxes,
  BarChart3,
  CalendarDays,
  Wallet,
  Wrench,
  FolderOpen,
  ListChecks,
  Settings,
  Plug,
} from "lucide-react";
import { useIsMobile } from "@/hooks/use-mobile";
import { cn } from "@/lib/utils";
import { MoreDrawer } from "@/components/mobile-more-drawer";

type NavItem = {
  title: string;
  url: string;
  icon: typeof LayoutDashboard;
  exact?: boolean;
  primary?: boolean;
};

const items: NavItem[] = [
  { title: "Início", url: "/", icon: LayoutDashboard, exact: true },
  { title: "Pedidos", url: "/pedidos", icon: ShoppingBag },
  { title: "Novo", url: "/pedido-novo", icon: PlusCircle, primary: true },
  { title: "Produção", url: "/producao", icon: Factory },
];

export const moreShortcuts = [
  { title: "Clientes / CRM", url: "/clientes", icon: Users },
  { title: "Aprovação de Arte", url: "/aprovacao", icon: Palette },
  { title: "Estoque", url: "/estoque", icon: Boxes },
  { title: "Relatórios", url: "/relatorios", icon: BarChart3 },
  { title: "Calendário", url: "/calendario", icon: CalendarDays },
  { title: "Prioridades", url: "/prioridades", icon: ListChecks },
  { title: "Financeiro", url: "/financeiro", icon: Wallet },
  { title: "Máquinas", url: "/maquinas", icon: Wrench },
  { title: "Arquivos", url: "/arquivos", icon: FolderOpen },
  { title: "Configurações", url: "/configuracoes", icon: Settings },
  { title: "Integrações", url: "/integracoes", icon: Plug },
] as const;

function MobileBottomNavInner() {
  const isMobile = useIsMobile();
  // Não montar nada no SSR / desktop — evita custo no bundle de runtime.
  const [mounted, setMounted] = useState(false);
  useEffect(() => setMounted(true), []);

  const path = useRouterState({ select: (r) => r.location.pathname });
  const [moreOpen, setMoreOpen] = useState(false);
  // Só renderiza o subtree do Drawer após primeira abertura — economiza
  // o setup do Vaul (event listeners, focus trap) em devices fracos.
  const [drawerEverOpened, setDrawerEverOpened] = useState(false);

  if (!mounted || !isMobile) return null;

  const isActive = (url: string, exact?: boolean) =>
    exact ? path === url : path === url || path.startsWith(url + "/");

  const openMore = () => {
    setDrawerEverOpened(true);
    setMoreOpen(true);
  };

  return (
    <>
      <nav
        className="fixed inset-x-0 bottom-0 z-40 border-t border-border bg-background/95 backdrop-blur"
        style={{ paddingBottom: "env(safe-area-inset-bottom)" }}
      >
        <ul className="grid grid-cols-5">
          {items.map((it) => {
            const active = isActive(it.url, it.exact);
            if (it.primary) {
              return (
                <li key={it.url} className="flex items-start justify-center">
                  <Link
                    to={it.url}
                    className="-mt-5 flex h-14 w-14 items-center justify-center rounded-full bg-gradient-to-br from-primary to-info text-primary-foreground shadow-[var(--shadow-elegant)] transition-transform active:scale-95"
                    aria-label={it.title}
                  >
                    <it.icon className="h-6 w-6" />
                  </Link>
                </li>
              );
            }
            return (
              <li key={it.url}>
                <Link
                  to={it.url}
                  className={cn(
                    "flex h-14 flex-col items-center justify-center gap-0.5 text-[10px] font-medium",
                    active ? "text-primary" : "text-muted-foreground",
                  )}
                >
                  <it.icon className="h-5 w-5" />
                  <span>{it.title}</span>
                </Link>
              </li>
            );
          })}
          <li>
            <button
              type="button"
              onClick={openMore}
              className="flex h-14 w-full flex-col items-center justify-center gap-0.5 text-[10px] font-medium text-muted-foreground"
              aria-label="Mais opções"
            >
              <Menu className="h-5 w-5" />
              <span>Mais</span>
            </button>
          </li>
        </ul>
      </nav>

      {drawerEverOpened && (
        <MoreDrawer open={moreOpen} onOpenChange={setMoreOpen} currentPath={path} />
      )}
    </>
  );
}

export const MobileBottomNav = memo(MobileBottomNavInner);
