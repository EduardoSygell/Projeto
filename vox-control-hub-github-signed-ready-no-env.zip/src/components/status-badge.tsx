import { cn } from "@/lib/utils";
import type { OrderStatus, Priority, PaymentStatus, MachineStatus, ArtApprovalStatus } from "@/lib/types";

const orderMap: Record<OrderStatus, { label: string; cls: string }> = {
  ORCAMENTO:             { label: "Orçamento",           cls: "bg-muted text-muted-foreground" },
  AGUARDANDO_APROVACAO:  { label: "Aguard. Aprovação",   cls: "bg-muted/60 text-foreground border border-border" },
  AGUARDANDO_PAGAMENTO:  { label: "Aguard. Pagamento",   cls: "bg-warning/15 text-warning border border-warning/30" },
  AGUARDANDO_ARTE:       { label: "Aguard. Arte",        cls: "bg-warning/15 text-warning border border-warning/30" },
  ARTE_AJUSTE:           { label: "Arte em Ajuste",      cls: "bg-warning/15 text-warning border border-warning/30" },
  ARTE_APROVADA:         { label: "Arte Aprovada",       cls: "bg-info/15 text-info border border-info/30" },
  SEPARAR_PECAS:         { label: "Separar Peças",       cls: "bg-info/15 text-info border border-info/30" },
  EM_PRODUCAO:           { label: "Em Produção",         cls: "bg-info/20 text-info border border-info/40" },
  ACABAMENTO:            { label: "Acabamento",          cls: "bg-info/15 text-info border border-info/30" },
  CONFERENCIA:           { label: "Conferência",         cls: "bg-info/15 text-info border border-info/30" },
  PRONTO:                { label: "Pronto",              cls: "bg-success/15 text-success border border-success/30" },
  ENTREGUE:              { label: "Entregue",            cls: "bg-success/20 text-success border border-success/30" },
  FINALIZADO:            { label: "Finalizado",          cls: "bg-success/25 text-success border border-success/40" },
  CANCELADO:             { label: "Cancelado",           cls: "bg-destructive/15 text-destructive border border-destructive/30" },
};

const priorityMap: Record<Priority, { label: string; cls: string }> = {
  BAIXA:   { label: "Baixa",   cls: "bg-muted text-muted-foreground" },
  MEDIA:   { label: "Média",   cls: "bg-info/15 text-info border border-info/30" },
  ALTA:    { label: "Alta",    cls: "bg-warning/15 text-warning border border-warning/30" },
  URGENTE: { label: "Urgente", cls: "bg-destructive/15 text-destructive border border-destructive/40" },
};

const paymentMap: Record<PaymentStatus, { label: string; cls: string }> = {
  PENDENTE: { label: "Pendente", cls: "bg-warning/15 text-warning border border-warning/30" },
  PARCIAL:  { label: "Parcial",  cls: "bg-info/15 text-info border border-info/30" },
  PAGO:     { label: "Pago",     cls: "bg-success/15 text-success border border-success/30" },
  ATRASADO: { label: "Atrasado", cls: "bg-destructive/15 text-destructive border border-destructive/30" },
};

const machineMap: Record<MachineStatus, { label: string; cls: string }> = {
  OPERACIONAL: { label: "Operacional", cls: "bg-success/15 text-success border border-success/30" },
  MANUTENCAO:  { label: "Manutenção",  cls: "bg-warning/15 text-warning border border-warning/30" },
  PARADA:      { label: "Parada",      cls: "bg-destructive/15 text-destructive border border-destructive/30" },
};

const artMap: Record<ArtApprovalStatus, { label: string; cls: string }> = {
  PENDENTE:  { label: "Arte pendente",  cls: "bg-muted text-muted-foreground" },
  EM_AJUSTE: { label: "Arte em ajuste", cls: "bg-warning/15 text-warning border border-warning/30" },
  APROVADA:  { label: "Arte aprovada",  cls: "bg-success/15 text-success border border-success/30" },
  REJEITADA: { label: "Arte rejeitada", cls: "bg-destructive/15 text-destructive border border-destructive/30" },
};

const base = "inline-flex items-center rounded-full px-2.5 py-0.5 text-xs font-medium whitespace-nowrap";

export function OrderStatusBadge({ status }: { status: OrderStatus }) {
  const m = orderMap[status]; return <span className={cn(base, m.cls)}>{m.label}</span>;
}
export function PriorityBadge({ priority }: { priority: Priority }) {
  const m = priorityMap[priority]; return <span className={cn(base, m.cls)}>{m.label}</span>;
}
export function PaymentBadge({ status }: { status: PaymentStatus }) {
  const m = paymentMap[status]; return <span className={cn(base, m.cls)}>{m.label}</span>;
}
export function MachineBadge({ status }: { status: MachineStatus }) {
  const m = machineMap[status]; return <span className={cn(base, m.cls)}>{m.label}</span>;
}
export function ArtBadge({ status }: { status: ArtApprovalStatus }) {
  const m = artMap[status]; return <span className={cn(base, m.cls)}>{m.label}</span>;
}

export const ORDER_STATUS_LABEL: Record<OrderStatus, string> = Object.fromEntries(
  Object.entries(orderMap).map(([k, v]) => [k, v.label])
) as Record<OrderStatus, string>;
