import { Wifi, WifiOff, CloudUpload, RefreshCw, AlertTriangle } from "lucide-react";
import { useOnlineStatus } from "@/hooks/use-online-status";
import { cn } from "@/lib/utils";

export function OnlineIndicator({ className }: { className?: string }) {
  const { online, pending, syncing, error } = useOnlineStatus();

  const tone = error
    ? "border-destructive/40 bg-destructive/10 text-destructive"
    : syncing
      ? "border-sky-500/30 bg-sky-500/10 text-sky-700 dark:text-sky-300"
      : online
        ? "border-emerald-500/30 bg-emerald-500/10 text-emerald-700 dark:text-emerald-300"
        : "border-amber-500/30 bg-amber-500/10 text-amber-700 dark:text-amber-300";

  const label = error
    ? "Erro de sync"
    : syncing
      ? "Sincronizando"
      : online
        ? "Online"
        : "Offline";

  const Icon = error
    ? AlertTriangle
    : syncing
      ? RefreshCw
      : online
        ? Wifi
        : WifiOff;

  return (
    <div
      className={cn(
        "inline-flex items-center gap-2 rounded-full border px-3 py-1 text-xs font-medium",
        tone,
        className,
      )}
      title={
        error
          ? `Algumas alterações falharam: ${error}`
          : syncing
            ? "Enviando alterações pendentes..."
            : online
              ? "Conectado"
              : "Modo offline — alterações serão enviadas ao reconectar"
      }
    >
      <Icon className={cn("h-3.5 w-3.5", syncing && "animate-spin")} />
      <span>{label}</span>
      {pending > 0 && (
        <span className="inline-flex items-center gap-1 border-l pl-2">
          <CloudUpload className="h-3.5 w-3.5" />
          {pending}
        </span>
      )}
    </div>
  );
}
