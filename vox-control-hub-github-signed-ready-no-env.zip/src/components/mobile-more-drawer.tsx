import { Link } from "@tanstack/react-router";
import {
  Drawer,
  DrawerContent,
  DrawerHeader,
  DrawerTitle,
  DrawerClose,
} from "@/components/ui/drawer";
import { cn } from "@/lib/utils";
import { moreShortcuts } from "@/components/mobile-bottom-nav";

interface MoreDrawerProps {
  open: boolean;
  onOpenChange: (v: boolean) => void;
  currentPath: string;
}

export function MoreDrawer({ open, onOpenChange, currentPath }: MoreDrawerProps) {
  const isActive = (url: string) =>
    currentPath === url || currentPath.startsWith(url + "/");

  return (
    <Drawer open={open} onOpenChange={onOpenChange}>
      <DrawerContent className="md:hidden">
        <DrawerHeader className="text-left">
          <DrawerTitle>Mais opções</DrawerTitle>
        </DrawerHeader>
        <div
          className="grid grid-cols-3 gap-3 px-4 pb-6"
          style={{ paddingBottom: "calc(env(safe-area-inset-bottom) + 1.5rem)" }}
        >
          {moreShortcuts.map((s) => {
            const active = isActive(s.url);
            return (
              <DrawerClose asChild key={s.url}>
                <Link
                  to={s.url}
                  className={cn(
                    "flex aspect-square flex-col items-center justify-center gap-2 rounded-xl border border-border bg-card p-3 text-center transition-colors active:scale-[0.97]",
                    active && "border-primary/60 bg-primary/10",
                  )}
                >
                  <s.icon
                    className={cn(
                      "h-6 w-6",
                      active ? "text-primary" : "text-foreground",
                    )}
                  />
                  <span className="text-[11px] font-medium leading-tight text-foreground">
                    {s.title}
                  </span>
                </Link>
              </DrawerClose>
            );
          })}
        </div>
      </DrawerContent>
    </Drawer>
  );
}
