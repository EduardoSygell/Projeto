import { Link, useRouterState } from "@tanstack/react-router";
import {
  LayoutDashboard, Users, ShoppingBag, Palette, Factory,
  Boxes, Wallet, Wrench, CalendarDays, ListChecks,
  FolderOpen, BarChart3, Settings, Plug, Sparkles, PlusCircle,
} from "lucide-react";
import {
  Sidebar, SidebarContent, SidebarGroup, SidebarGroupContent, SidebarGroupLabel,
  SidebarMenu, SidebarMenuButton, SidebarMenuItem, SidebarHeader, SidebarFooter,
  useSidebar,
} from "@/components/ui/sidebar";

const groups = [
  {
    label: "Operação",
    items: [
      { title: "Dashboard", url: "/", icon: LayoutDashboard },
      { title: "+ Novo Pedido Completo", url: "/pedido-novo", icon: PlusCircle },
      { title: "Pedidos", url: "/pedidos", icon: ShoppingBag },
      { title: "Aprovação de Arte", url: "/aprovacao", icon: Palette },
      { title: "Produção", url: "/producao", icon: Factory },
      { title: "Calendário", url: "/calendario", icon: CalendarDays },
      { title: "Prioridades", url: "/prioridades", icon: ListChecks },
    ],
  },
  {
    label: "Gestão",
    items: [
      { title: "Clientes / CRM", url: "/clientes", icon: Users },
      { title: "Estoque", url: "/estoque", icon: Boxes },
      { title: "Financeiro", url: "/financeiro", icon: Wallet },
      { title: "Máquinas", url: "/maquinas", icon: Wrench },
      { title: "Arquivos / Artes", url: "/arquivos", icon: FolderOpen },
      { title: "Relatórios", url: "/relatorios", icon: BarChart3 },
    ],
  },
  {
    label: "Sistema",
    items: [
      { title: "Configurações", url: "/configuracoes", icon: Settings },
      { title: "Integrações", url: "/integracoes", icon: Plug },
    ],
  },
];

export function AppSidebar() {
  const { state } = useSidebar();
  const collapsed = state === "collapsed";
  const path = useRouterState({ select: (r) => r.location.pathname });
  const isActive = (url: string) => (url === "/" ? path === "/" : path.startsWith(url));

  return (
    <Sidebar collapsible="icon">
      <SidebarHeader className="border-b border-sidebar-border">
        <div className="flex items-center gap-2 px-2 py-3">
          <div className="flex h-9 w-9 items-center justify-center rounded-lg bg-gradient-to-br from-primary to-info shadow-[var(--shadow-elegant)]">
            <Sparkles className="h-5 w-5 text-primary-foreground" />
          </div>
          {!collapsed && (
            <div className="flex flex-col leading-tight">
              <span className="text-sm font-bold tracking-wider text-sidebar-foreground">VOX CONTROL</span>
              <span className="text-[10px] uppercase tracking-widest text-muted-foreground">VOX — Mode</span>
            </div>
          )}
        </div>
      </SidebarHeader>

      <SidebarContent>
        {groups.map((g) => (
          <SidebarGroup key={g.label}>
            {!collapsed && <SidebarGroupLabel>{g.label}</SidebarGroupLabel>}
            <SidebarGroupContent>
              <SidebarMenu>
                {g.items.map((item) => (
                  <SidebarMenuItem key={item.url}>
                    <SidebarMenuButton asChild isActive={isActive(item.url)} tooltip={item.title}>
                      <Link to={item.url} className="flex items-center gap-2">
                        <item.icon className="h-4 w-4 shrink-0" />
                        {!collapsed && <span>{item.title}</span>}
                      </Link>
                    </SidebarMenuButton>
                  </SidebarMenuItem>
                ))}
              </SidebarMenu>
            </SidebarGroupContent>
          </SidebarGroup>
        ))}
      </SidebarContent>

      <SidebarFooter className="border-t border-sidebar-border">
        {!collapsed && (
          <div className="px-2 py-2 text-[10px] uppercase tracking-widest text-muted-foreground">
            v0.1 · Interno
          </div>
        )}
      </SidebarFooter>
    </Sidebar>
  );
}
