# VOX Control

Mini ERP interno da **VOX - Mode** (estamparia): clientes, pedidos, fichas técnicas (DTF / DTG / Bordado), produção, calendário, estoque, financeiro, relatórios e arquivos — com **modo offline-first** (IndexedDB + outbox de sincronização) e empacotamento para **Web / PWA**, **Android (APK via Capacitor)** e **Desktop (Electron)**.

---

## 1. Stack

- React 19 + TanStack Start (SSR) + Vite 7
- Tailwind v4 + shadcn/ui
- Lovable Cloud (Supabase) — Auth, Postgres, Storage
- IndexedDB (`idb`) para cache local e fila offline
- Capacitor 8 (Android) + Electron 42 (Desktop)

---

## 2. Rodar localmente

```bash
bun install        # ou npm install
bun run dev        # http://localhost:5173
```

Variáveis de ambiente são gerenciadas pela Lovable Cloud — não edite `.env` manualmente.

```bash
bun run build      # gera dist/client (web/PWA)
bun run preview    # serve o build
```

---

## 3. Empacotar como APK Android

### Pré-requisitos no seu computador

- **Android Studio** (https://developer.android.com/studio)
- **JDK 17+**
- Variável de ambiente `ANDROID_HOME` apontando para o SDK

### Primeira vez (gera a pasta `android/`)

```bash
bun run build
bun run cap:add:android      # cria android/ — só na primeira vez
bun run cap:sync:android
bun run cap:open:android     # abre no Android Studio
```

> O `appId` já está configurado como **`br.com.voxmode.voxcontrol`** e o `appName` como **VOX Control** em `capacitor.config.ts`.
> Se preferir rodar o init manualmente:
> ```bash
> npx cap init "VOX Control" br.com.voxmode.voxcontrol --web-dir dist/client
> ```

### Atualizar o APK depois de mudanças no código

```bash
bun run android:build        # build web + cap sync android
bun run cap:open:android     # abre o projeto no Android Studio
```

### Gerar o APK no Android Studio

**APK de teste (debug):**
1. `Build → Build Bundle(s) / APK(s) → Build APK(s)`
2. Saída: `android/app/build/outputs/apk/debug/app-debug.apk`

**APK assinado (release / produção):**
1. `Build → Generate Signed Bundle / APK → APK`
2. Crie ou selecione uma **keystore** (guarde em local seguro — sem ela você não consegue publicar updates)
3. Selecione `release` + ambas as assinaturas (V1 + V2)
4. Saída: `android/app/release/app-release.apk`

### Atualizar versão do app

Em `android/app/build.gradle` ajuste:

```gradle
versionCode 2          // inteiro, sempre incremental
versionName "1.1.0"    // string visível ao usuário
```

### Trocar ícone e splash

- Ícones PNG em `public/icon-192.png` e `public/icon-512.png` (PWA)
- Para Android nativo use [@capacitor/assets](https://github.com/ionic-team/capacitor-assets):
  ```bash
  bunx @capacitor/assets generate --android
  ```
  Ele gera todos os tamanhos a partir de `resources/icon.png` e `resources/splash.png`.

---

## 4. Permissões Android (mínimas)

Configuradas em `android/app/src/main/AndroidManifest.xml` quando você roda `cap add android`. Mantemos só o necessário:

- `INTERNET` — sincronização e Supabase
- `READ_MEDIA_IMAGES` / `READ_EXTERNAL_STORAGE` — anexar imagens e arquivos a pedidos
- `CAMERA` — opcional (foto da peça pronta / comprovante)
- `POST_NOTIFICATIONS` — opcional (lembretes futuros)

Não adicionamos permissões desnecessárias (sem localização, contatos, etc).

---

## 5. Modo offline (Web + APK)

O app é **offline-first**:
- Tudo é lido primeiro do IndexedDB (`src/lib/offline/db.ts`) — instantâneo.
- Mutações entram numa **outbox** e sobem para o Supabase quando a conexão volta.
- Indicador no header mostra **Online / Offline / Sincronizando / Pendentes**.

Funciona sem internet:
- Abrir o app, ver dados já carregados
- Criar cliente, pedido, evento, registro de produção/manutenção
- Anexar arquivos (vão pendentes pra sincronizar)
- Consultar calendário, estoque e fichas locais

---

## 6. Empacotar como Desktop (Electron)

```bash
bun run build
bun run electron:pack:linux    # → electron-release/VOXControl-linux-x64/
bun run electron:pack:win      # → electron-release/VOXControl-win32-x64/
bun run electron:pack:mac      # apenas em macOS
```

Para rodar localmente sem empacotar:
```bash
bun run build
bun run electron:dev
```

---

## 7. Checklist de testes no APK

1. Instalar APK em Android real (habilitar "fontes desconhecidas")
2. Abrir o app **sem internet**
3. Criar cliente offline
4. Criar pedido offline
5. Anexar imagem ao pedido offline
6. Religar internet → verificar sincronização automática
7. Criar orçamento e exportar PDF
8. Enviar pedido para produção
9. Reagendar evento no calendário
10. Exportar calendário em PDF
11. Exportar calendário em ICS
12. Validar upload de arquivos (múltiplos + categorias)
13. Validar formulário DTF / DTG / Bordado
14. Validar dashboard, relatórios, estoque e financeiro
15. Validar performance em celular simples (Android 8+)

---

## 8. Publicação futura

- **Google Play**: upload do `.aab` assinado no Google Play Console
- **Distribuição direta**: hospede o `.apk` em qualquer URL
- **iOS**: instale `@capacitor/ios` em um Mac com Xcode (não incluído nesta versão)

---

## 9. Estrutura relevante

```
src/
  routes/                   # páginas (TanStack file-based)
  features/pedido-wizard/   # wizard DTF/DTG/Bordado
  components/mobile-*       # bottom nav e drawer mobile
  lib/offline/              # IndexedDB + outbox + sync
  lib/platform.ts           # detecta web / capacitor / electron
  integrations/supabase/    # cliente, auth-middleware, admin
capacitor.config.ts         # appId, appName, splash, status bar
public/manifest.json        # PWA manifest
electron/                   # main + preload do desktop
```
