# Empacotamento — APK Android e Desktop

O mesmo código React vira: web (Lovable Cloud), APK Android (Capacitor) e executável desktop Win/Mac/Linux (Electron).

## 1. Build comum

```bash
bun run build           # gera dist/client (assets estáticos do front-end)
```

## 2. Android (APK)

Pré-requisitos no seu computador:
- Android Studio instalado (https://developer.android.com/studio)
- JDK 17+
- Variável `ANDROID_HOME` configurada

Primeira vez:
```bash
bun run build
bun run cap:add:android      # cria a pasta android/
bun run cap:sync:android
bun run cap:open:android     # abre no Android Studio
```

No Android Studio:
1. **Build → Generate Signed Bundle / APK → APK**
2. Crie ou selecione uma keystore.
3. O APK fica em `android/app/release/app-release.apk`.

A cada nova versão:
```bash
bun run android:build        # build + cap sync
```
Depois reabra o projeto no Android Studio e gere o APK.

## 3. Desktop (Electron)

Linux (rodando em qualquer SO Linux):
```bash
bun run build
bun run electron:pack:linux
# saída: electron-release/VOXControl-linux-x64/  (executável `VOXControl`)
```

Windows (cross-build a partir de Linux/Mac também funciona):
```bash
bun run build
bun run electron:pack:win
# saída: electron-release/VOXControl-win32-x64/  (`VOXControl.exe`)
```

macOS (apenas em Mac):
```bash
bun run build
bun run electron:pack:mac
```

Para rodar localmente em desenvolvimento sem empacotar:
```bash
bun run build
bun run electron:dev
```

## 4. Modo offline

Em todas as plataformas o app funciona sem internet:
- Os dados ficam em IndexedDB (`src/lib/offline/db.ts`).
- Alterações entram em uma fila (`outbox`) e sobem automaticamente quando a conexão volta.
- Indicador no header mostra **Online / Offline** + número de itens pendentes.

## 5. Publicação

- **Play Store**: faça upload manual do APK assinado no Google Play Console.
- **Distribuição direta**: hospede o `.apk` em qualquer URL e o usuário instala
  habilitando "fontes desconhecidas".
- **Desktop**: distribua os zips/pastas de `electron-release/` direto pelo seu
  site ou Drive.

## 6. iOS (futuro)

iOS não está incluído nesta versão. Quando precisar, instale `@capacitor/ios`,
rode `npx cap add ios` em um Mac com Xcode e gere o `.ipa`.
