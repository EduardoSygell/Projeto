const { contextBridge, ipcRenderer } = require("electron");

contextBridge.exposeInMainWorld("electron", {
  isElectron: true,
  version: process.versions.electron,
  saveFile: (name, data) => ipcRenderer.invoke("save-file", { name, data }),
});
