
-- Config de precificação (chave/valor por categoria)
CREATE TABLE public.config_precificacao (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  categoria text NOT NULL,
  chave text NOT NULL,
  valor numeric NOT NULL DEFAULT 0,
  descricao text,
  updated_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE (categoria, chave)
);
ALTER TABLE public.config_precificacao ENABLE ROW LEVEL SECURITY;
CREATE POLICY config_precificacao_select ON public.config_precificacao FOR SELECT TO authenticated USING (is_authenticated_app_user(auth.uid()));
CREATE POLICY config_precificacao_insert ON public.config_precificacao FOR INSERT TO authenticated WITH CHECK (is_authenticated_app_user(auth.uid()));
CREATE POLICY config_precificacao_update ON public.config_precificacao FOR UPDATE TO authenticated USING (is_authenticated_app_user(auth.uid()));
CREATE POLICY config_precificacao_delete ON public.config_precificacao FOR DELETE TO authenticated USING (has_role(auth.uid(),'dono') OR has_role(auth.uid(),'administrador'));
CREATE TRIGGER trg_cp_touch BEFORE UPDATE ON public.config_precificacao FOR EACH ROW EXECUTE FUNCTION public.touch_updated_at();

INSERT INTO public.config_precificacao (categoria, chave, valor, descricao) VALUES
 ('DTF','custo_filme_metro',12,'R$ por metro de filme DTF'),
 ('DTF','custo_tinta_branca_ml',0.8,'R$ por ml de tinta branca'),
 ('DTF','custo_tinta_cmyk_ml',0.6,'R$ por ml de tinta CMYK'),
 ('DTF','custo_mao_obra_min',1.2,'R$ por minuto de mão de obra'),
 ('DTG','custo_tinta_branca_ml',1.0,'R$ por ml de tinta branca DTG'),
 ('DTG','custo_tinta_cmyk_ml',0.8,'R$ por ml de tinta CMYK DTG'),
 ('DTG','custo_pretratamento_un',3,'R$ por aplicação de pré-tratamento'),
 ('DTG','custo_mao_obra_min',1.5,'R$ por minuto de mão de obra'),
 ('BORDADO','custo_por_1000_pontos',5,'R$ por 1000 pontos'),
 ('BORDADO','custo_minuto_maquina',1.0,'R$ por minuto de máquina'),
 ('BORDADO','custo_linha_m',0.05,'R$ por metro de linha'),
 ('BORDADO','custo_entretela_un',1.5,'R$ por unidade de entretela'),
 ('BORDADO','custo_setup_matriz',20,'Custo de setup/matriz'),
 ('GERAL','margem_padrao_pct',60,'Margem padrão em %'),
 ('GERAL','validade_orcamento_dias',7,'Dias de validade do orçamento');

-- Fichas técnicas
CREATE TABLE public.fichas_tecnicas (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  pedido_id uuid NOT NULL,
  item_id uuid,
  tecnica text NOT NULL,
  dados jsonb NOT NULL DEFAULT '{}'::jsonb,
  mockup_url text,
  arquivo_arte_url text,
  status_arte text DEFAULT 'PENDENTE',
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);
ALTER TABLE public.fichas_tecnicas ENABLE ROW LEVEL SECURITY;
CREATE POLICY fichas_tecnicas_select ON public.fichas_tecnicas FOR SELECT TO authenticated USING (is_authenticated_app_user(auth.uid()));
CREATE POLICY fichas_tecnicas_insert ON public.fichas_tecnicas FOR INSERT TO authenticated WITH CHECK (is_authenticated_app_user(auth.uid()));
CREATE POLICY fichas_tecnicas_update ON public.fichas_tecnicas FOR UPDATE TO authenticated USING (is_authenticated_app_user(auth.uid()));
CREATE POLICY fichas_tecnicas_delete ON public.fichas_tecnicas FOR DELETE TO authenticated USING (has_role(auth.uid(),'dono') OR has_role(auth.uid(),'administrador'));
CREATE TRIGGER trg_ft_touch BEFORE UPDATE ON public.fichas_tecnicas FOR EACH ROW EXECUTE FUNCTION public.touch_updated_at();
CREATE INDEX idx_fichas_pedido ON public.fichas_tecnicas(pedido_id);

-- Clientes: campos extras
ALTER TABLE public.clientes
  ADD COLUMN IF NOT EXISTS tipo text DEFAULT 'PF',
  ADD COLUMN IF NOT EXISTS status text DEFAULT 'ATIVO',
  ADD COLUMN IF NOT EXISTS atencoes_producao text,
  ADD COLUMN IF NOT EXISTS origem text;

-- Pedidos: campos extras
ALTER TABLE public.pedidos
  ADD COLUMN IF NOT EXISTS origem text,
  ADD COLUMN IF NOT EXISTS data_limite_producao date,
  ADD COLUMN IF NOT EXISTS entrada_valor numeric DEFAULT 0,
  ADD COLUMN IF NOT EXISTS desconto numeric DEFAULT 0,
  ADD COLUMN IF NOT EXISTS acrescimo numeric DEFAULT 0,
  ADD COLUMN IF NOT EXISTS margem_pct numeric DEFAULT 0;

-- Itens pedido
ALTER TABLE public.itens_pedido
  ADD COLUMN IF NOT EXISTS valor_total_calculado numeric DEFAULT 0;

-- Anexos
ALTER TABLE public.anexos
  ADD COLUMN IF NOT EXISTS categoria text DEFAULT 'OUTRO',
  ADD COLUMN IF NOT EXISTS descricao text,
  ADD COLUMN IF NOT EXISTS status text DEFAULT 'RECEBIDO',
  ADD COLUMN IF NOT EXISTS item_id uuid;
