
-- Fix: definir search_path em touch_updated_at
create or replace function public.touch_updated_at()
returns trigger
language plpgsql
set search_path = public
as $$
begin new.updated_at = now(); return new; end; $$;

-- Restringir execução de funções SECURITY DEFINER
revoke execute on function public.has_role(uuid, public.app_role) from public, anon;
revoke execute on function public.is_authenticated_app_user(uuid) from public, anon;
revoke execute on function public.handle_new_user() from public, anon, authenticated;
revoke execute on function public.touch_updated_at() from public, anon, authenticated;

grant execute on function public.has_role(uuid, public.app_role) to authenticated;
grant execute on function public.is_authenticated_app_user(uuid) to authenticated;
