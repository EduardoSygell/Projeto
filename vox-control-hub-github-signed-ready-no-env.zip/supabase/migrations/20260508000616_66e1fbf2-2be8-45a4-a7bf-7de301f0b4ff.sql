
insert into storage.buckets (id, name, public)
values ('anexos', 'anexos', true)
on conflict (id) do nothing;

create policy "anexos_storage_select"
on storage.objects for select
to authenticated, anon
using (bucket_id = 'anexos');

create policy "anexos_storage_insert"
on storage.objects for insert
to authenticated
with check (bucket_id = 'anexos' and public.is_authenticated_app_user(auth.uid()));

create policy "anexos_storage_update"
on storage.objects for update
to authenticated
using (bucket_id = 'anexos' and public.is_authenticated_app_user(auth.uid()));

create policy "anexos_storage_delete"
on storage.objects for delete
to authenticated
using (
  bucket_id = 'anexos'
  and (public.has_role(auth.uid(), 'dono') or public.has_role(auth.uid(), 'administrador'))
);
