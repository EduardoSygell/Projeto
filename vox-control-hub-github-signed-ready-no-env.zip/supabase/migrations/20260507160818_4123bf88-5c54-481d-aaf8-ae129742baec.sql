
-- =========================================================
-- VOX Control — esquema inicial
-- =========================================================

-- ----- Enums -----
create type public.app_role as enum ('dono', 'administrador', 'producao', 'financeiro');
create type public.tecnica_producao as enum ('DTF', 'DTG', 'BORDADO', 'PRENSA');
create type public.tipo_tecido as enum ('ALGODAO_100', 'PV', 'POLIESTER', 'OUTRO');
create type public.status_pedido as enum (
  'ORCAMENTO','AGUARDANDO_ARTE','ARTE_APROVADA','EM_PRODUCAO','PRONTO','ENTREGUE','CANCELADO'
);
create type public.prioridade as enum ('BAIXA','MEDIA','ALTA','URGENTE');
create type public.status_pagamento as enum ('PENDENTE','PARCIAL','PAGO','ATRASADO');
create type public.status_arte as enum ('PENDENTE','ENVIADA','APROVADA','AJUSTES','REJEITADA');
create type public.status_ordem as enum ('FILA','EM_ANDAMENTO','PAUSADA','CONCLUIDA','REFAZER');
create type public.status_maquina as enum ('OPERACIONAL','MANUTENCAO','PARADA');
create type public.tipo_movimento_estoque as enum ('ENTRADA','SAIDA','AJUSTE');
create type public.tipo_financeiro as enum ('RECEITA','DESPESA');
create type public.status_tarefa as enum ('ABERTA','EM_ANDAMENTO','CONCLUIDA','CANCELADA');

-- ----- Profiles -----
create table public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  nome text not null,
  telefone text,
  avatar_url text,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
alter table public.profiles enable row level security;

-- ----- User roles -----
create table public.user_roles (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  role public.app_role not null,
  created_at timestamptz not null default now(),
  unique (user_id, role)
);
alter table public.user_roles enable row level security;

create or replace function public.has_role(_user_id uuid, _role public.app_role)
returns boolean
language sql
stable
security definer
set search_path = public
as $$
  select exists (select 1 from public.user_roles where user_id = _user_id and role = _role);
$$;

create or replace function public.is_authenticated_app_user(_user_id uuid)
returns boolean
language sql
stable
security definer
set search_path = public
as $$
  select exists (select 1 from public.user_roles where user_id = _user_id);
$$;

-- ----- Auto-create profile on signup -----
create or replace function public.handle_new_user()
returns trigger
language plpgsql
security definer
set search_path = public
as $$
begin
  insert into public.profiles (id, nome)
  values (new.id, coalesce(new.raw_user_meta_data->>'nome', split_part(new.email, '@', 1)));
  return new;
end;
$$;

create trigger on_auth_user_created
  after insert on auth.users
  for each row execute function public.handle_new_user();

-- ----- Updated_at helper -----
create or replace function public.touch_updated_at()
returns trigger language plpgsql as $$
begin new.updated_at = now(); return new; end; $$;

-- ----- Clientes -----
create table public.clientes (
  id uuid primary key default gen_random_uuid(),
  nome text not null,
  documento text,
  telefone text,
  email text,
  endereco text,
  observacoes text,
  created_by uuid references auth.users(id),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
create trigger trg_clientes_updated before update on public.clientes
  for each row execute function public.touch_updated_at();
alter table public.clientes enable row level security;

-- ----- Pedidos -----
create table public.pedidos (
  id uuid primary key default gen_random_uuid(),
  codigo text not null unique,
  cliente_id uuid not null references public.clientes(id) on delete restrict,
  status public.status_pedido not null default 'ORCAMENTO',
  prioridade public.prioridade not null default 'MEDIA',
  data_entrega date,
  valor_total numeric(12,2) not null default 0,
  status_pagamento public.status_pagamento not null default 'PENDENTE',
  observacoes text,
  created_by uuid references auth.users(id),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
create index idx_pedidos_cliente on public.pedidos(cliente_id);
create index idx_pedidos_status on public.pedidos(status);
create trigger trg_pedidos_updated before update on public.pedidos
  for each row execute function public.touch_updated_at();
alter table public.pedidos enable row level security;

-- ----- Itens do pedido -----
create table public.itens_pedido (
  id uuid primary key default gen_random_uuid(),
  pedido_id uuid not null references public.pedidos(id) on delete cascade,
  descricao text not null,
  tecnica public.tecnica_producao not null,
  tecido public.tipo_tecido,
  cor text,
  tamanho text,
  quantidade integer not null check (quantidade > 0),
  valor_unitario numeric(12,2) not null default 0,
  observacoes text,
  created_at timestamptz not null default now()
);
create index idx_itens_pedido_pedido on public.itens_pedido(pedido_id);
alter table public.itens_pedido enable row level security;

-- ----- Artes -----
create table public.artes (
  id uuid primary key default gen_random_uuid(),
  pedido_id uuid not null references public.pedidos(id) on delete cascade,
  item_id uuid references public.itens_pedido(id) on delete set null,
  nome text not null,
  arquivo_url text,
  versao integer not null default 1,
  status public.status_arte not null default 'PENDENTE',
  created_by uuid references auth.users(id),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
create trigger trg_artes_updated before update on public.artes
  for each row execute function public.touch_updated_at();
alter table public.artes enable row level security;

-- ----- Aprovacoes de arte -----
create table public.aprovacoes_arte (
  id uuid primary key default gen_random_uuid(),
  arte_id uuid not null references public.artes(id) on delete cascade,
  status public.status_arte not null,
  feedback text,
  enviado_em timestamptz,
  respondido_em timestamptz,
  respondido_por text,
  created_by uuid references auth.users(id),
  created_at timestamptz not null default now()
);
create index idx_aprovacoes_arte on public.aprovacoes_arte(arte_id);
alter table public.aprovacoes_arte enable row level security;

-- ----- Maquinas -----
create table public.maquinas (
  id uuid primary key default gen_random_uuid(),
  nome text not null,
  tecnica public.tecnica_producao not null,
  status public.status_maquina not null default 'OPERACIONAL',
  modelo text,
  fabricante text,
  observacoes text,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
create trigger trg_maquinas_updated before update on public.maquinas
  for each row execute function public.touch_updated_at();
alter table public.maquinas enable row level security;

-- ----- Ordens de producao -----
create table public.ordens_producao (
  id uuid primary key default gen_random_uuid(),
  pedido_id uuid not null references public.pedidos(id) on delete cascade,
  item_id uuid references public.itens_pedido(id) on delete set null,
  tecnica public.tecnica_producao not null,
  maquina_id uuid references public.maquinas(id) on delete set null,
  status public.status_ordem not null default 'FILA',
  prioridade public.prioridade not null default 'MEDIA',
  iniciada_em timestamptz,
  concluida_em timestamptz,
  responsavel_id uuid references auth.users(id),
  observacoes text,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
create index idx_op_pedido on public.ordens_producao(pedido_id);
create index idx_op_maquina on public.ordens_producao(maquina_id);
create trigger trg_op_updated before update on public.ordens_producao
  for each row execute function public.touch_updated_at();
alter table public.ordens_producao enable row level security;

-- ----- Etapas de producao -----
create table public.etapas_producao (
  id uuid primary key default gen_random_uuid(),
  ordem_id uuid not null references public.ordens_producao(id) on delete cascade,
  nome text not null,
  ordem_sequencia integer not null default 1,
  status public.status_ordem not null default 'FILA',
  iniciada_em timestamptz,
  concluida_em timestamptz,
  responsavel_id uuid references auth.users(id),
  observacoes text,
  created_at timestamptz not null default now()
);
create index idx_etapas_ordem on public.etapas_producao(ordem_id);
alter table public.etapas_producao enable row level security;

-- ----- Filas de maquina -----
create table public.filas_maquina (
  id uuid primary key default gen_random_uuid(),
  maquina_id uuid not null references public.maquinas(id) on delete cascade,
  ordem_id uuid not null references public.ordens_producao(id) on delete cascade,
  posicao integer not null default 1,
  created_at timestamptz not null default now(),
  unique (maquina_id, ordem_id)
);
create index idx_fila_maquina on public.filas_maquina(maquina_id, posicao);
alter table public.filas_maquina enable row level security;

-- ----- Manutencoes -----
create table public.manutencoes (
  id uuid primary key default gen_random_uuid(),
  maquina_id uuid not null references public.maquinas(id) on delete cascade,
  tipo text not null,
  descricao text,
  data_prevista date,
  data_realizada date,
  custo numeric(12,2),
  responsavel_id uuid references auth.users(id),
  created_at timestamptz not null default now()
);
create index idx_manut_maquina on public.manutencoes(maquina_id);
alter table public.manutencoes enable row level security;

-- ----- Estoque -----
create table public.estoque_itens (
  id uuid primary key default gen_random_uuid(),
  nome text not null,
  categoria text not null,
  unidade text not null default 'un',
  quantidade numeric(12,3) not null default 0,
  quantidade_minima numeric(12,3) not null default 0,
  custo_unitario numeric(12,2),
  fornecedor text,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
create trigger trg_estoque_itens_updated before update on public.estoque_itens
  for each row execute function public.touch_updated_at();
alter table public.estoque_itens enable row level security;

create table public.estoque_movimentacoes (
  id uuid primary key default gen_random_uuid(),
  item_id uuid not null references public.estoque_itens(id) on delete cascade,
  tipo public.tipo_movimento_estoque not null,
  quantidade numeric(12,3) not null,
  motivo text,
  pedido_id uuid references public.pedidos(id) on delete set null,
  responsavel_id uuid references auth.users(id),
  created_at timestamptz not null default now()
);
create index idx_estoque_mov_item on public.estoque_movimentacoes(item_id);
alter table public.estoque_movimentacoes enable row level security;

-- ----- Financeiro -----
create table public.financeiro_receber (
  id uuid primary key default gen_random_uuid(),
  pedido_id uuid references public.pedidos(id) on delete set null,
  cliente_id uuid references public.clientes(id) on delete set null,
  descricao text not null,
  valor numeric(12,2) not null,
  vencimento date not null,
  pago_em date,
  status public.status_pagamento not null default 'PENDENTE',
  metodo_pagamento text,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
create trigger trg_fin_receber_updated before update on public.financeiro_receber
  for each row execute function public.touch_updated_at();
alter table public.financeiro_receber enable row level security;

create table public.financeiro_pagar (
  id uuid primary key default gen_random_uuid(),
  fornecedor text,
  descricao text not null,
  categoria text,
  valor numeric(12,2) not null,
  vencimento date not null,
  pago_em date,
  status public.status_pagamento not null default 'PENDENTE',
  metodo_pagamento text,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
create trigger trg_fin_pagar_updated before update on public.financeiro_pagar
  for each row execute function public.touch_updated_at();
alter table public.financeiro_pagar enable row level security;

-- ----- Tarefas -----
create table public.tarefas (
  id uuid primary key default gen_random_uuid(),
  titulo text not null,
  descricao text,
  status public.status_tarefa not null default 'ABERTA',
  prioridade public.prioridade not null default 'MEDIA',
  prazo timestamptz,
  responsavel_id uuid references auth.users(id),
  pedido_id uuid references public.pedidos(id) on delete set null,
  created_by uuid references auth.users(id),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
create trigger trg_tarefas_updated before update on public.tarefas
  for each row execute function public.touch_updated_at();
alter table public.tarefas enable row level security;

-- ----- Calendario -----
create table public.calendario_eventos (
  id uuid primary key default gen_random_uuid(),
  titulo text not null,
  descricao text,
  inicio timestamptz not null,
  fim timestamptz,
  tipo text,
  pedido_id uuid references public.pedidos(id) on delete set null,
  maquina_id uuid references public.maquinas(id) on delete set null,
  responsavel_id uuid references auth.users(id),
  cor text,
  created_at timestamptz not null default now()
);
alter table public.calendario_eventos enable row level security;

-- ----- Anexos -----
create table public.anexos (
  id uuid primary key default gen_random_uuid(),
  nome text not null,
  url text not null,
  tipo text,
  tamanho_bytes bigint,
  pedido_id uuid references public.pedidos(id) on delete cascade,
  cliente_id uuid references public.clientes(id) on delete set null,
  arte_id uuid references public.artes(id) on delete cascade,
  uploaded_by uuid references auth.users(id),
  created_at timestamptz not null default now()
);
alter table public.anexos enable row level security;

-- ----- Logs / Sincronizacao -----
create table public.logs_auditoria (
  id uuid primary key default gen_random_uuid(),
  user_id uuid references auth.users(id),
  acao text not null,
  entidade text not null,
  entidade_id uuid,
  payload jsonb,
  created_at timestamptz not null default now()
);
alter table public.logs_auditoria enable row level security;

create table public.fila_sincronizacao (
  id uuid primary key default gen_random_uuid(),
  tipo text not null,
  payload jsonb not null,
  status text not null default 'PENDENTE',
  tentativas integer not null default 0,
  ultimo_erro text,
  processado_em timestamptz,
  created_at timestamptz not null default now()
);
alter table public.fila_sincronizacao enable row level security;

-- =========================================================
-- RLS — usuários autenticados com papel podem operar.
-- Apenas dono/administrador podem mexer em user_roles e auditoria.
-- =========================================================

-- Profiles
create policy "profiles_self_select" on public.profiles
  for select to authenticated using (auth.uid() = id or public.is_authenticated_app_user(auth.uid()));
create policy "profiles_self_update" on public.profiles
  for update to authenticated using (auth.uid() = id);
create policy "profiles_self_insert" on public.profiles
  for insert to authenticated with check (auth.uid() = id);

-- user_roles
create policy "roles_select_self_or_admin" on public.user_roles
  for select to authenticated using (
    user_id = auth.uid()
    or public.has_role(auth.uid(), 'dono')
    or public.has_role(auth.uid(), 'administrador')
  );
create policy "roles_admin_manage" on public.user_roles
  for all to authenticated using (
    public.has_role(auth.uid(), 'dono') or public.has_role(auth.uid(), 'administrador')
  ) with check (
    public.has_role(auth.uid(), 'dono') or public.has_role(auth.uid(), 'administrador')
  );

-- Helper: aplicar políticas padrão (CRUD para qualquer usuário com papel)
do $$
declare t text;
begin
  for t in select unnest(array[
    'clientes','pedidos','itens_pedido','artes','aprovacoes_arte',
    'ordens_producao','etapas_producao','filas_maquina','maquinas','manutencoes',
    'estoque_itens','estoque_movimentacoes','financeiro_receber','financeiro_pagar',
    'tarefas','calendario_eventos','anexos','fila_sincronizacao'
  ])
  loop
    execute format('create policy "%1$s_select" on public.%1$s for select to authenticated using (public.is_authenticated_app_user(auth.uid()));', t);
    execute format('create policy "%1$s_insert" on public.%1$s for insert to authenticated with check (public.is_authenticated_app_user(auth.uid()));', t);
    execute format('create policy "%1$s_update" on public.%1$s for update to authenticated using (public.is_authenticated_app_user(auth.uid()));', t);
    execute format('create policy "%1$s_delete" on public.%1$s for delete to authenticated using (public.has_role(auth.uid(), ''dono'') or public.has_role(auth.uid(), ''administrador''));', t);
  end loop;
end $$;

-- Logs de auditoria: somente dono/admin leem; qualquer usuário autenticado insere
create policy "audit_admin_select" on public.logs_auditoria
  for select to authenticated using (
    public.has_role(auth.uid(), 'dono') or public.has_role(auth.uid(), 'administrador')
  );
create policy "audit_authenticated_insert" on public.logs_auditoria
  for insert to authenticated with check (public.is_authenticated_app_user(auth.uid()));
