-- Restringir todas as políticas RLS do schema public e as do bucket anexos
-- para o role 'authenticated' apenas (removendo acesso anônimo).
DO $$
DECLARE r record;
BEGIN
  FOR r IN
    SELECT schemaname, tablename, policyname
    FROM pg_policies
    WHERE schemaname = 'public'
       OR (schemaname = 'storage' AND tablename = 'objects'
           AND policyname IN ('anexos_storage_delete','anexos_storage_update','anexos_storage_insert','anexos_storage_select'))
  LOOP
    EXECUTE format('ALTER POLICY %I ON %I.%I TO authenticated',
                   r.policyname, r.schemaname, r.tablename);
  END LOOP;
END $$;