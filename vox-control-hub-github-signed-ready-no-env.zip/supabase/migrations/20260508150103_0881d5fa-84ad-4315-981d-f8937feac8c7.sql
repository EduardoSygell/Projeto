
CREATE UNIQUE INDEX IF NOT EXISTS config_precificacao_categoria_chave_uniq
  ON public.config_precificacao (categoria, chave);

INSERT INTO public.config_precificacao (categoria, chave, valor, descricao) VALUES
  ('GERAL','margem_padrao_pct',30,'Margem padrão (%)'),
  ('GERAL','desconto_padrao_pct',0,'Desconto padrão (%)'),
  ('GERAL','acrescimo_padrao_pct',0,'Acréscimo padrão (%)'),
  ('GERAL','validade_orcamento_dias',7,'Validade do orçamento (dias)'),
  ('DTF','filme_metro',18,'Filme DTF (R$/metro)'),
  ('DTF','tinta_branca_ml',0.45,'Tinta branca DTF (R$/ml)'),
  ('DTF','tinta_cmyk_ml',0.35,'Tinta CMYK DTF (R$/ml)'),
  ('DTF','mao_obra_min',1.5,'Mão de obra DTF (R$/min)'),
  ('DTF','perda_pct',5,'Perda estimada (%)'),
  ('DTG','tinta_ml',0.6,'Tinta DTG (R$/ml)'),
  ('DTG','pretratamento_un',2.5,'Pré-tratamento (R$/un)'),
  ('DTG','mao_obra_min',1.5,'Mão de obra DTG (R$/min)'),
  ('BORDADO','pontos_1000',2.5,'Pontos (R$/1000)'),
  ('BORDADO','minuto_maquina',1.2,'Minuto de máquina (R$)'),
  ('BORDADO','linha_un',0.3,'Linha (R$/un)'),
  ('BORDADO','entretela_un',0.5,'Entretela (R$/un)'),
  ('BORDADO','setup_matriz',25,'Setup/Matriz (R$)'),
  ('PAGAMENTO','pix',1,'PIX'),
  ('PAGAMENTO','dinheiro',1,'Dinheiro'),
  ('PAGAMENTO','cartao_credito',1,'Cartão de crédito'),
  ('PAGAMENTO','cartao_debito',1,'Cartão de débito'),
  ('PAGAMENTO','boleto',0,'Boleto'),
  ('PAGAMENTO','transferencia',0,'Transferência bancária'),
  ('PAGAMENTO','forma_padrao',0,'PIX')
ON CONFLICT (categoria, chave) DO NOTHING;
