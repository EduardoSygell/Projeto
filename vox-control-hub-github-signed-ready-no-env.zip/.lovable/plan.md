
# Tornar o app instalável: APK Android + Desktop + Offline-first

Hoje o projeto roda como web app (TanStack Start SSR). Para virar APK e executável desktop, precisamos:
1. Gerar um build estático/SPA do front-end.
2. Embrulhar esse build no Capacitor (Android) e no Electron (Win/Mac/Linux).
3. Habilitar offline-first de verdade (cache de dados + assets + fila de sincronização que já temos).

Tudo continua usando o mesmo código React — não duplicamos telas.

---

## 1. Build estático para empacotamento

- Adicionar script `build:static` que gera um bundle SPA em `dist-static/` (sem SSR), apontando 100% para o backend Lovable Cloud já existente.
- Ajustar `vite.config.ts` com `base: './'` (necessário para Capacitor/Electron carregarem via `file://`).
- Garantir que rotas TanStack Router funcionem em modo hash/memory dentro do APK e do Electron (fallback `index.html`).
- Variáveis `VITE_SUPABASE_URL` / `VITE_SUPABASE_PUBLISHABLE_KEY` embutidas no build (já é o padrão Vite).

## 2. Offline-first

Camada nova em `src/lib/offline/`:

- `db.ts` — IndexedDB (via `idb`) com stores: `clientes`, `pedidos`, `fichas_tecnicas`, `anexos_meta`, `eventos`, `entregas`, `config_precificacao`, `outbox`.
- `sync.ts` — sincroniza Supabase ↔ IndexedDB:
  - Pull inicial das tabelas principais ao logar.
  - Push da `outbox` quando volta online (reaproveita `sync-queue.ts` atual).
  - Realtime do Supabase atualiza o cache local quando online.
- `queries.ts` — wrapper sobre react-query que lê do IndexedDB primeiro e revalida com Supabase em background (stale-while-revalidate).
- Telas existentes (dashboard, calendário, pedidos, configurações, wizard) passam a consumir esse wrapper — abrem mesmo sem internet.
- Indicador global online/offline no header/sidebar e badge de itens pendentes na fila.

## 3. Capacitor (Android APK)

- Instalar `@capacitor/core`, `@capacitor/cli`, `@capacitor/android`, `@capacitor/preferences`, `@capacitor/filesystem`, `@capacitor/network`, `@capacitor/share`.
- `capacitor.config.ts` apontando `webDir: 'dist-static'`, `appId: com.lovable.gestao`, `appName` configurável.
- `npx cap add android` cria a pasta `android/` versionada.
- Scripts:
  - `bun run build:android` → build static + `cap sync android`.
  - `bun run open:android` → abre no Android Studio para gerar APK assinado.
- Substitui o `gerarCalendarioPDF`/`anexos` por `Filesystem` + `Share` quando rodando dentro do Capacitor (detecção via `Capacitor.isNativePlatform()`).

## 4. Electron (Desktop Win/Mac/Linux)

- Adicionar `electron` e `@electron/packager` como devDeps.
- `electron/main.cjs` — `BrowserWindow` carregando `dist-static/index.html`, `contextIsolation: true`, `nodeIntegration: false`.
- `electron/preload.cjs` — expõe API mínima (`isElectron`, versão).
- Scripts:
  - `bun run build:desktop` → vite build estático + `@electron/packager` para Linux/Win/Mac.
  - Saídas zipadas em `/mnt/documents/` para download direto.

## 5. Ajustes no código existente

- `src/lib/platform.ts` (novo) — detecta `web | capacitor | electron` e expõe helpers (download de arquivo, share, abrir link externo).
- `orcamento-pdf.ts` e `calendario-export.ts` passam a salvar via `Filesystem` no Android e via `dialog.showSaveDialog` no Electron.
- Upload de anexos: no Capacitor usa `@capacitor/camera` + `Filesystem` para escolher arquivo; no Electron usa input nativo; no web continua igual.
- Login: mantém Supabase Auth (funciona em todos os runtimes); tokens salvos via `@capacitor/preferences` no mobile para persistir entre aberturas.

## 6. Documentação curta

- `docs/empacotamento.md` explicando como gerar APK e instaladores desktop, com pré-requisitos (Android Studio, JDK 17, etc).

---

## Entregáveis ao final

- `bun run build:android` produz APK assinável.
- `bun run build:desktop` produz `.tar.gz` (Linux), `.zip` (Mac/Win) prontos pra baixar.
- App abre offline em todas as plataformas com dados em cache; alterações entram na fila e sobem quando reconectar.

## Fora de escopo

- iOS (.ipa) — exigiria Mac/Xcode, fica para depois conforme você optou.
- Publicação automática em Play Store / lojas — apenas geramos o APK; envio é manual.

Posso seguir com a implementação?
